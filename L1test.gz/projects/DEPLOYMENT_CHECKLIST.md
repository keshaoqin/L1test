# 部署前检查清单

## 服务器环境检查

- [ ] 服务器已连接（IP: 47.89.134.217）
- [ ] 操作系统为 Ubuntu 20.04/22.04 或其他 Linux 发行版
- [ ] 已安装 Node.js 24.x (`node --version`)
- [ ] 已安装 npm (`npm --version`)
- [ ] 已安装 pnpm (`pnpm --version`)
- [ ] 已安装 PM2（推荐）(`pm2 --version`)
- [ ] 已安装 Nginx（可选）(`nginx -v`)

## 防火墙配置检查

- [ ] TCP 80 端口已开放（HTTP）
- [ ] TCP 443 端口已开放（HTTPS）
- [ ] TCP 5000 端口已开放（应用端口）
- [ ] 阿里云安全组规则已配置

## 项目文件检查

- [ ] 项目代码已上传到服务器
- [ ] `.env.production` 文件存在
- [ ] `nginx.conf` 文件存在（如需 Nginx）
- [ ] `ecosystem.config.js` 文件存在（如需 PM2）
- [ ] `.coze` 文件存在
- [ ] `package.json` 文件存在

## 依赖安装检查

- [ ] 已执行 `pnpm install`
- [ ] 无依赖安装错误
- [ ] `node_modules` 目录存在

## 构建检查

- [ ] 已执行 `npx next build`
- [ ] 构建成功无错误
- [ ] `.next` 目录存在

## 服务启动检查

- [ ] 服务已启动（使用 PM2 或 nohup）
- [ ] 端口 5000 正在监听 (`ss -lntp | grep 5000`)
- [ ] 服务进程运行正常 (`pm2 status` 或 `ps aux | grep next`)

## 网络访问检查

- [ ] 本地访问正常 (`curl http://localhost:5000`)
- [ ] 公网访问正常 (`curl http://47.89.134.217:5000`)
- [ ] 管理后台可访问 (`http://47.89.134.217:5000/admin/login`)

## 功能验证检查

- [ ] 首页加载正常
- [ ] 评估页面可访问
- [ ] 管理后台登录功能正常
- [ ] admin 账户可登录（admin/admin123）
- [ ] ksq 账户可登录（ksq/ksq123）
- [ ] 评估记录列表正常显示
- [ ] 管理员管理功能正常

## 日志检查

- [ ] 应用日志无错误 (`pm2 logs assessment-app` 或 `/tmp/assessment-*.log`)
- [ ] Nginx 日志无错误（如使用 Nginx）
- [ ] 系统日志无异常

## 安全检查

- [ ] 默认管理员密码已修改（可选，但推荐）
- [ ] 防火墙规则已配置
- [ ] 不必要的端口已关闭
- [ ] SSH 访问已加固（可选）

## 性能检查

- [ ] 页面加载速度正常
- [ ] API 响应时间正常
- [ ] 内存使用正常
- [ ] CPU 使用正常

## 备份检查

- [ ] 数据库已备份（如需要）
- [ ] 配置文件已备份
- [ ] 部署脚本已备份

## 文档检查

- [ ] 部署文档已阅读
- [ ] 管理员账号信息已记录
- [ ] 常见问题文档已了解
- [ ] 应急联系信息已记录

## 常见问题快速参考

### 服务无法启动
1. 检查 Node.js 版本：`node --version`
2. 检查端口占用：`ss -lntp | grep 5000`
3. 查看日志：`pm2 logs assessment-app`

### 无法访问网站
1. 检查防火墙：`sudo ufw status`
2. 检查安全组（阿里云控制台）
3. 检查服务状态：`pm2 status`

### 登录失败
1. 检查初始化接口：`curl http://localhost:5000/api/admin/init`
2. 使用默认账户：admin/admin123 或 ksq/ksq123
3. 查看日志：`pm2 logs assessment-app`

### 构建失败
1. 清理缓存：`rm -rf .next node_modules/.cache`
2. 重新安装依赖：`pnpm install`
3. 重新构建：`npx next build`

---

**部署日期**: ___________
**部署人员**: ___________
**验证结果**: [ ] 通过 [ ] 不通过
**备注**: ___________
