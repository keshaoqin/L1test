# 时悦健康 - 生活方式评估系统

> 基于生活方式医学理论的专业健康评估系统

## 🌟 项目简介

"时悦健康"是一个专业的线上生活方式评估系统，通过科学的问卷评估用户的饮食、运动、睡眠、基础健康和风险控制能力，生成个性化的健康报告和改善建议。

### 核心功能

- **📋 6步评估问卷**: 饮食、运动、睡眠等多个维度的科学评估
- **📊 智能评分系统**: 基于100分制的综合评分和等级评定
- **💡 个性化建议**: 根据评估结果提供针对性的改善建议
- **🖼️ 报告导出**: 支持将评估报告导出为高清图片
- **🔐 管理后台**: 完整的数据统计、记录查询和详情分析功能

## 🚀 快速开始

### 本地开发

```bash
# 安装依赖
pnpm install

# 启动开发服务器（端口 5000）
pnpm run dev
```

访问：http://localhost:5000/assessment

### 管理后台

访问：http://localhost:5000/admin/login

默认密码：`admin123`

## 📦 项目结构

```
.
├── src/
│   ├── app/
│   │   ├── assessment/           # 评估问卷页面
│   │   ├── admin/                # 管理后台
│   │   │   ├── login/           # 登录页面
│   │   │   ├── dashboard/       # 仪表盘
│   │   │   └── assessments/     # 评估记录
│   │   ├── api/                 # API 路由
│   │   │   ├── assess/          # 评估提交接口
│   │   │   └── admin/           # 管理后台接口
│   │   └── layout.tsx           # 根布局
│   ├── components/
│   │   └── ui/                  # UI 组件库
│   ├── lib/
│   │   └── scoring.ts           # 评分逻辑
│   ├── storage/
│   │   └── database/            # 数据库管理
│   ├── types/
│   │   └── assessment.ts        # 类型定义
│   └── globals.css              # 全局样式
├── public/                      # 静态资源
├── PRD.md                       # 产品需求文档
├── DEPLOYMENT.md                # 部署指南
└── package.json
```

## 🏗️ 技术栈

### 前端
- **框架**: Next.js 16 (App Router)
- **语言**: React 19 + TypeScript 5
- **样式**: Tailwind CSS 4
- **组件**: shadcn/ui
- **图表**: Recharts
- **工具**: html2canvas, Lucide Icons

### 后端
- **框架**: Next.js API Routes
- **数据库**: PostgreSQL
- **ORM**: Drizzle ORM
- **SDK**: coze-coding-dev-sdk

## 📊 数据库

### 表结构

```sql
assessments (评估记录表)
├── id                    VARCHAR(36)  - 主键
├── name                  VARCHAR(128) - 用户姓名
├── gender                VARCHAR(20)  - 性别
├── age                   INTEGER      - 年龄
├── request_data          JSONB        - 评估请求数据
├── response_data         JSONB        - 评估结果数据
├── total_score           INTEGER      - 总分
├── bmi                   VARCHAR(20)  - BMI 指数
├── total_score_level     VARCHAR(20)  - 评分等级
├── bmi_category          VARCHAR(20)  - BMI 分类
├── created_at            TIMESTAMP    - 创建时间
└── updated_at            TIMESTAMP    - 更新时间
```

### 数据状态

- **当前记录数**: 9 条
- **数据库类型**: PostgreSQL
- **连接方式**: coze-coding-dev-sdk

## 🔐 安全说明

⚠️ **生产环境注意事项**：

1. **修改默认密码**: 环境变量 `ADMIN_PASSWORD` 必须设置为强密码
2. **HTTPS 部署**: 生产环境必须使用 HTTPS
3. **认证升级**: 建议实施 JWT 认证替代当前简单的密码认证
4. **访问控制**: 建议添加 IP 白名单或 VPN 访问限制

## 📖 文档

- **产品需求**: [PRD.md](./PRD.md)
- **部署指南**: [DEPLOYMENT.md](./DEPLOYMENT.md)
- **技术栈文档**:
  - [Next.js](https://nextjs.org/docs)
  - [Drizzle ORM](https://orm.drizzle.team/docs/overview)
  - [shadcn/ui](https://ui.shadcn.com/)

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 许可证

本项目仅供学习和演示使用。

---

**Made with ❤️ by Coze Coding Team**
