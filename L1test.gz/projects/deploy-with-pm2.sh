#!/bin/bash

# 使用 PM2 部署脚本
# 适用于阿里云服务器生产环境

set -e

echo "=================================="
echo "使用 PM2 部署到阿里云服务器"
echo "=================================="
echo "服务器公网 IP: 47.89.134.217"
echo "服务器私有 IP: 172.19.22.208"
echo "=================================="

# 检查是否在正确的目录
if [ ! -f ".coze" ]; then
    echo "错误：请在项目根目录执行此脚本"
    exit 1
fi

# 检查 PM2 是否安装
if ! command -v pm2 &> /dev/null; then
    echo ""
    echo "安装 PM2..."
    echo "=================================="
    npm install -g pm2
fi

# 设置环境变量
export NODE_ENV=production
export PORT=5000
export DEPLOY_RUN_PORT=5000
export SERVER_PUBLIC_IP=47.89.134.217
export SERVER_PRIVATE_IP=172.19.22.208

echo ""
echo "步骤 1/5: 停止现有服务..."
echo "=================================="
if pm2 list | grep -q "assessment-app"; then
    echo "停止现有 PM2 服务..."
    pm2 stop assessment-app
    pm2 delete assessment-app
fi

# 确保端口 5000 没有被其他进程占用
PIDS=$(ss -H -lntp 2>/dev/null | awk -v port="5000" '$4 ~ ":"port"$"' | grep -o 'pid=[0-9]*' | cut -d= -f2 | paste -sd' ' - || true)
if [[ -n "${PIDS}" ]]; then
    echo "停止端口 5000 上的其他服务: ${PIDS}"
    echo "${PIDS}" | xargs -I {} kill -9 {}
    sleep 2
fi

echo ""
echo "步骤 2/5: 清理旧构建文件..."
echo "=================================="
rm -rf .next
rm -rf node_modules/.cache
echo "清理完成"

echo ""
echo "步骤 3/5: 安装依赖..."
echo "=================================="
pnpm install --prefer-frozen-lockfile --prefer-offline --loglevel=error
echo "依赖安装完成"

echo ""
echo "步骤 4/5: 构建项目..."
echo "=================================="
npx next build
echo "项目构建完成"

echo ""
echo "步骤 5/5: 使用 PM2 启动服务..."
echo "=================================="
# 使用 PM2 启动服务
pm2 start ecosystem.config.js

# 保存 PM2 配置
pm2 save

# 设置开机自启
pm2 startup systemd -u $USER --hp /home/$USER

echo ""
echo "等待服务启动..."
sleep 5

# 检查服务状态
pm2 status assessment-app

# 检查服务是否正常运行
if ss -lntp 2>/dev/null | grep -q ":5000"; then
    echo ""
    echo "=================================="
    echo "部署成功！"
    echo "=================================="
    echo "服务地址: http://47.89.134.217:5000"
    echo "管理后台: http://47.89.134.217:5000/admin/login"
    echo ""
    echo "默认管理员账户："
    echo "  - admin / admin123"
    echo "  - ksq / ksq123"
    echo ""
    echo "PM2 管理命令："
    echo "  pm2 status           - 查看服务状态"
    echo "  pm2 logs assessment-app - 查看日志"
    echo "  pm2 restart assessment-app - 重启服务"
    echo "  pm2 stop assessment-app    - 停止服务"
    echo "=================================="
else
    echo ""
    echo "=================================="
    echo "部署失败！服务未正常启动"
    echo "=================================="
    echo "查看日志: pm2 logs assessment-app"
    echo "=================================="
    exit 1
fi
