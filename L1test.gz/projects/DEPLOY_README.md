# 科学减重生活方式评估系统 - 部署指南

## 项目简介

基于华西医院生活方式评估问卷开发的专业线上生活方式测试系统，提供科学评分和减重建议。

## 服务器信息

- **公网 IP**: 47.89.134.217
- **私有 IP**: 172.19.22.208
- **应用端口**: 5000

## 快速部署（推荐）

### 使用 PM2 部署（推荐用于生产环境）

```bash
# 1. 进入项目目录
cd /workspace/projects

# 2. 赋予脚本执行权限
chmod +x deploy-with-pm2.sh

# 3. 执行部署脚本
./deploy-with-pm2.sh
```

### 使用简单部署脚本

```bash
# 1. 进入项目目录
cd /workspace/projects

# 2. 赋予脚本执行权限
chmod +x deploy.sh

# 3. 执行部署脚本
./deploy.sh
```

### 快速启动（用于测试）

```bash
# 1. 赋予脚本执行权限
chmod +x quick-start.sh

# 2. 执行脚本
./quick-start.sh
```

## 部署后访问

- **主页**: http://47.89.134.217:5000
- **管理后台**: http://47.89.134.217:5000/admin/login

## 默认管理员账户

| 用户名 | 密码 | 说明 |
|--------|------|------|
| admin | admin123 | 默认管理员 |
| ksq | ksq123 | 附加管理员 |

**安全提示**: 生产环境建议修改默认密码。

## 部署文件说明

### 配置文件

- `.env.production` - 生产环境变量配置
- `nginx.conf` - Nginx 反向代理配置
- `ecosystem.config.js` - PM2 进程管理配置
- `assessment-app.service` - Systemd 服务配置

### 部署脚本

- `deploy.sh` - 基础部署脚本（使用 nohup）
- `deploy-with-pm2.sh` - PM2 部署脚本（推荐）
- `quick-start.sh` - 快速启动脚本（用于测试）
- `setup-nginx.sh` - Nginx 安装和配置脚本

### 文档

- `DEPLOYMENT.md` - 详细部署指南
- `DEPLOYMENT_CHECKLIST.md` - 部署检查清单
- `DEPLOY_README.md` - 本文件

## 常用命令

### PM2 管理命令

```bash
# 查看服务状态
pm2 status

# 查看日志
pm2 logs assessment-app

# 重启服务
pm2 restart assessment-app

# 停止服务
pm2 stop assessment-app

# 监控服务
pm2 monit
```

### Nginx 管理命令

```bash
# 重启服务
sudo systemctl restart nginx

# 查看状态
sudo systemctl status nginx

# 查看日志
sudo tail -f /var/log/nginx/assessment-access.log
```

### 应用管理命令

```bash
# 查看端口占用
ss -lntp | grep 5000

# 查看日志
tail -f /tmp/assessment-service.log
```

## 更新部署

```bash
# 1. 拉取最新代码
git pull

# 2. 安装依赖
pnpm install

# 3. 重新构建
npx next build

# 4. 重启服务
pm2 restart assessment-app
```

## 系统要求

- **操作系统**: Ubuntu 20.04/22.04 或其他 Linux 发行版
- **Node.js**: 24.x
- **npm**: 最新版
- **pnpm**: 9.0.0+
- **PM2**: 最新版（推荐）
- **Nginx**: 最新版（可选，用于反向代理）

## 防火墙配置

需要开放以下端口：

- TCP 80 - HTTP（如使用 Nginx）
- TCP 443 - HTTPS（如使用 Nginx）
- TCP 5000 - 应用端口

**阿里云安全组配置**：
在阿里云 ECS 控制台的安全组中，添加入站规则开放上述端口。

## 故障排查

### 服务无法启动

```bash
# 查看日志
pm2 logs assessment-app

# 检查端口占用
ss -lntp | grep 5000

# 检查 Node.js 版本
node --version
```

### 无法访问网站

```bash
# 检查防火墙
sudo ufw status

# 检查服务状态
pm2 status

# 检查端口监听
ss -lntp | grep 5000
```

### 登录失败

```bash
# 测试初始化接口
curl http://localhost:5000/api/admin/init

# 查看日志
pm2 logs assessment-app
```

## 安全建议

1. **修改默认密码**：生产环境务必修改默认管理员密码
2. **使用 HTTPS**：配置 SSL 证书，启用 HTTPS
3. **配置防火墙**：只开放必要的端口
4. **定期更新**：及时更新系统和依赖包
5. **备份策略**：定期备份数据库和配置文件
6. **监控日志**：定期检查应用和系统日志

## 详细文档

- [详细部署指南](DEPLOYMENT.md)
- [部署检查清单](DEPLOYMENT_CHECKLIST.md)

## 技术支持

如有问题，请查看：
- 应用日志：`pm2 logs assessment-app`
- Nginx 日志：`/var/log/nginx/assessment-*.log`
- 系统日志：`/var/log/syslog`

---

**版本**: 1.0.0
**更新日期**: 2025-01-09
