#!/bin/bash

# 阿里云服务器部署脚本
# 服务器信息：公网 IP 47.89.134.217，私有 IP 172.19.22.208

set -e

echo "=================================="
echo "开始部署到阿里云服务器"
echo "=================================="
echo "服务器公网 IP: 47.89.134.217"
echo "服务器私有 IP: 172.19.22.208"
echo "=================================="

# 检查是否在正确的目录
if [ ! -f ".coze" ]; then
    echo "错误：请在项目根目录执行此脚本"
    exit 1
fi

# 设置环境变量
export NODE_ENV=production
export PORT=5000
export DEPLOY_RUN_PORT=5000
export SERVER_PUBLIC_IP=47.89.134.217
export SERVER_PRIVATE_IP=172.19.22.208

echo ""
echo "步骤 1/5: 停止现有服务..."
echo "=================================="
# 停止端口 5000 上的服务
PIDS=$(ss -H -lntp 2>/dev/null | awk -v port="5000" '$4 ~ ":"port"$"' | grep -o 'pid=[0-9]*' | cut -d= -f2 | paste -sd' ' - || true)
if [[ -n "${PIDS}" ]]; then
    echo "停止端口 5000 上的服务: ${PIDS}"
    echo "${PIDS}" | xargs -I {} kill -9 {}
    sleep 2
    echo "服务已停止"
else
    echo "端口 5000 上没有运行的服务"
fi

echo ""
echo "步骤 2/5: 清理旧构建文件..."
echo "=================================="
rm -rf .next
rm -rf node_modules/.cache
echo "清理完成"

echo ""
echo "步骤 3/5: 安装依赖..."
echo "=================================="
pnpm install --prefer-frozen-lockfile --prefer-offline --loglevel=error
echo "依赖安装完成"

echo ""
echo "步骤 4/5: 构建项目..."
echo "=================================="
npx next build
echo "项目构建完成"

echo ""
echo "步骤 5/5: 启动服务..."
echo "=================================="
# 使用 nohup 在后台启动服务
nohup npx next start --port 5000 > /tmp/assessment-service.log 2>&1 &
SERVICE_PID=$!

echo "服务已启动，PID: ${SERVICE_PID}"
echo "日志文件: /tmp/assessment-service.log"

# 等待服务启动
echo "等待服务启动..."
sleep 5

# 检查服务是否正常运行
if ss -lntp 2>/dev/null | grep -q ":5000"; then
    echo ""
    echo "=================================="
    echo "部署成功！"
    echo "=================================="
    echo "服务地址: http://47.89.134.217:5000"
    echo "管理后台: http://47.89.134.217:5000/admin/login"
    echo ""
    echo "默认管理员账户："
    echo "  - admin / admin123"
    echo "  - ksq / ksq123"
    echo ""
    echo "查看日志: tail -f /tmp/assessment-service.log"
    echo "=================================="
else
    echo ""
    echo "=================================="
    echo "部署失败！服务未正常启动"
    echo "=================================="
    echo "查看日志: cat /tmp/assessment-service.log"
    echo "=================================="
    exit 1
fi
