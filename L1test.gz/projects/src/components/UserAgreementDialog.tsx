'use client';

import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface UserAgreementDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultTab?: 'agreement' | 'privacy';
}

export function UserAgreementDialog({ open, onOpenChange, defaultTab = 'agreement' }: UserAgreementDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>用户协议与隐私政策</DialogTitle>
        </DialogHeader>
        <Tabs defaultValue={defaultTab} className="mt-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="agreement">用户协议</TabsTrigger>
            <TabsTrigger value="privacy">隐私政策</TabsTrigger>
          </TabsList>
          
          <TabsContent value="agreement">
            <ScrollArea className="h-[60vh] pr-4">
              <div className="space-y-4 text-sm">
                <section>
                  <h3 className="text-lg font-semibold mb-2">1. 协议的接受</h3>
                  <p className="text-gray-600 leading-relaxed">
                    欢迎使用时悦生活方式评估系统（以下简称"本系统"）。当您使用本系统时，即表示您已阅读、理解并同意接受本协议的所有条款和条件。如果您不同意本协议的任何条款，请立即停止使用本系统。
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">2. 服务说明</h3>
                  <p className="text-gray-600 leading-relaxed">
                    本系统提供生活方式评估服务，包括饮食习惯、运动习惯、睡眠质量、基础健康指标等方面的评估。评估结果基于华西医院减重科生活方式医学评估和循证医学证据，仅供参考，不能替代专业医疗建议。
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">3. 用户义务</h3>
                  <p className="text-gray-600 leading-relaxed mb-2">
                    在使用本系统时，您承诺：
                  </p>
                  <ul className="list-disc list-inside text-gray-600 space-y-1 ml-4">
                    <li>提供真实、准确、完整的信息</li>
                    <li>不得利用本系统进行任何违法或不当活动</li>
                    <li>不得干扰或破坏本系统的正常运行</li>
                    <li>保护个人账户和密码的安全</li>
                  </ul>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">4. 知识产权</h3>
                  <p className="text-gray-600 leading-relaxed">
                    本系统的所有内容，包括但不限于文字、图片、软件、设计、算法等，均受知识产权法保护。未经本系统书面许可，用户不得复制、修改、传播或用于商业用途。
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">5. 免责声明</h3>
                  <p className="text-gray-600 leading-relaxed">
                    本系统提供的评估结果和建议仅供参考，不构成医疗诊断或治疗建议。如有健康问题，请咨询专业医生或医疗机构。本系统不对因使用评估结果而产生的任何直接或间接损失承担责任。
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">6. 服务变更与终止</h3>
                  <p className="text-gray-600 leading-relaxed">
                    本系统有权随时修改或终止服务，无需事先通知用户。用户也可以随时停止使用本系统。
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">7. 争议解决</h3>
                  <p className="text-gray-600 leading-relaxed">
                    因本协议引起的任何争议，双方应友好协商解决。协商不成的，任何一方可向本系统所在地人民法院提起诉讼。
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">8. 协议更新</h3>
                  <p className="text-gray-600 leading-relaxed">
                    本系统有权根据需要修改本协议。修改后的协议一旦公布即代替原协议，恕不另行通知。用户继续使用本系统即表示同意修改后的协议。
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">9. 联系方式</h3>
                  <p className="text-gray-600 leading-relaxed">
                    如对本协议有任何疑问，请通过本系统提供的联系方式与我们联系。
                  </p>
                </section>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="privacy">
            <ScrollArea className="h-[60vh] pr-4">
              <div className="space-y-4 text-sm">
                <section>
                  <h3 className="text-lg font-semibold mb-2">1. 信息收集</h3>
                  <p className="text-gray-600 leading-relaxed mb-2">
                    为了提供评估服务，我们可能收集以下信息：
                  </p>
                  <ul className="list-disc list-inside text-gray-600 space-y-1 ml-4">
                    <li>个人信息：姓名、性别、年龄等</li>
                    <li>健康信息：身高、体重、血压、BMI等</li>
                    <li>生活习惯信息：饮食习惯、运动习惯、睡眠情况等</li>
                    <li>技术信息：IP地址、设备信息、浏览器类型等</li>
                  </ul>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">2. 信息使用</h3>
                  <p className="text-gray-600 leading-relaxed">
                    我们使用收集的信息用于：提供评估服务、改善用户体验、分析系统性能、发送服务通知、维护系统安全等。我们不会将您的个人信息出售、出租或转让给第三方。
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">3. 信息共享</h3>
                  <p className="text-gray-600 leading-relaxed">
                    除以下情况外，我们不会与第三方共享您的个人信息：
                  </p>
                  <ul className="list-disc list-inside text-gray-600 space-y-1 ml-4">
                    <li>获得您的明确同意</li>
                    <li>法律法规要求或政府部门要求</li>
                    <li>为保护我们的合法权益</li>
                    <li>与可信的第三方服务提供商共享（限于提供服务的必要范围）</li>
                  </ul>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">4. 信息存储与安全</h3>
                  <p className="text-gray-600 leading-relaxed">
                    我们采取合理的技术措施和管理措施保护您的个人信息安全，包括数据加密、访问控制、安全审计等。但请注意，任何互联网传输都存在风险，我们无法保证绝对安全。
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">5. Cookie 使用</h3>
                  <p className="text-gray-600 leading-relaxed">
                    我们可能使用 Cookie 和类似技术来改善用户体验、分析访问数据。您可以通过浏览器设置管理 Cookie，但这可能影响某些功能的正常使用。
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">6. 用户权利</h3>
                  <p className="text-gray-600 leading-relaxed mb-2">
                    根据相关法律法规，您享有以下权利：
                  </p>
                  <ul className="list-disc list-inside text-gray-600 space-y-1 ml-4">
                    <li>查询、复制您的个人信息</li>
                    <li>更正、补充您的个人信息</li>
                    <li>删除您的个人信息</li>
                    <li>撤回您的授权同意</li>
                    <li>注销账户</li>
                  </ul>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">7. 未成年人保护</h3>
                  <p className="text-gray-600 leading-relaxed">
                    本系统主要面向成年人。如果您是未成年人，请在监护人陪同下使用本系统。我们不会故意收集未成年人的个人信息。
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">8. 数据保留</h3>
                  <p className="text-gray-600 leading-relaxed">
                    我们仅在为实现收集目的所必需的期间保留您的个人信息。当您注销账户或我们停止服务时，我们将删除或匿名化处理您的个人信息。
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">9. 隐私政策更新</h3>
                  <p className="text-gray-600 leading-relaxed">
                    我们可能不时更新本隐私政策。更新后的政策将在本系统上公布，请您定期查看。您继续使用本系统即表示同意更新后的隐私政策。
                  </p>
                </section>

                <section>
                  <h3 className="text-lg font-semibold mb-2">10. 联系我们</h3>
                  <p className="text-gray-600 leading-relaxed">
                    如对本隐私政策有任何疑问或需要行使您的权利，请通过本系统提供的联系方式与我们联系。我们将在收到您的请求后及时回复。
                  </p>
                </section>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
