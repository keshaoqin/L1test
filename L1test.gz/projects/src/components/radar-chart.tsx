'use client';

import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Legend } from 'recharts';

interface RadarChartProps {
  data: {
    subject: string;
    score: number;
    fullScore: number;
  }[];
}

export function HealthRadarChart({ data }: RadarChartProps) {
  // 将分数转换为相对于满分的百分比（0-100）
  const normalizedData = data.map(item => ({
    subject: item.subject,
    score: Math.round((item.score / item.fullScore) * 100),
    fullScore: 100
  }));

  // 维度颜色（与下方文字颜色一致）
  const dimensionColors = [
    '#16a34a', // 饮食 - 绿色
    '#ea580c', // 运动 - 橙色
    '#9333ea', // 睡眠 - 紫色
    '#dc2626', // 基础健康 - 红色
    '#2563eb', // 风险控制 - 蓝色
  ];

  return (
    <div className="w-full h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={normalizedData}>
          <PolarGrid stroke="#e5e7eb" strokeWidth={1} />
          <PolarAngleAxis
            dataKey="subject"
            className="text-sm font-medium"
            tick={{ fontSize: 12, fill: '#374151' }}
          />
          <PolarRadiusAxis
            angle={0}
            domain={[0, 100]}
            tick={{ fontSize: 10, fill: '#6b7280' }}
            tickFormatter={(value) => `${value}%`}
          />
          
          {/* 单个Radar，使用默认颜色 */}
          <Radar
            name="健康得分"
            dataKey="score"
            stroke="#2563eb"
            fill="#2563eb"
            fillOpacity={0.3}
            strokeWidth={2}
            dot={{ 
              r: 5, 
              fill: '#2563eb',
              strokeWidth: 2,
              stroke: '#ffffff'
            }}
            isAnimationActive={false}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
