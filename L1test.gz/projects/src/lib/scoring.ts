import { AssessmentRequest, AssessmentResult } from '@/types/assessment';

/**
 * 华西医院生活方式评估 - 评分系统
 * 基于生活方式医学的循证依据设计
 */
export class AssessmentScorer {
  private request: AssessmentRequest;

  constructor(request: AssessmentRequest) {
    this.request = request;
  }

  /**
   * 计算BMI
   */
  private calculateBMI(): number | null {
    const { height, weight } = this.request.enrollmentInfo;
    if (!height || !weight) return null;
    const heightInMeters = height / 100;
    return Number((weight / (heightInMeters * heightInMeters)).toFixed(1));
  }

  /**
   * 获取BMI分类
   */
  private getBMICategory(bmi: number | null): 'underweight' | 'normal' | 'overweight' | 'obesity' {
    if (!bmi) return 'normal';
    if (bmi < 18.5) return 'underweight';
    if (bmi < 24) return 'normal';
    if (bmi < 28) return 'overweight';
    return 'obesity';
  }

  /**
   * 获取腰围分类
   * 男性: <85cm 正常, 85-90cm 高风险, ≥90cm 极高风险
   * 女性: <80cm 正常, 80-85cm 高风险, ≥85cm 极高风险
   */
  private getWaistlineCategory(waistline: number | undefined, gender: 'male' | 'female'): 'normal' | 'highRisk' | 'veryHighRisk' {
    if (!waistline) return 'normal';

    const threshold = gender === 'male' ? 85 : 80;
    const highRiskThreshold = gender === 'male' ? 90 : 85;

    if (waistline < threshold) return 'normal';
    if (waistline < highRiskThreshold) return 'highRisk';
    return 'veryHighRisk';
  }

  /**
   * 评分 - 饮食习惯 (40分)
   */
  private scoreDiet(): number {
    const { dietAssessment } = this.request;
    let score = 0;

    // 1. 食物选择与搭配 (15分)
    // 主食类型 (3分)
    score += dietAssessment.foodSelection.stapleFood === 'mixed' ? 3 : 0;

    // 蛋白质来源 (3分)
    if (dietAssessment.foodSelection.proteinSource === 'balanced') score += 3;
    else if (dietAssessment.foodSelection.proteinSource === 'simple') score += 1;

    // 加工肉偏好 (2分)
    score += !dietAssessment.foodSelection.processedMeatPreference ? 2 : 0;

    // 蔬果摄入 (4分, 每项1分)
    const { fruitVegetableIntake } = dietAssessment;
    if (fruitVegetableIntake.vegetable300gOrMore) score += 1;
    if (fruitVegetableIntake.darkVegetableRatio > 50) score += 1;
    if (fruitVegetableIntake.fruit200gOrMore) score += 1;
    if (!fruitVegetableIntake.juiceInsteadOfFruit && !fruitVegetableIntake.cannedPickledFruitsAndVegetables) score += 1;

    // 油脂与调味 (3分)
    const { oilAndSeasoning } = dietAssessment;
    if (oilAndSeasoning.cookingOilType === 'vegetable') score += 1;
    
    let seasoningScore = 0;
    if (!oilAndSeasoning.oilIntakeExceeded) seasoningScore++;
    if (!oilAndSeasoning.saltIntakeExceeded) seasoningScore++;
    if (!oilAndSeasoning.sugarIntakeExceeded) seasoningScore++;
    score += seasoningScore === 3 ? 2 : (seasoningScore >= 2 ? 1 : 0);

    // 2. 进餐习惯 (10分)
    // 进餐速度 (3分)
    const eatingSpeedScores: any = { normal: 3, slow: 2, fast: 1, veryFast: 0 };
    score += dietAssessment.eatingSpeed ? eatingSpeedScores[dietAssessment.eatingSpeed] || 0 : 0;

    // 三餐规律性 (4分)
    const { mealRegularity } = dietAssessment;
    if (mealRegularity && mealRegularity.breakfastFrequency && mealRegularity.dinnerTime && mealRegularity.midnightSnackFrequency) {
      if (mealRegularity.breakfastFrequency === 'daily' &&
          mealRegularity.dinnerTime === '≤19:00' &&
          mealRegularity.midnightSnackFrequency === 'none') {
        score += 4;
      } else if (mealRegularity.breakfastFrequency === 'daily' &&
                 (mealRegularity.dinnerTime === '≤19:00' || mealRegularity.dinnerTime === '19:00-21:00') &&
                 mealRegularity.midnightSnackFrequency !== '≥3times') {
        score += 3;
      } else if (mealRegularity.breakfastFrequency === '5-6days' && mealRegularity.dinnerTime !== '≥21:00') {
        score += 2;
      }
    }

    // 饮水量 (2分)
    const waterScores: any = { '>2L': 2, '1-2L': 1, '<1L': 0, 'sugaryDrinks': 0 };
    score += dietAssessment.dailyWaterIntake ? waterScores[dietAssessment.dailyWaterIntake] || 0 : 0;

    // 外食频率 (1分)
    if (dietAssessment.eatingOut && dietAssessment.eatingOut.frequency && (dietAssessment.eatingOut.frequency === '0times' || dietAssessment.eatingOut.frequency === '1-3times')) {
      score += 1;
    }

    // 3. 烹饪方式 (7分)
    const cookingScores: any = { steamingBoiling: 7, coldDish: 6, stirFrying: 5, frying: 2 };
    score += dietAssessment.cookingMethodPreference ? cookingScores[dietAssessment.cookingMethodPreference] || 0 : 0;

    // 4. 代餐使用 (2分)
    if (!dietAssessment.mealReplacement.isUsing) score += 2;

    // 5. 饮食禁忌 (2分)
    if (!dietAssessment.foodAllergyOrTaboo.hasTaboo) score += 2;

    // 6. 饮食偏好扣分（专业营养学角度）
    // 基于循证医学证据，不同的饮食偏好对体重管理和健康的影响程度不同
    const badHabits = dietAssessment.dietaryPreferences || [];
    if (dietAssessment.dietaryPreferencesNone) {
      // 用户选择"无以上偏好"，不扣分
    } else if (badHabits.length > 0) {
      // 暴饮暴食：严重影响代谢节律，容易导致热量过剩
      if (badHabits.includes('暴饮暴食')) score -= 3;
      // 饮食不规律：严重影响血糖稳定和代谢功能
      if (badHabits.includes('饮食不规律')) score -= 3;
      // 偏好甜食：增加额外热量摄入，导致血糖大幅波动
      if (badHabits.includes('偏好甜食')) score -= 2;
      // 偏好油炸食物：高脂肪高热量，增加心血管风险
      if (badHabits.includes('偏好油炸食物')) score -= 2;
    }

    return Math.max(0, Math.min(40, score));
  }

  /**
   * 评分 - 运动习惯 (25分)
   */
  private scoreExercise(): number {
    const { exerciseAssessment } = this.request;

    // 1. 计算每日步数得分（满分10分）
    let stepsScore = 0;
    switch (exerciseAssessment.dailySteps) {
      case '>9000':
        stepsScore = 10;
        break;
      case '6000-9000':
        stepsScore = 8;
        break;
      case '3000-6000':
        stepsScore = 5;
        break;
      case '<3000':
        stepsScore = 2;
        break;
      default:
        stepsScore = 0;
    }

    // 2. 计算运动量得分（满分15分）
    const aerobicMinutes = (exerciseAssessment.aerobicExercise.frequency || 0) * (exerciseAssessment.aerobicExercise.duration || 0);
    const resistanceMinutes = (exerciseAssessment.resistanceExercise?.frequency || 0) * (exerciseAssessment.resistanceExercise?.duration || 0);
    const flexibilityMinutes = (exerciseAssessment.flexibilityTraining?.frequency || 0) * (exerciseAssessment.flexibilityTraining?.duration || 0);

    const totalExerciseMinutes = aerobicMinutes + resistanceMinutes + flexibilityMinutes;

    let exerciseScore = 0;
    if (totalExerciseMinutes >= 150) {
      exerciseScore = 15; // 100%
    } else if (totalExerciseMinutes >= 120) {
      exerciseScore = 12; // 80%
    } else if (totalExerciseMinutes >= 90) {
      exerciseScore = 9; // 60%
    } else if (totalExerciseMinutes >= 60) {
      exerciseScore = 6; // 40%
    } else if (totalExerciseMinutes >= 30) {
      exerciseScore = 3; // 20%
    } else {
      exerciseScore = 0;
    }

    // 总分 = 步数得分 + 运动量得分（满分25分）
    return Math.min(25, stepsScore + exerciseScore);
  }

  /**
   * 评分 - 睡眠质量 (15分)
   */
  private scoreSleep(): number {
    const { sleepAssessment } = this.request;
    let score = 0;

    // 基础分数 - 睡眠时长（10分）
    const hours = sleepAssessment.sleepHours;
    if (!hours) {
      // 用户未选择睡眠时长，不评分
    } else if (hours === '7-9hours') {
      score += 10; // 理想时长
    } else if (hours === '>9hours') {
      score += 6; // 睡眠过长
    } else if (hours === '5-7hours') {
      score += 5; // 睡眠略不足
    } else {
      score += 2; // 睡眠严重不足
    }

    // 规律性 (3分)
    if (sleepAssessment.bedtime && sleepAssessment.bedtime.trim().length > 0) {
      const bedtime = parseInt(sleepAssessment.bedtime.split(':')[0]);
      if (!isNaN(bedtime)) {
        if (bedtime >= 22 && bedtime <= 23) score += 3;
        else if (bedtime >= 21 && bedtime <= 24) score += 2;
        else if (bedtime >= 0 && bedtime <= 2) score += 1;
      }
    }

    // 睡眠质量 (2分)
    if (sleepAssessment.daytimeEnergy) {
      if (!sleepAssessment.snoring && !sleepAssessment.sleepAidOrCPAP && sleepAssessment.daytimeEnergy === 'energetic') {
        score += 2;
      } else if (sleepAssessment.snoring && !sleepAssessment.sleepAidOrCPAP) {
        score += 1;
      }
    }

    return score;
  }

  /**
   * 评分 - 基础健康指标 (10分)
   */
  private scoreBasicHealth(): number {
    const bmi = this.calculateBMI();
    const { height, weight, waistline, bloodPressurePulseUnknown } = this.request.enrollmentInfo;
    const { gender } = this.request.generalInfo;

    let score = 0;
    let scoreWeight = 0;
    let totalWeight = 0;

    // BMI评分 (5分) - 如果有身高体重数据
    if (height && weight && bmi !== null) {
      totalWeight += 5;
      if (bmi >= 18.5 && bmi < 24) score += 5;
      else if (bmi >= 24 && bmi < 28) score += 3;
      else if (bmi >= 28) score += 0;
      else score += 4; // 偏瘦
      scoreWeight += 5;
    }

    // 腰围评分 (2.5分) - 如果有腰围数据
    if (waistline) {
      totalWeight += 2.5;
      const waistlineCategory = this.getWaistlineCategory(waistline, gender);
      if (waistlineCategory === 'normal') score += 2.5;
      else if (waistlineCategory === 'highRisk') score += 1.5;
      else score += 0;
      scoreWeight += 2.5;
    }

    // 血压脉搏评分 (2.5分) - 如果有数据且用户知道
    if (!bloodPressurePulseUnknown && this.request.enrollmentInfo.systolicBloodPressure && this.request.enrollmentInfo.diastolicBloodPressure) {
      totalWeight += 2.5;
      const sbp = this.request.enrollmentInfo.systolicBloodPressure;
      const dbp = this.request.enrollmentInfo.diastolicBloodPressure;
      if (sbp < 120 && dbp < 80) score += 2.5;
      else if (sbp < 140 && dbp < 90) score += 2;
      else if (sbp < 160 && dbp < 100) score += 1;
      else score += 0.5;
      scoreWeight += 2.5;
    }

    // 如果所有数据都没有，给予中性分
    if (totalWeight === 0) return 5;

    // 按数据完整度加权计算
    return scoreWeight > 0 ? Math.round((score / scoreWeight) * 5) : 5;
  }

  /**
   * 评分 - 危险因素 (10分)
   * 基于生活方式医学的循证依据：吸烟和过量饮酒是心血管疾病、代谢疾病的主要危险因素
   */
  private scoreRiskFactors(): number {
    const { generalInfo } = this.request;
    let score = 0;

    // 吸烟评估 (5分)
    // 科学依据：吸烟是心血管疾病、肺癌、慢性阻塞性肺病的主要危险因素
    const smoking = generalInfo.smoking;
    if (!smoking.isSmoking) {
      // 不吸烟：最佳
      score += 5;
    } else {
      // 吸烟：根据吸烟量评分
      const cigarettesPerDay = smoking.cigarettesPerDay || 0;
      if (cigarettesPerDay < 10) {
        score += 1;  // 轻度吸烟，有一定风险
      } else {
        score += 0;  // 重度吸烟，高风险
      }
    }

    // 喝酒评估 (5分)
    // 科学依据：过量饮酒导致肝脏损伤、高血压、代谢异常、认知功能下降
    // 酒精摄入量标准：男性≤25g/天，女性≤15g/天
    const drinking = generalInfo.drinking;
    if (!drinking.isDrinking) {
      // 不喝酒：最佳
      score += 5;
    } else {
      // 喝酒：根据酒精摄入量评分
      const gramsPerDay = drinking.gramsOfAlcoholPerDay || 0;
      if (gramsPerDay < 20) {
        score += 3;  // 少量饮酒，低风险（但仍有健康影响）
      } else if (gramsPerDay <= 50) {
        score += 1;  // 中度饮酒，中风险
      } else {
        score += 0;  // 重度饮酒，高风险
      }
    }

    return score;
  }

  /**
   * 生成分析内容
   */
  private generateAnalysis(dietScore: number, exerciseScore: number, sleepScore: number, basicHealthScore: number, riskFactorsScore: number) {
    const bmi = this.calculateBMI();
    const bmiCategory = bmi ? this.getBMICategory(bmi) : 'normal';
    const { waistline } = this.request.enrollmentInfo;
    const waistlineCategory = waistline ? this.getWaistlineCategory(waistline, this.request.generalInfo.gender) : 'normal';
    const { medicalHistory } = this.request;

    // 总体评价
    let overall = '';
    const totalScore = dietScore + exerciseScore + sleepScore + basicHealthScore + riskFactorsScore;
    
    if (totalScore >= 85) {
      overall = '您的生活方式非常健康！饮食习惯良好，运动规律，睡眠质量高。继续保持这种健康的生活方式，您的身体状况将处于最佳状态。';
    } else if (totalScore >= 70) {
      overall = '您的生活方式较健康，但在某些方面仍有改进空间。通过针对性地调整，您可以进一步提升健康水平，更好地管理体重。';
    } else if (totalScore >= 55) {
      overall = '您的生活方式一般，存在一些不良习惯。这些习惯可能正在影响您的健康和体重管理效果。建议您重点关注饮食和运动习惯的改善。';
    } else if (totalScore >= 40) {
      overall = '您的生活方式较差，存在较多不健康的行为模式。这可能导致代谢异常和体重问题。强烈建议您立即开始调整生活方式，循序渐进地改善。';
    } else {
      overall = '您的生活方式存在较多问题，已严重影响健康。建议在医生或专业营养师的指导下，制定系统性的改善计划，并严格执行。';
    }

    // 饮食分析
    let diet = '';
    if (dietScore >= 32) {
      diet = '饮食习惯非常好：食物种类丰富、搭配均衡，三餐规律，烹饪方式健康。';
    } else if (dietScore >= 24) {
      diet = '饮食习惯较好：大部分方面健康，但仍有可改进之处，如增加蔬果摄入、减少精制主食等。';
    } else if (dietScore >= 16) {
      diet = '饮食习惯一般：存在一些问题，如进餐速度过快、外食过多、偏好高热量食物等，需要针对性调整。';
    } else {
      diet = '饮食习惯较差：存在多个不良饮食习惯，如高油高盐、暴饮暴食、饮食不规律等，严重影响健康和体重管理。';
    }

    // 运动分析
    let exercise = '';
    if (exerciseScore >= 20) {
      exercise = '运动习惯非常优秀：有氧、抗阻、柔韧性训练均衡，达到或超过了世界卫生组织的推荐标准。';
    } else if (exerciseScore >= 15) {
      exercise = '运动习惯较好：有一定运动基础，但强度或频率还可进一步提升，建议增加抗阻训练。';
    } else if (exerciseScore >= 10) {
      exercise = '运动习惯一般：运动量不足，建议逐步增加运动时间和强度，培养规律运动的习惯。';
    } else {
      exercise = '运动习惯较差：运动严重不足，缺乏规律性的身体活动。这是代谢性疾病的重要风险因素。';
    }

    // 睡眠分析
    let sleep = '';
    const sleepHours = this.request.sleepAssessment.sleepHours;

    if (sleepHours === '7-9hours') {
      sleep = '睡眠时长非常理想：7-9小时的睡眠能够充分满足身体修复和代谢需求，有助于维持正常的激素水平。';
    } else if (sleepHours === '>9hours') {
      sleep = '睡眠时间偏长：过长的睡眠可能与代谢异常相关，建议控制在7-9小时范围内。';
    } else if (sleepHours === '5-7hours') {
      sleep = '睡眠时间略不足：5-7小时的睡眠可能无法完全满足身体需求，长期可能影响代谢和激素平衡。';
    } else {
      sleep = '睡眠时间严重不足：少于5小时的睡眠会显著增加食欲、降低代谢率，严重影响健康和体重管理。';
    }

    // 添加睡眠规律性和质量信息
    if (sleepScore >= 12) {
      sleep += '睡眠规律性和质量都很优秀。';
    } else if (sleepScore >= 9) {
      sleep += '睡眠质量良好，但在规律性方面还有改进空间。';
    } else if (sleepScore >= 6) {
      sleep += '睡眠质量一般，建议改善睡眠规律性和质量。';
    } else {
      sleep += '睡眠质量较差，存在明显的睡眠问题，建议及时就医检查。';
    }

    // 健康风险
    const healthRisks: string[] = [];
    if (bmiCategory === 'overweight' || bmiCategory === 'obesity') {
      healthRisks.push('超重或肥胖会增加心血管疾病、糖尿病等慢性病的风险');
    }
    if (waistlineCategory === 'highRisk' || waistlineCategory === 'veryHighRisk') {
      healthRisks.push('腰围超标提示腹部脂肪堆积，增加代谢综合征风险');
    }
    if (medicalHistory.hypertension || medicalHistory.coronaryHeartDisease) {
      healthRisks.push('既往心血管病史需要特别关注生活方式管理');
    }
    if (medicalHistory.highBloodSugar || medicalHistory.diabetes) {
      healthRisks.push('糖代谢异常需要严格控制饮食和规律运动');
    }
    if (medicalHistory.fattyLiver) {
      healthRisks.push('脂肪肝需要通过减重、饮食控制和运动改善');
    }
    if (this.request.generalInfo.smoking.isSmoking) {
      healthRisks.push('吸烟会显著增加心血管疾病和多种癌症的风险');
    }
    if (sleepScore < 9) {
      healthRisks.push('睡眠不足会增加食欲、降低代谢率，不利于体重管理');
    }
    if (exerciseScore < 15) {
      healthRisks.push('运动不足会导致肌肉流失、基础代谢率下降，易形成恶性循环');
    }

    return { overall, diet, exercise, sleep, healthRisks };
  }

  /**
   * 生成建议
   */
  private generateRecommendations() {
    const { dietAssessment, exerciseAssessment, sleepAssessment } = this.request;
    const bmi = this.calculateBMI();
    const bmiCategory = bmi ? this.getBMICategory(bmi) : 'normal';

    const recommendations = {
      diet: [] as string[],
      exercise: [] as string[],
      sleep: [] as string[],
      healthMonitoring: [] as string[],
      psychologicalSupport: [] as string[]
    };

    // 饮食建议
    if (dietAssessment.foodSelection.stapleFood === 'refined') {
      recommendations.diet.push('将精制米面逐步替换为全谷物（燕麦、糙米、全麦等），建议每天主食中粗粮占30-50%');
    }
    if (dietAssessment.foodSelection.proteinSource !== 'balanced') {
      recommendations.diet.push('优化蛋白质来源：增加鱼类、禽类、豆制品、蛋奶的比例，减少畜肉摄入');
    }
    if (!dietAssessment.fruitVegetableIntake.vegetable300gOrMore) {
      recommendations.diet.push('增加蔬菜摄入量至每天≥300g，其中深色蔬菜占一半以上');
    }
    if (!dietAssessment.fruitVegetableIntake.fruit200gOrMore) {
      recommendations.diet.push('每天摄入200-350g新鲜水果，选择低糖水果（如苹果、浆果等）');
    }
    if (dietAssessment.fruitVegetableIntake.juiceInsteadOfFruit) {
      recommendations.diet.push('停止用果汁替代水果，果汁缺乏纤维素，容易导致血糖快速升高');
    }
    if (dietAssessment.oilAndSeasoning.oilIntakeExceeded) {
      recommendations.diet.push('控制每日烹调油摄入在25-30g，选用橄榄油、亚麻籽油等健康油脂');
    }
    if (dietAssessment.oilAndSeasoning.saltIntakeExceeded) {
      recommendations.diet.push('限制每日盐摄入≤5g（约一啤酒瓶盖），减少腌制食品和加工食品');
    }
    if (dietAssessment.eatingSpeed === 'veryFast' || dietAssessment.eatingSpeed === 'fast') {
      recommendations.diet.push('放慢进餐速度，每餐用时≥15分钟，细嚼慢咽有助于增加饱腹感');
    }
    if (dietAssessment.mealRegularity && dietAssessment.mealRegularity.breakfastFrequency !== 'daily') {
      recommendations.diet.push('养成每天吃早餐的习惯，早餐应包含优质蛋白和复合碳水化合物');
    }
    if (dietAssessment.mealRegularity && dietAssessment.mealRegularity.dinnerTime === '≥21:00') {
      recommendations.diet.push('调整晚餐时间至19:00前，给身体足够时间消化');
    }
    if (dietAssessment.mealRegularity && dietAssessment.mealRegularity.midnightSnackFrequency !== 'none') {
      recommendations.diet.push('停止吃夜宵，如果晚上饥饿可少量饮用低脂牛奶或无糖酸奶');
    }
    if (dietAssessment.eatingOut && (dietAssessment.eatingOut.frequency === 'daily' || dietAssessment.eatingOut.frequency === '4-6times')) {
      recommendations.diet.push('减少外食频率，自己做饭可以更好地控制油盐量，选择蒸煮凉拌等健康烹饪方式');
    }
    if (dietAssessment.cookingMethodPreference === 'frying') {
      recommendations.diet.push('减少油炸食物，改用蒸、煮、炖、凉拌等低油烹饪方式');
    }
    if (dietAssessment.dailyWaterIntake === 'sugaryDrinks' || dietAssessment.dailyWaterIntake === '<1L') {
      recommendations.diet.push('戒除含糖饮料，每日饮水1.5-2L，可适量饮用茶或无糖咖啡');
    }
    if (!dietAssessment.dietaryPreferencesNone && dietAssessment.dietaryPreferences.includes('暴饮暴食')) {
      recommendations.diet.push('控制暴饮暴食，采用少食多餐，每餐七八分饱，避免过度饥饿后暴食');
    }

    // 运动建议
    recommendations.exercise.push('增加有氧运动至每周3～4次，每次≥30分钟（如快走、跑步、游泳、骑行等）');
    recommendations.exercise.push('增加抗阻训练至每周2～3次，每次10～20分钟（如举重、弹力带训练、深蹲、俯卧撑等）');
    recommendations.exercise.push('每周进行2～3次柔韧性训练，如瑜伽、普拉提或拉伸练习，每次10～15分钟');
    recommendations.exercise.push('运动强度应达到中等强度（心率=(220-年龄)×60-70%）');
    recommendations.exercise.push('运动前后做好热身和拉伸，预防运动损伤');
    recommendations.exercise.push('循序渐进增加运动量，避免一次性过度运动导致放弃');

    // 睡眠建议
    if (sleepAssessment.sleepHours === '<5hours') {
      recommendations.sleep.push('您的睡眠时间严重不足，建议优先延长睡眠至至少7小时。睡眠不足会降低基础代谢率、增加食欲，严重影响健康');
    } else if (sleepAssessment.sleepHours === '5-7hours') {
      recommendations.sleep.push('您的睡眠时间略不足，建议延长至7-9小时。充足的睡眠有助于维持正常的代谢功能');
    } else if (sleepAssessment.sleepHours === '>9hours') {
      recommendations.sleep.push('您的睡眠时间偏长，建议控制在7-9小时范围内。过长的睡眠可能与代谢异常相关');
    } else {
      recommendations.sleep.push('您的睡眠时间非常理想，继续保持7-9小时的睡眠习惯');
    }

    const bedtime = parseInt(sleepAssessment.bedtime.split(':')[0]);
    if (bedtime > 23 || bedtime < 22) {
      recommendations.sleep.push('调整作息，建议22:00-23:00入睡，23:00-7:00是最佳睡眠时段');
    }
    if (sleepAssessment.snoring) {
      recommendations.sleep.push('打鼾可能提示睡眠呼吸暂停，建议到呼吸科做睡眠监测检查');
    }
    if (sleepAssessment.daytimeEnergy === 'tired') {
      recommendations.sleep.push('白天精力不足可能与睡眠质量有关，建议规律作息，睡前避免使用电子设备');
    }
    recommendations.sleep.push('睡前1小时避免进食、剧烈运动和刺激内容，可进行放松活动（如听音乐、冥想）');

    // 危险因素建议（吸烟喝酒）
    if (this.request.generalInfo.smoking.isSmoking) {
      const cigarettesPerDay = this.request.generalInfo.smoking.cigarettesPerDay || 0;
      if (cigarettesPerDay < 10) {
        recommendations.healthMonitoring.push('建议逐步减少吸烟量，制定戒烟计划。即使是轻度吸烟也会显著增加心血管疾病和肺癌风险');
      } else {
        recommendations.healthMonitoring.push('您的吸烟量较大，强烈建议立即戒烟。吸烟是导致慢性阻塞性肺病、冠心病、脑卒中等疾病的主要危险因素');
      }
      recommendations.healthMonitoring.push('戒烟建议：设定戒烟日、寻求家人支持、使用尼古丁替代疗法、必要时咨询戒烟门诊');
    } else {
      recommendations.healthMonitoring.push('您不吸烟，这非常好。继续保持，避免二手烟暴露');
    }

    if (this.request.generalInfo.drinking.isDrinking) {
      const gramsPerDay = this.request.generalInfo.drinking.gramsOfAlcoholPerDay || 0;
      if (gramsPerDay < 20) {
        recommendations.healthMonitoring.push('您有少量饮酒习惯，建议控制在每周不超过100g酒精（约2瓶啤酒或2杯红酒）。即使少量饮酒也存在健康风险');
      } else if (gramsPerDay <= 50) {
        recommendations.healthMonitoring.push('您有中度饮酒习惯，建议逐步减少。过量饮酒会导致脂肪肝、高血压、胰腺炎等疾病');
      } else {
        recommendations.healthMonitoring.push('您的饮酒量较大，严重影响健康。建议立即戒酒或大幅减少摄入量，必要时寻求专业戒酒帮助');
      }
    } else {
      recommendations.healthMonitoring.push('您不喝酒，这非常好。继续保持');
    }

    // 健康监测建议
    recommendations.healthMonitoring.push('每周测量体重，固定时间（如早晨起床后）并记录');
    recommendations.healthMonitoring.push('每月测量腰围，男性目标<90cm，女性目标<85cm');
    if ((this.request.enrollmentInfo.systolicBloodPressure || 0) > 140 || (this.request.enrollmentInfo.diastolicBloodPressure || 0) > 90) {
      recommendations.healthMonitoring.push('血压偏高，建议每日监测血压，必要时就医调整用药');
    }
    if (this.request.medicalHistory.highBloodSugar || this.request.medicalHistory.diabetes) {
      recommendations.healthMonitoring.push('定期监测空腹血糖和糖化血红蛋白，必要时监测餐后血糖');
    }
    if (this.request.medicalHistory.hyperlipidemia) {
      recommendations.healthMonitoring.push('定期检查血脂水平，控制低密度脂蛋白胆固醇');
    }
    recommendations.healthMonitoring.push('每年进行一次全面的体检，评估健康状况');

    // 心理支持建议
    const determination = this.request.enrollmentInfo.weightLossDetermination;
    if (determination === 'low' || determination === 'medium') {
      recommendations.psychologicalSupport.push('提高减重决心是成功的关键，建议明确减重目标，找到内在驱动力');
    }
    recommendations.psychologicalSupport.push('设定可实现的小目标，逐步积累成就感，避免因目标过高而挫败');
    recommendations.psychologicalSupport.push('培养健康的生活方式和兴趣，将减重融入生活而非单纯的任务');
    recommendations.psychologicalSupport.push('建立社会支持系统，与家人朋友分享减重计划，获得鼓励和监督');
    recommendations.psychologicalSupport.push('学会应对压力和情绪，避免情绪性进食，必要时寻求专业心理咨询');
    recommendations.psychologicalSupport.push('保持积极心态，接受偶尔的失误，及时调整而非放弃');

    // 如果建议太少，添加通用建议
    if (recommendations.diet.length < 3) {
      recommendations.diet.push('继续保持当前健康的饮食习惯');
    }
    if (recommendations.exercise.length < 3) {
      recommendations.exercise.push('继续保持当前的运动习惯，可适当增加强度和多样性');
    }
    if (recommendations.sleep.length < 3) {
      recommendations.sleep.push('继续保持良好的睡眠习惯');
    }

    return recommendations;
  }

  /**
   * 计算目标热量（基于基础代谢率和活动水平）
   */
  private calculateTargetCalories(): number {
    const { height, weight } = this.request.enrollmentInfo;
    const { age, gender } = this.request.generalInfo;

    // 如果缺少必要数据，返回估算值
    if (!height || !weight || !age) {
      return 1800; // 默认值
    }
    
    // Mifflin-St Jeor公式计算基础代谢率
    let bmr: number;
    if (gender === 'male') {
      bmr = 10 * weight + 6.25 * height - 5 * age + 5;
    } else {
      bmr = 10 * weight + 6.25 * height - 5 * age - 161;
    }

    // 活动系数（基于运动评估）
    const { exerciseAssessment } = this.request;
    const totalExerciseMinutes =
      (exerciseAssessment.aerobicExercise.frequency || 0) * (exerciseAssessment.aerobicExercise.duration || 0) +
      (exerciseAssessment.resistanceExercise?.frequency || 0) * (exerciseAssessment.resistanceExercise?.duration || 0);
    
    let activityFactor = 1.2; // 久坐
    if (totalExerciseMinutes >= 300) {
      activityFactor = 1.725; // 高强度运动
    } else if (totalExerciseMinutes >= 150) {
      activityFactor = 1.55; // 中度运动
    } else if (totalExerciseMinutes >= 60) {
      activityFactor = 1.375; // 轻度运动
    }

    const totalEnergyExpenditure = bmr * activityFactor;
    
    // 减重目标热量（减少20%）
    return Math.round(totalEnergyExpenditure * 0.8);
  }

  /**
   * 生成行动计划
   */
  private generateActionPlan() {
    const { exerciseAssessment } = this.request;
    const bmi = this.calculateBMI();

    // 判断用户当前运动水平
    const aerobicMinutes = (exerciseAssessment.aerobicExercise.frequency || 0) * (exerciseAssessment.aerobicExercise.duration || 0);
    const resistanceMinutes = (exerciseAssessment.resistanceExercise?.frequency || 0) * (exerciseAssessment.resistanceExercise?.duration || 0);

    return {
      oneMonth: [
        '建立规律作息时间',
        '记录每日饮食和运动情况，了解自身习惯',
        '开始每天饮用足够的水（1.5-2L）',
        aerobicMinutes < 90 ? '逐步增加有氧运动，从每次20-30分钟开始，每周2-3次' : '保持当前运动习惯，适当增加强度',
        '学习识别健康和不健康食物，建立健康饮食观念',
        '与家人朋友分享减重计划，获得支持'
      ],
      threeMonths: [
        '调整饮食结构，逐步用全谷物替代部分精制主食',
        '规律进行有氧运动，每周3-4次，每次30分钟左右',
        '加入抗阻训练，每周2-3次，每次10-20分钟',
        '减少外食频率，尽量自己烹饪健康餐食',
        '设定合理的体重下降目标，一般每月下降2-4kg为宜',
        '关注身体指标变化，如体重、腰围等'
      ],
      sixMonths: [
        '巩固健康饮食习惯，形成自然的生活方式',
        '建立多元化的运动体系，包含有氧、抗阻、柔韧性训练',
        '根据身体状况调整减重目标，逐步接近理想体重',
        '关注腰围变化，目标：男性<90cm，女性<85cm',
        '定期监测身体指标，关注代谢健康改善情况',
        '将健康的生活方式长期坚持下去，形成良性循环'
      ]
    };
  }

  /**
   * 执行完整评分
   */
  public score(): AssessmentResult {
    const dietScore = this.scoreDiet();
    const exerciseScore = this.scoreExercise();
    const sleepScore = this.scoreSleep();
    const basicHealthScore = this.scoreBasicHealth();
    const riskFactorsScore = this.scoreRiskFactors();

    const totalScore = dietScore + exerciseScore + sleepScore + basicHealthScore + riskFactorsScore;

    // 总分等级
    let totalScoreLevel: 'excellent' | 'good' | 'average' | 'poor' | 'veryPoor';
    if (totalScore >= 85) totalScoreLevel = 'excellent';
    else if (totalScore >= 70) totalScoreLevel = 'good';
    else if (totalScore >= 55) totalScoreLevel = 'average';
    else if (totalScore >= 40) totalScoreLevel = 'poor';
    else totalScoreLevel = 'veryPoor';

    const bmi = this.calculateBMI();
    const bmiCategory = bmi ? this.getBMICategory(bmi) : 'normal';
    const waistline = this.request.enrollmentInfo.waistline;
    const waistlineCategory = waistline ? this.getWaistlineCategory(waistline, this.request.generalInfo.gender) : 'normal';

    const analysis = this.generateAnalysis(dietScore, exerciseScore, sleepScore, basicHealthScore, riskFactorsScore);
    const recommendations = this.generateRecommendations();
    const actionPlan = this.generateActionPlan();

    return {
      totalScore,
      totalScoreLevel,
      dimensionScores: {
        diet: dietScore,
        exercise: exerciseScore,
        sleep: sleepScore,
        basicHealth: basicHealthScore,
        riskFactors: riskFactorsScore
      },
      bmi: bmi || 0,
      bmiCategory,
      waistlineCategory,
      analysis,
      recommendations,
      actionPlan
    };
  }
}
