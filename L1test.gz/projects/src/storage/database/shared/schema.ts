import { sql } from "drizzle-orm";
import {
  pgTable,
  text,
  varchar,
  timestamp,
  boolean,
  integer,
  jsonb,
  index,
} from "drizzle-orm/pg-core";
import { createSchemaFactory } from "drizzle-zod";
import { z } from "zod";

// 评估记录表
export const assessments = pgTable(
  "assessments",
  {
    id: varchar("id", { length: 36 })
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    // 用户基本信息（提取常用字段方便查询）
    name: varchar("name", { length: 128 }),
    gender: varchar("gender", { length: 20 }).notNull(),
    age: integer("age").notNull(),
    
    // 存储完整的评估请求和结果（JSON格式）
    requestData: jsonb("request_data").notNull(),
    responseData: jsonb("response_data").notNull(),
    
    // 提取常用字段方便查询和统计
    totalScore: integer("total_score").notNull(),
    bmi: varchar("bmi", { length: 20 }),
    totalScoreLevel: varchar("total_score_level", { length: 20 }).notNull(),
    bmiCategory: varchar("bmi_category", { length: 20 }),
    
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => ({
    createdAtIdx: index("assessments_created_at_idx").on(table.createdAt),
    totalScoreIdx: index("assessments_total_score_idx").on(table.totalScore),
    totalScoreLevelIdx: index("assessments_total_score_level_idx").on(table.totalScoreLevel),
    genderIdx: index("assessments_gender_idx").on(table.gender),
  })
);

// 管理员用户表
export const adminUsers = pgTable(
  "admin_users",
  {
    id: varchar("id", { length: 36 })
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    username: varchar("username", { length: 50 }).notNull().unique(),
    passwordHash: varchar("password_hash", { length: 255 }).notNull(),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => ({
    usernameIdx: index("admin_users_username_idx").on(table.username),
  })
);

// 使用 createSchemaFactory 配置 date coercion
const { createInsertSchema: createCoercedInsertSchema } = createSchemaFactory({
  coerce: { date: true },
});

// Zod schemas for validation
export const insertAssessmentSchema = createCoercedInsertSchema(assessments).pick({
  name: true,
  gender: true,
  age: true,
  requestData: true,
  responseData: true,
  totalScore: true,
  bmi: true,
  totalScoreLevel: true,
  bmiCategory: true,
});

export const updateAssessmentSchema = createCoercedInsertSchema(assessments)
  .pick({
    name: true,
    bmi: true,
  })
  .partial();

// 管理员用户Zod schemas
export const insertAdminUserSchema = createCoercedInsertSchema(adminUsers).pick({
  username: true,
  passwordHash: true,
  isActive: true,
});

export const createAdminUserSchema = z.object({
  username: z.string().min(3).max(50),
  password: z.string().min(6),
  isActive: z.boolean().optional(),
});

// TypeScript types
export type Assessment = typeof assessments.$inferSelect;
export type InsertAssessment = z.infer<typeof insertAssessmentSchema>;
export type UpdateAssessment = z.infer<typeof updateAssessmentSchema>;

export type AdminUser = typeof adminUsers.$inferSelect;
export type InsertAdminUser = z.infer<typeof insertAdminUserSchema>;
export type CreateAdminUser = z.infer<typeof createAdminUserSchema>;
