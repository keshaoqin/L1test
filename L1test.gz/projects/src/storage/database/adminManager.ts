import { getDb } from "coze-coding-dev-sdk";
import { adminUsers, type AdminUser, type InsertAdminUser, type CreateAdminUser } from "./shared/schema";
import { eq, desc } from "drizzle-orm";
import bcrypt from "bcrypt";

export class AdminManager {
  /**
   * 创建管理员用户
   */
  async createAdmin(data: CreateAdminUser): Promise<AdminUser> {
    // 检查用户名是否已存在
    const existing = await this.getAdminByUsername(data.username);
    if (existing) {
      throw new Error("用户名已存在");
    }

    // 加密密码
    const passwordHash = await bcrypt.hash(data.password, 10);

    // 插入数据库
    const insertData: InsertAdminUser = {
      username: data.username,
      passwordHash,
      isActive: data.isActive ?? true,
    };

    const db = await getDb();
    const result = await db
      .insert(adminUsers)
      .values(insertData)
      .returning();

    return result[0];
  }

  /**
   * 根据用户名获取管理员
   */
  async getAdminByUsername(username: string): Promise<AdminUser | null> {
    const db = await getDb();
    const result = await db
      .select()
      .from(adminUsers)
      .where(eq(adminUsers.username, username))
      .limit(1);

    return result[0] || null;
  }

  /**
   * 根据ID获取管理员
   */
  async getAdminById(id: string): Promise<AdminUser | null> {
    const db = await getDb();
    const result = await db
      .select()
      .from(adminUsers)
      .where(eq(adminUsers.id, id))
      .limit(1);

    return result[0] || null;
  }

  /**
   * 获取所有管理员
   */
  async getAllAdmins(): Promise<AdminUser[]> {
    const db = await getDb();
    const result = await db
      .select()
      .from(adminUsers)
      .orderBy(desc(adminUsers.createdAt));

    return result;
  }

  /**
   * 删除管理员
   */
  async deleteAdmin(id: string): Promise<boolean> {
    const db = await getDb();
    const result = await db
      .delete(adminUsers)
      .where(eq(adminUsers.id, id))
      .returning();

    return result.length > 0;
  }

  /**
   * 更新管理员状态
   */
  async updateAdminStatus(id: string, isActive: boolean): Promise<AdminUser | null> {
    const db = await getDb();
    const result = await db
      .update(adminUsers)
      .set({ isActive, updatedAt: new Date() })
      .where(eq(adminUsers.id, id))
      .returning();

    return result[0] || null;
  }

  /**
   * 验证用户名和密码
   */
  async validateLogin(username: string, password: string): Promise<AdminUser | null> {
    const admin = await this.getAdminByUsername(username);
    
    if (!admin) {
      return null;
    }

    if (!admin.isActive) {
      throw new Error("账户已被禁用");
    }

    const isValid = await bcrypt.compare(password, admin.passwordHash);
    
    if (!isValid) {
      return null;
    }

    return admin;
  }

  /**
   * 修改密码
   */
  async changePassword(id: string, newPassword: string): Promise<boolean> {
    const passwordHash = await bcrypt.hash(newPassword, 10);
    const db = await getDb();
    
    const result = await db
      .update(adminUsers)
      .set({ 
        passwordHash, 
        updatedAt: new Date() 
      })
      .where(eq(adminUsers.id, id))
      .returning();

    return result.length > 0;
  }

  /**
   * 初始化默认管理员
   * - 如果不存在，创建默认管理员
   * - 如果存在但被禁用，启用它
   * - 如果存在但密码不对，重置密码为默认值
   */
  async initDefaultAdmin(): Promise<{ action: string }> {
    const existing = await this.getAdminByUsername("admin");
    
    if (!existing) {
      // 不存在，创建
      await this.createAdmin({
        username: "admin",
        password: "admin123",
        isActive: true,
      });
      console.log("默认管理员已创建: username=admin, password=admin123");
      return { action: "created" };
    }
    
    // 检查是否被禁用
    if (!existing.isActive) {
      await this.updateAdminStatus(existing.id, true);
      console.log("默认管理员已启用: username=admin");
      return { action: "enabled" };
    }
    
    // 检查密码是否正确
    const isValid = await bcrypt.compare("admin123", existing.passwordHash);
    if (!isValid) {
      await this.changePassword(existing.id, "admin123");
      console.log("默认管理员密码已重置: username=admin, password=admin123");
      return { action: "password_reset" };
    }
    
    console.log("默认管理员已存在且状态正常: username=admin");
    return { action: "exists" };
  }

  /**
   * 初始化所有管理员（admin 和 ksq）
   */
  async initAllAdmins(): Promise<{ results: Array<{ username: string; action: string }> }> {
    const results: Array<{ username: string; action: string }> = [];
    
    // 初始化 admin
    const adminResult = await this.initDefaultAdmin();
    results.push({ username: "admin", action: adminResult.action });
    
    // 初始化 ksq
    const ksqResult = await this.initOrResetAdmin("ksq", "ksq123");
    results.push(ksqResult);
    
    return { results };
  }

  /**
   * 初始化或重置指定管理员
   */
  private async initOrResetAdmin(username: string, password: string): Promise<{ username: string; action: string }> {
    const existing = await this.getAdminByUsername(username);
    
    if (!existing) {
      // 不存在，创建
      await this.createAdmin({
        username,
        password,
        isActive: true,
      });
      console.log(`管理员已创建: username=${username}, password=${password}`);
      return { username, action: "created" };
    }
    
    // 检查是否被禁用
    if (!existing.isActive) {
      await this.updateAdminStatus(existing.id, true);
      console.log(`管理员已启用: username=${username}`);
      return { username, action: "enabled" };
    }
    
    // 检查密码是否正确
    const isValid = await bcrypt.compare(password, existing.passwordHash);
    if (!isValid) {
      await this.changePassword(existing.id, password);
      console.log(`管理员密码已重置: username=${username}, password=${password}`);
      return { username, action: "password_reset" };
    }
    
    console.log(`管理员已存在且状态正常: username=${username}`);
    return { username, action: "exists" };
  }
}

export const adminManager = new AdminManager();
