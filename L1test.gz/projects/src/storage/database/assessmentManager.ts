import { eq, and, SQL, desc, sql, gte, lte, like } from "drizzle-orm";
import { getDb } from "coze-coding-dev-sdk";
import { assessments, insertAssessmentSchema, updateAssessmentSchema } from "./shared/schema";
import type { Assessment, InsertAssessment, UpdateAssessment } from "./shared/schema";

export class AssessmentManager {
  /**
   * 创建评估记录
   */
  async createAssessment(data: InsertAssessment): Promise<Assessment> {
    const db = await getDb();
    const validated = insertAssessmentSchema.parse(data);
    const [assessment] = await db.insert(assessments).values(validated).returning();
    return assessment;
  }

  /**
   * 获取评估列表（支持筛选、搜索、分页）
   */
  async getAssessments(options: {
    skip?: number;
    limit?: number;
    filters?: {
      gender?: 'male' | 'female';
      totalScoreLevel?: 'excellent' | 'good' | 'average' | 'poor' | 'veryPoor';
      startDate?: Date | string;
      endDate?: Date | string;
      id?: string;
    };
    search?: string;
  } = {}): Promise<{ data: Assessment[]; total: number }> {
    const { skip = 0, limit = 20, filters = {}, search } = options;
    const db = await getDb();

    // 构建查询条件
    const conditions: SQL[] = [];

    if (filters.gender !== undefined) {
      conditions.push(eq(assessments.gender, filters.gender));
    }
    if (filters.totalScoreLevel !== undefined) {
      conditions.push(eq(assessments.totalScoreLevel, filters.totalScoreLevel));
    }
    if (filters.startDate) {
      const startDate = typeof filters.startDate === 'string' ? new Date(filters.startDate) : filters.startDate;
      conditions.push(gte(assessments.createdAt, startDate));
    }
    if (filters.endDate) {
      const endDate = typeof filters.endDate === 'string' ? new Date(filters.endDate) : filters.endDate;
      conditions.push(lte(assessments.createdAt, endDate));
    }
    if (filters.id) {
      conditions.push(eq(assessments.id, filters.id));
    }
    if (search) {
      conditions.push(like(assessments.name, `%${search}%`));
    }

    // 获取总数和数据
    const baseQuery = db.select().from(assessments);
    const finalQuery = conditions.length > 0 
      ? baseQuery.where(and(...conditions))
      : baseQuery;

    // 获取总数
    const countResult = await db
      .select({ count: sql<number>`count(*)` })
      .from(assessments)
      .where(conditions.length > 0 ? and(...conditions) : undefined);
    const total = countResult[0]?.count || 0;

    // 获取数据
    const data = await finalQuery
      .orderBy(desc(assessments.createdAt))
      .limit(limit)
      .offset(skip);

    return { data, total };
  }

  /**
   * 根据 ID 获取评估详情
   */
  async getAssessmentById(id: string): Promise<Assessment | null> {
    const db = await getDb();
    const [assessment] = await db.select().from(assessments).where(eq(assessments.id, id));
    return assessment || null;
  }

  /**
   * 更新评估记录
   */
  async updateAssessment(id: string, data: UpdateAssessment): Promise<Assessment | null> {
    const db = await getDb();
    const validated = updateAssessmentSchema.parse(data);
    const [assessment] = await db
      .update(assessments)
      .set({ ...validated, updatedAt: new Date() })
      .where(eq(assessments.id, id))
      .returning();
    return assessment || null;
  }

  /**
   * 删除评估记录
   */
  async deleteAssessment(id: string): Promise<boolean> {
    const db = await getDb();
    const result = await db.delete(assessments).where(eq(assessments.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  /**
   * 获取仪表盘统计数据
   */
  async getDashboardStats(): Promise<{
    totalAssessments: number;
    todayCount: number;
    weekCount: number;
    averageTotalScore: number;
    scoreDistribution: Record<string, number>;
    genderDistribution: Record<string, number>;
    dimensionAverages: {
      diet: number;
      exercise: number;
      sleep: number;
      basicHealth: number;
      riskFactors: number;
    };
  }> {
    const db = await getDb();

    // 总数
    const [totalResult] = await db.select({ count: sql<number>`count(*)` }).from(assessments);
    const totalAssessments = totalResult.count || 0;

    // 今日数量
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const [todayResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(assessments)
      .where(gte(assessments.createdAt, today));
    const todayCount = todayResult.count || 0;

    // 本周数量
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    const [weekResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(assessments)
      .where(gte(assessments.createdAt, weekAgo));
    const weekCount = weekResult.count || 0;

    // 平均总分
    const [avgScoreResult] = await db
      .select({ avg: sql<number>`avg(total_score)` })
      .from(assessments);
    const averageTotalScore = avgScoreResult.avg || 0;

    // 评分等级分布
    const scoreDistributionResult = await db
      .select({
        level: assessments.totalScoreLevel,
        count: sql<number>`count(*)`,
      })
      .from(assessments)
      .groupBy(assessments.totalScoreLevel);
    
    const scoreDistribution: Record<string, number> = {
      excellent: 0,
      good: 0,
      average: 0,
      poor: 0,
      veryPoor: 0,
    };
    scoreDistributionResult.forEach(row => {
      if (row.level) {
        scoreDistribution[row.level] = row.count;
      }
    });

    // 性别分布
    const genderDistributionResult = await db
      .select({
        gender: assessments.gender,
        count: sql<number>`count(*)`,
      })
      .from(assessments)
      .groupBy(assessments.gender);
    
    const genderDistribution: Record<string, number> = {
      male: 0,
      female: 0,
    };
    genderDistributionResult.forEach(row => {
      if (row.gender) {
        genderDistribution[row.gender] = row.count;
      }
    });

    // 各维度平均分（从 response_data 中提取）
    const allAssessments = await db.select().from(assessments);
    
    let dietSum = 0, exerciseSum = 0, sleepSum = 0, basicHealthSum = 0, riskFactorsSum = 0;
    
    allAssessments.forEach(assessment => {
      const responseData = assessment.responseData as any;
      if (responseData && responseData.dimensionScores) {
        dietSum += responseData.dimensionScores.diet || 0;
        exerciseSum += responseData.dimensionScores.exercise || 0;
        sleepSum += responseData.dimensionScores.sleep || 0;
        basicHealthSum += responseData.dimensionScores.basicHealth || 0;
        riskFactorsSum += responseData.dimensionScores.riskFactors || 0;
      }
    });

    const count = allAssessments.length || 1;
    const dimensionAverages = {
      diet: Math.round((dietSum / count) * 10) / 10,
      exercise: Math.round((exerciseSum / count) * 10) / 10,
      sleep: Math.round((sleepSum / count) * 10) / 10,
      basicHealth: Math.round((basicHealthSum / count) * 10) / 10,
      riskFactors: Math.round((riskFactorsSum / count) * 10) / 10,
    };

    return {
      totalAssessments,
      todayCount,
      weekCount,
      averageTotalScore: Math.round(averageTotalScore * 10) / 10,
      scoreDistribution,
      genderDistribution,
      dimensionAverages,
    };
  }
}

export const assessmentManager = new AssessmentManager();
