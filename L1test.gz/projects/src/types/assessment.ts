// 华西医院生活方式评估问卷 - 数据类型定义

export interface AssessmentRequest {
  // 一、一般信息
  generalInfo: {
    name?: string;
    gender: 'male' | 'female';
    age: number;
    smoking: {
      isSmoking: boolean;
      cigarettesPerDay?: number;
    };
    drinking: {
      isDrinking: boolean;
      gramsOfAlcoholPerDay?: number; // 每天摄入酒精量（克）= 摄入量 * 含酒精度
    };
  };

  // 二、身体情况
  enrollmentInfo: {
    height?: number; // cm
    weight?: number; // kg
    waistline?: number; // cm
    systolicBloodPressure?: number; // mmHg
    diastolicBloodPressure?: number; // mmHg
    pulse?: number; // 次/分
    bloodPressurePulseUnknown: boolean; // 是否不知道血压与脉搏数据
    weightLossDetermination: 'low' | 'medium' | 'high' | 'veryHigh'; // 减重决心
  };

  // 三、既往史
  medicalHistory: {
    noDiseases: boolean; // 没有以上疾病
    hyperlipidemia: boolean;
    fattyLiver: boolean;
    hypertension: boolean;
    coronaryHeartDisease: boolean;
    heartFailure: boolean;
    highBloodSugar: boolean;
    diabetes: boolean;
    hyperuricemia: boolean;
    gout: boolean;
    pancreatitis: boolean;
    thyroidRelated: boolean;
    others?: string;
  };

  // 四、饮食评估
  dietAssessment: {
    // 1. 食物选择与搭配
    foodSelection: {
      stapleFood: 'refined' | 'mixed'; // 精制米面 vs 粗细搭配
      proteinSource: 'balanced' | 'simple' | 'insufficient'; // 均衡/较单一/不足
      processedMeatPreference: boolean; // 是否偏好加工肉
    };
    fruitVegetableIntake: {
      vegetable300gOrMore: boolean;
      darkVegetableRatio: number; // 深色菜占比 %
      fruit200gOrMore: boolean;
      juiceInsteadOfFruit: boolean;
      cannedPickledFruitsAndVegetables: boolean;
    };
    oilAndSeasoning: {
      cookingOilType: 'vegetable' | 'animal' | 'mixed';
      oilIntakeExceeded: boolean;
      saltIntakeExceeded: boolean;
      sugarIntakeExceeded: boolean;
    };
    // 2. 进餐速度
    eatingSpeed: 'veryFast' | 'fast' | 'normal' | 'slow';
    // 3. 三餐规律性
    mealRegularity: {
      breakfastFrequency: 'daily' | '5-6days' | '≤4days';
      dinnerTime: '≤19:00' | '19:00-21:00' | '≥21:00';
      midnightSnackFrequency: 'none' | '1-2times' | '≥3times';
    };
    // 4. 外食/外卖频率
    eatingOut: {
      frequency: '0times' | '1-3times' | '4-6times' | 'daily';
      mainTypes: string[]; // 可多选：快餐、火锅/烧烤、炒菜、轻食
    };
    // 5. 烹饪方式偏好
    cookingMethodPreference: 'frying' | 'stirFrying' | 'steamingBoiling' | 'coldDish';
    // 6. 是否使用代餐/减肥产品
    mealReplacement: {
      isUsing: boolean;
      type?: 'proteinShake' | 'mealBar' | 'porridge' | 'other';
      productName?: string;
      frequency?: string;
    };
    // 7. 是否有食物禁忌或过敏
    foodAllergyOrTaboo: {
      hasTaboo: boolean;
      specificFoods?: string;
    };
    // 8. 每日饮水
    dailyWaterIntake: '<1L' | '1-2L' | '>2L' | 'sugaryDrinks';
    // 9. 饮食偏好与习惯
    dietaryPreferences: string[];
    dietaryPreferencesNone: boolean; // 无以上偏好
  };

  // 五、运动评估
  exerciseAssessment: {
    dailySteps: '<3000' | '3000-6000' | '6000-9000' | '>9000'; // 每日步数
    aerobicExercise: {
      frequency?: number; // 每周次数
      duration?: number; // 每次分钟
    };
    resistanceExercise: {
      frequency?: number;
      duration?: number;
    };
    flexibilityTraining: {
      frequency?: number;
      duration?: number;
    };
  };

  // 六、睡眠评估
  sleepAssessment: {
    sleepHours: '<5hours' | '5-7hours' | '7-9hours' | '>9hours'; // 睡眠时间选项
    bedtime: string; // 入睡时间
    snoring: boolean;
    sleepAidOrCPAP: boolean;
    sleepAidOrCPAPDetails?: string;
    daytimeEnergy: 'energetic' | 'tired';
  };
}

// 评估结果
export interface AssessmentResult {
  totalScore: number;
  totalScoreLevel: 'excellent' | 'good' | 'average' | 'poor' | 'veryPoor';
  dimensionScores: {
    diet: number;
    exercise: number;
    sleep: number;
    basicHealth: number;
    riskFactors: number;  // 危险因素（吸烟喝酒），满分10分
  };
  bmi: number;
  bmiCategory: 'underweight' | 'normal' | 'overweight' | 'obesity';
  waistlineCategory: 'normal' | 'highRisk' | 'veryHighRisk';

  analysis: {
    overall: string;
    diet: string;
    exercise: string;
    sleep: string;
    healthRisks: string[];
  };

  recommendations: {
    diet: string[];
    exercise: string[];
    sleep: string[];
    healthMonitoring: string[];
    psychologicalSupport: string[];
  };

  actionPlan: {
    oneMonth: string[];
    threeMonths: string[];
    sixMonths: string[];
  };
}
