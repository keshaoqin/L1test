'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Checkbox } from '@/components/ui/checkbox';
import { UserAgreementDialog } from '@/components/UserAgreementDialog';

export default function Home() {
  const [showAgreement, setShowAgreement] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [agreementTab, setAgreementTab] = useState<'agreement' | 'privacy'>('agreement');

  const handleShowUserAgreement = () => {
    setAgreementTab('agreement');
    setShowAgreement(true);
  };

  const handleShowPrivacyPolicy = () => {
    setAgreementTab('privacy');
    setShowAgreement(true);
  };

  const handleStartAssessment = (e: React.MouseEvent) => {
    if (!agreedToTerms) {
      e.preventDefault();
      alert('请先阅读并同意用户协议和隐私政策');
      return;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-4 pb-20">
      <div className="max-w-2xl mx-auto">
        {/* Logo和吉祥物 */}
        <div className="flex items-center justify-center mb-8">
          <img src="/logo-mascot.png" alt="Logo" className="h-24 w-auto" />
        </div>

        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            科学减重生活方式评估问卷
          </h1>
          <p className="text-xl text-gray-600">
            基于专业的医学知识和体重管理理论，为您提供科学的生活方式评估和减重建议
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">评估内容</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold text-blue-700 mb-2">饮食习惯评估</h3>
              <p className="text-sm text-gray-600">食物选择、进餐习惯、三餐规律性等</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="font-semibold text-green-700 mb-2">运动习惯评估</h3>
              <p className="text-sm text-gray-600">有氧运动、抗阻训练、柔韧性训练</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="font-semibold text-purple-700 mb-2">睡眠质量评估</h3>
              <p className="text-sm text-gray-600">睡眠时长、规律性、睡眠质量</p>
            </div>
            <div className="bg-orange-50 p-4 rounded-lg">
              <h3 className="font-semibold text-orange-700 mb-2">基础健康指标</h3>
              <p className="text-sm text-gray-600">BMI、腰围、血压等</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">评估报告</h2>
          <ul className="space-y-2 text-gray-600">
            <li className="flex items-start">
              <span className="text-blue-500 mr-2">✓</span>
              <span>总体生活方式评分（满分100分）</span>
            </li>
            <li className="flex items-start">
              <span className="text-blue-500 mr-2">✓</span>
              <span>各维度详细分析和得分</span>
            </li>
            <li className="flex items-start">
              <span className="text-blue-500 mr-2">✓</span>
              <span>个性化饮食建议</span>
            </li>
            <li className="flex items-start">
              <span className="text-blue-500 mr-2">✓</span>
              <span>科学运动指导</span>
            </li>
            <li className="flex items-start">
              <span className="text-blue-500 mr-2">✓</span>
              <span>睡眠改善建议</span>
            </li>
            <li className="flex items-start">
              <span className="text-blue-500 mr-2">✓</span>
              <span>健康风险提示</span>
            </li>
          </ul>
        </div>

        <div className="text-center space-y-4">
          <div className="flex items-center justify-start gap-3 bg-blue-50 p-4 rounded-lg">
            <Checkbox
              id="agree-terms"
              checked={agreedToTerms}
              onCheckedChange={(checked) => setAgreedToTerms(checked as boolean)}
            />
            <label
              htmlFor="agree-terms"
              className="text-sm text-gray-700 cursor-pointer select-none"
            >
              我已阅读并同意
              <button
                type="button"
                onClick={handleShowUserAgreement}
                className="text-blue-600 hover:text-blue-700 underline ml-1"
              >
                《用户协议》
              </button>
              和
              <button
                type="button"
                onClick={handleShowPrivacyPolicy}
                className="text-blue-600 hover:text-blue-700 underline ml-1"
              >
                《隐私政策》
              </button>
            </label>
          </div>

          <Link href="/assessment" onClick={handleStartAssessment}>
            <div
              className={`inline-block font-semibold py-4 px-8 rounded-xl text-lg transition-all cursor-pointer shadow-lg ${
                agreedToTerms
                  ? 'bg-green-600 hover:bg-green-700 text-white hover:shadow-xl'
                  : 'bg-gray-400 text-gray-200 cursor-not-allowed'
              }`}
            >
              开始评估 →
            </div>
          </Link>
          <p className="text-sm text-gray-500">
            评估大约需要 5-10 分钟
          </p>
        </div>

        <div className="mt-12 text-center text-sm text-gray-500">
          <p>本评估系统基于华西医院减重科生活方式医学评估和循证医学证据</p>
          <p>评估结果仅供参考，如有健康问题请咨询专业医生</p>
        </div>
      </div>

      <UserAgreementDialog 
        open={showAgreement} 
        onOpenChange={setShowAgreement}
        defaultTab={agreementTab}
      />
    </div>
  );
}
