'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Check, Info, AlertCircle, Download } from 'lucide-react';
import { AssessmentRequest } from '@/types/assessment';
import { HealthRadarChart } from '@/components/radar-chart';
import html2canvas from 'html2canvas';

const TOTAL_STEPS = 6;

export default function AssessmentPage() {
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [exporting, setExporting] = useState(false);
  const reportRef = useState<HTMLDivElement | null>(null)[0];

  // 存储每个字段的错误信息
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  const [formData, setFormData] = useState<Partial<AssessmentRequest>>({
    generalInfo: {
      name: '',
      gender: undefined as any,
      age: undefined as any,
      smoking: {
        isSmoking: undefined as any,
        cigarettesPerDay: undefined
      },
      drinking: {
        isDrinking: undefined as any,
        gramsOfAlcoholPerDay: undefined
      }
    },
    enrollmentInfo: {
      bloodPressurePulseUnknown: undefined as any,
      weightLossDetermination: undefined as any
    },
    medicalHistory: {
      noDiseases: undefined as any,
      hyperlipidemia: undefined as any,
      fattyLiver: undefined as any,
      hypertension: undefined as any,
      coronaryHeartDisease: undefined as any,
      heartFailure: undefined as any,
      highBloodSugar: undefined as any,
      diabetes: undefined as any,
      hyperuricemia: undefined as any,
      gout: undefined as any,
      pancreatitis: undefined as any,
      thyroidRelated: undefined as any
    },
    dietAssessment: {
      foodSelection: {
        stapleFood: undefined as any,
        proteinSource: undefined as any,
        processedMeatPreference: undefined as any
      },
      fruitVegetableIntake: {
        vegetable300gOrMore: undefined as any,
        darkVegetableRatio: 0,
        fruit200gOrMore: undefined as any,
        juiceInsteadOfFruit: undefined as any,
        cannedPickledFruitsAndVegetables: undefined as any
      },
      oilAndSeasoning: {
        cookingOilType: undefined as any,
        oilIntakeExceeded: undefined as any,
        saltIntakeExceeded: undefined as any,
        sugarIntakeExceeded: undefined as any
      },
      eatingSpeed: undefined as any,
      mealRegularity: {
        breakfastFrequency: undefined as any,
        dinnerTime: undefined as any,
        midnightSnackFrequency: undefined as any
      },
      eatingOut: {
        frequency: undefined as any,
        mainTypes: []
      },
      cookingMethodPreference: undefined as any,
      mealReplacement: {
        isUsing: undefined as any
      },
      foodAllergyOrTaboo: {
        hasTaboo: undefined as any
      },
      dailyWaterIntake: undefined as any,
      dietaryPreferences: [],
      dietaryPreferencesNone: undefined as any
    },
    exerciseAssessment: {
      dailySteps: undefined as any,
      aerobicExercise: { frequency: undefined, duration: undefined },
      resistanceExercise: { frequency: undefined, duration: undefined },
      flexibilityTraining: { frequency: undefined, duration: undefined }
    },
    sleepAssessment: {
      sleepHours: undefined as any,
      bedtime: '',
      snoring: undefined as any,
      sleepAidOrCPAP: undefined as any,
      daytimeEnergy: undefined as any
    }
  });

  const updateFormData = (section: string, data: any, fieldPath?: string) => {
    setFormData(prev => ({
      ...prev,
      [section]: { ...prev[section as keyof AssessmentRequest], ...data }
    }));

    // 如果提供了fieldPath，清除该字段的错误
    if (fieldPath) {
      clearFieldError(fieldPath);
    }
  };

  const handleNext = () => {
    if (currentStep < TOTAL_STEPS) {
      setCurrentStep(currentStep + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // 检查指定字段是否有错误
  const hasFieldError = (fieldPath: string): boolean => {
    return !!fieldErrors[fieldPath];
  };

  // 获取指定字段的错误信息
  const getFieldError = (fieldPath: string): string | undefined => {
    return fieldErrors[fieldPath];
  };

  // 清除指定字段的错误
  const clearFieldError = (fieldPath: string) => {
    setFieldErrors(prev => {
      const newErrors = { ...prev };
      delete newErrors[fieldPath];
      return newErrors;
    });
  };

  // 创建一个带有错误提示的表单项组件
  const FormItemWithError = ({ fieldPath, label, children }: { fieldPath: string; label: string; children: React.ReactNode }) => {
    const error = getFieldError(fieldPath);
    return (
      <div data-field={fieldPath} className="mb-4">
        {label && <label className="block text-sm font-medium text-gray-700 mb-2">{label}</label>}
        {children}
        {error && (
          <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-sm text-red-600 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              {error}
            </p>
          </div>
        )}
      </div>
    );
  };

  // 获取当前步骤的所有错误
  const getCurrentStepErrors = (): string[] => {
    const currentStepPrefix = [
      'generalInfo',
      'enrollmentInfo',
      'medicalHistory',
      'dietAssessment',
      'exerciseAssessment',
      'sleepAssessment'
    ][currentStep - 1];

    return Object.keys(fieldErrors)
      .filter(key => key.startsWith(currentStepPrefix))
      .map(key => fieldErrors[key]);
  };

  // 验证表单数据并返回具体的字段错误
  const findFieldErrors = (): Record<string, string> => {
    const errors: Record<string, string> = {};

    // 步骤1：基本信息
    if (!formData.generalInfo?.name?.trim()) errors['generalInfo.name'] = '请输入姓名';
    if (!formData.generalInfo?.gender) errors['generalInfo.gender'] = '请选择性别';
    if (!formData.generalInfo?.age) errors['generalInfo.age'] = '请输入年龄';
    if (formData.generalInfo?.smoking?.isSmoking === undefined) errors['generalInfo.smoking.isSmoking'] = '请选择是否吸烟';
    if (formData.generalInfo?.smoking?.isSmoking && !formData.generalInfo.smoking.cigarettesPerDay) {
      errors['generalInfo.smoking.cigarettesPerDay'] = '请输入每天吸烟支数';
    }
    if (formData.generalInfo?.drinking?.isDrinking === undefined) errors['generalInfo.drinking.isDrinking'] = '请选择是否饮酒';
    if (formData.generalInfo?.drinking?.isDrinking && !formData.generalInfo.drinking.gramsOfAlcoholPerDay) {
      errors['generalInfo.drinking.gramsOfAlcoholPerDay'] = '请输入每天摄入酒精量';
    }

    // 步骤2：身体情况
    if (!formData.enrollmentInfo?.height) errors['enrollmentInfo.height'] = '请输入身高';
    if (!formData.enrollmentInfo?.weight) errors['enrollmentInfo.weight'] = '请输入体重';
    if (!formData.enrollmentInfo?.waistline) errors['enrollmentInfo.waistline'] = '请输入腰围';
    if (!formData.enrollmentInfo?.weightLossDetermination) errors['enrollmentInfo.weightLossDetermination'] = '请选择减重决心';

    // 血压脉搏（如果不是"不知道"）
    if (formData.enrollmentInfo?.bloodPressurePulseUnknown === undefined) {
      errors['enrollmentInfo.bloodPressurePulseUnknown'] = '请选择是否知道血压与脉搏数据';
    } else if (formData.enrollmentInfo?.bloodPressurePulseUnknown === false) {
      if (!formData.enrollmentInfo?.systolicBloodPressure) errors['enrollmentInfo.systolicBloodPressure'] = '请输入收缩压';
      if (!formData.enrollmentInfo?.diastolicBloodPressure) errors['enrollmentInfo.diastolicBloodPressure'] = '请输入舒张压';
      if (!formData.enrollmentInfo?.pulse) errors['enrollmentInfo.pulse'] = '请输入脉搏';
    }

    // 步骤3：既往史
    const medicalHistory = formData.medicalHistory;
    if (medicalHistory?.noDiseases === undefined &&
        medicalHistory?.hyperlipidemia === undefined &&
        medicalHistory?.fattyLiver === undefined &&
        medicalHistory?.hypertension === undefined &&
        medicalHistory?.coronaryHeartDisease === undefined &&
        medicalHistory?.heartFailure === undefined &&
        medicalHistory?.highBloodSugar === undefined &&
        medicalHistory?.diabetes === undefined &&
        medicalHistory?.hyperuricemia === undefined &&
        medicalHistory?.gout === undefined &&
        medicalHistory?.pancreatitis === undefined &&
        medicalHistory?.thyroidRelated === undefined) {
      errors['medicalHistory.any'] = '请选择既往病史（至少选择一项或选择"无以上选项"）';
    }

    // 步骤4：饮食评估
    const diet = formData.dietAssessment;
    if (!diet?.foodSelection?.stapleFood) errors['dietAssessment.foodSelection.stapleFood'] = '请选择主食偏好';
    if (!diet?.foodSelection?.proteinSource) errors['dietAssessment.foodSelection.proteinSource'] = '请选择蛋白质来源';
    if (diet?.foodSelection?.processedMeatPreference === undefined) errors['dietAssessment.foodSelection.processedMeatPreference'] = '请选择是否偏好加工肉';
    if (diet?.fruitVegetableIntake?.vegetable300gOrMore === undefined) errors['dietAssessment.fruitVegetableIntake.vegetable300gOrMore'] = '请选择每日蔬菜摄入量';
    if (diet?.fruitVegetableIntake?.vegetable300gOrMore && diet.fruitVegetableIntake.darkVegetableRatio === 0) {
      errors['dietAssessment.fruitVegetableIntake.darkVegetableRatio'] = '请输入深色蔬菜占比';
    }
    if (diet?.fruitVegetableIntake?.fruit200gOrMore === undefined) errors['dietAssessment.fruitVegetableIntake.fruit200gOrMore'] = '请选择每日水果摄入量';
    if (diet?.fruitVegetableIntake?.juiceInsteadOfFruit === undefined) errors['dietAssessment.fruitVegetableIntake.juiceInsteadOfFruit'] = '请选择是否用果汁代替水果';
    if (diet?.fruitVegetableIntake?.cannedPickledFruitsAndVegetables === undefined) errors['dietAssessment.fruitVegetableIntake.cannedPickledFruitsAndVegetables'] = '请选择是否食用腌制蔬果';
    if (!diet?.oilAndSeasoning?.cookingOilType) errors['dietAssessment.oilAndSeasoning.cookingOilType'] = '请选择烹饪用油';
    if (diet?.oilAndSeasoning?.oilIntakeExceeded === undefined) errors['dietAssessment.oilAndSeasoning.oilIntakeExceeded'] = '请选择油脂摄入是否超标';
    if (diet?.oilAndSeasoning?.saltIntakeExceeded === undefined) errors['dietAssessment.oilAndSeasoning.saltIntakeExceeded'] = '请选择盐摄入是否超标';
    if (diet?.oilAndSeasoning?.sugarIntakeExceeded === undefined) errors['dietAssessment.oilAndSeasoning.sugarIntakeExceeded'] = '请选择添加糖摄入是否超标';
    if (!diet?.eatingSpeed) errors['dietAssessment.eatingSpeed'] = '请选择进食速度';
    if (!diet?.mealRegularity?.breakfastFrequency) errors['dietAssessment.mealRegularity.breakfastFrequency'] = '请选择早餐频率';
    if (!diet?.mealRegularity?.dinnerTime) errors['dietAssessment.mealRegularity.dinnerTime'] = '请选择晚餐时间';
    if (!diet?.mealRegularity?.midnightSnackFrequency) errors['dietAssessment.mealRegularity.midnightSnackFrequency'] = '请选择夜宵频率';
    if (!diet?.eatingOut?.frequency) errors['dietAssessment.eatingOut.frequency'] = '请选择外出就餐频率';
    if (diet?.eatingOut?.frequency !== '0times' && (!diet?.eatingOut?.mainTypes || diet.eatingOut.mainTypes.length === 0)) {
      errors['dietAssessment.eatingOut.mainTypes'] = '请选择外出就餐类型';
    }
    if (!diet?.cookingMethodPreference) errors['dietAssessment.cookingMethodPreference'] = '请选择烹饪方式偏好';
    if (diet?.mealReplacement?.isUsing === undefined) errors['dietAssessment.mealReplacement.isUsing'] = '请选择是否使用代餐';
    if (diet?.foodAllergyOrTaboo?.hasTaboo === undefined) errors['dietAssessment.foodAllergyOrTaboo.hasTaboo'] = '请选择是否有饮食禁忌';
    if (!diet?.dailyWaterIntake) errors['dietAssessment.dailyWaterIntake'] = '请选择每日饮水量';
    // 只有当用户选择了偏好或选择了"无偏好"时才通过验证
    if ((!diet?.dietaryPreferences || diet.dietaryPreferences.length === 0) && diet?.dietaryPreferencesNone !== true) {
      errors['dietAssessment.dietaryPreferences'] = '请选择饮食偏好或选择"无偏好"';
    }

    // 步骤5：运动评估 - 每日步数为必填
    if (!formData.exerciseAssessment?.dailySteps) {
      errors['exerciseAssessment.dailySteps'] = '请选择您的每日步数';
    }

    // 步骤6：睡眠评估
    const sleep = formData.sleepAssessment;
    if (!sleep?.sleepHours) errors['sleepAssessment.sleepHours'] = '请选择每日睡眠时长';
    if (!sleep?.bedtime) errors['sleepAssessment.bedtime'] = '请选择入睡时间';
    if (sleep?.snoring === undefined) errors['sleepAssessment.snoring'] = '请选择是否打鼾';
    if (sleep?.sleepAidOrCPAP === undefined) errors['sleepAssessment.sleepAidOrCPAP'] = '请选择是否使用助眠药物或呼吸机';
    if (!sleep?.daytimeEnergy) errors['sleepAssessment.daytimeEnergy'] = '请选择白天精力状态';

    return errors;
  };

  // 根据字段路径获取步骤号
  const getStepFromFieldPath = (fieldPath: string): number => {
    if (fieldPath.startsWith('generalInfo')) return 1;
    if (fieldPath.startsWith('enrollmentInfo')) return 2;
    if (fieldPath.startsWith('medicalHistory')) return 3;
    if (fieldPath.startsWith('dietAssessment')) return 4;
    if (fieldPath.startsWith('exerciseAssessment')) return 5;
    if (fieldPath.startsWith('sleepAssessment')) return 6;
    return 1;
  };

  const handleSubmit = async () => {
    // 检查是否有未完成的字段
    const errors = findFieldErrors();
    if (Object.keys(errors).length > 0) {
      // 设置错误信息
      setFieldErrors(errors);

      // 找到第一个错误所在的步骤并跳转
      const firstErrorField = Object.keys(errors)[0];
      const targetStep = getStepFromFieldPath(firstErrorField);

      if (targetStep !== currentStep) {
        setCurrentStep(targetStep);
      }

      // 滚动到第一个错误字段
      setTimeout(() => {
        const errorElement = document.querySelector(`[data-field="${firstErrorField}"]`);
        if (errorElement) {
          errorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 100);

      return;
    }

    // 清除所有错误
    setFieldErrors({});

    setLoading(true);
    try {
      // 将 undefined 转换为 false 以匹配类型定义
      const submissionData = {
        ...formData,
        generalInfo: {
          ...formData.generalInfo,
          smoking: {
            ...formData.generalInfo!.smoking,
            isSmoking: formData.generalInfo!.smoking!.isSmoking ?? false,
            cigarettesPerDay: formData.generalInfo!.smoking!.cigarettesPerDay || undefined
          },
          drinking: {
            ...formData.generalInfo!.drinking,
            isDrinking: formData.generalInfo!.drinking!.isDrinking ?? false,
            gramsOfAlcoholPerDay: formData.generalInfo!.drinking!.gramsOfAlcoholPerDay || undefined
          }
        },
        enrollmentInfo: {
          ...formData.enrollmentInfo,
          bloodPressurePulseUnknown: formData.enrollmentInfo!.bloodPressurePulseUnknown ?? false
        },
        medicalHistory: {
          ...formData.medicalHistory,
          noDiseases: formData.medicalHistory!.noDiseases ?? false,
          hyperlipidemia: formData.medicalHistory!.hyperlipidemia ?? false,
          fattyLiver: formData.medicalHistory!.fattyLiver ?? false,
          hypertension: formData.medicalHistory!.hypertension ?? false,
          coronaryHeartDisease: formData.medicalHistory!.coronaryHeartDisease ?? false,
          heartFailure: formData.medicalHistory!.heartFailure ?? false,
          highBloodSugar: formData.medicalHistory!.highBloodSugar ?? false,
          diabetes: formData.medicalHistory!.diabetes ?? false,
          hyperuricemia: formData.medicalHistory!.hyperuricemia ?? false,
          gout: formData.medicalHistory!.gout ?? false,
          pancreatitis: formData.medicalHistory!.pancreatitis ?? false,
          thyroidRelated: formData.medicalHistory!.thyroidRelated ?? false
        },
        dietAssessment: {
          ...formData.dietAssessment,
          foodSelection: {
            ...formData.dietAssessment!.foodSelection,
            processedMeatPreference: formData.dietAssessment!.foodSelection!.processedMeatPreference ?? false
          },
          fruitVegetableIntake: {
            ...formData.dietAssessment!.fruitVegetableIntake,
            vegetable300gOrMore: formData.dietAssessment!.fruitVegetableIntake!.vegetable300gOrMore ?? false,
            fruit200gOrMore: formData.dietAssessment!.fruitVegetableIntake!.fruit200gOrMore ?? false,
            juiceInsteadOfFruit: formData.dietAssessment!.fruitVegetableIntake!.juiceInsteadOfFruit ?? false,
            cannedPickledFruitsAndVegetables: formData.dietAssessment!.fruitVegetableIntake!.cannedPickledFruitsAndVegetables ?? false
          },
          oilAndSeasoning: {
            ...formData.dietAssessment!.oilAndSeasoning,
            oilIntakeExceeded: formData.dietAssessment!.oilAndSeasoning!.oilIntakeExceeded ?? false,
            saltIntakeExceeded: formData.dietAssessment!.oilAndSeasoning!.saltIntakeExceeded ?? false,
            sugarIntakeExceeded: formData.dietAssessment!.oilAndSeasoning!.sugarIntakeExceeded ?? false
          },
          mealReplacement: {
            ...formData.dietAssessment!.mealReplacement,
            isUsing: formData.dietAssessment!.mealReplacement!.isUsing ?? false,
            type: formData.dietAssessment!.mealReplacement!.type ?? undefined
          },
          foodAllergyOrTaboo: {
            ...formData.dietAssessment!.foodAllergyOrTaboo,
            hasTaboo: formData.dietAssessment!.foodAllergyOrTaboo!.hasTaboo ?? false
          },
          dietaryPreferencesNone: formData.dietAssessment!.dietaryPreferencesNone ?? false
        },
        sleepAssessment: {
          ...formData.sleepAssessment,
          snoring: formData.sleepAssessment!.snoring ?? false,
          sleepAidOrCPAP: formData.sleepAssessment!.sleepAidOrCPAP ?? false
        }
      };

      const response = await fetch('/api/assess', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(submissionData)
      });
      const data = await response.json();
      setResult(data);
    } catch (error) {
      console.error('提交失败:', error);
      alert('提交失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  // 导出为图片
  
  // 导出为图片 - 直接截图结果页 DOM 元素，使用增强的 oklch 处理
  const handleExportAsImage = async () => {
    if (!result) return;

    setExporting(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 300));

      // 创建一个隐藏的临时容器
      const tempContainer = document.createElement('div');
      tempContainer.id = 'temp-assessment-report';
      tempContainer.style.position = 'fixed';
      tempContainer.style.left = '-9999px';
      tempContainer.style.top = '0';
      tempContainer.style.width = '800px';
      tempContainer.style.backgroundColor = '#ffffff';
      tempContainer.style.padding = '24px';
      tempContainer.style.fontFamily = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      document.body.appendChild(tempContainer);

      // 生成用户报告内容
      const getScoreTheme = () => {
        if (result.totalScore >= 85) {
          return {
            gradient: 'from-green-400 to-emerald-500',
            bgColor: 'bg-green-50',
            textColor: 'text-green-700',
            borderColor: 'border-green-200',
            badgeBg: 'bg-green-100',
            badgeText: 'text-green-700',
            emoji: '😊',
            rabbit: '🐰',
            title: '优秀',
          };
        } else if (result.totalScore >= 70) {
          return {
            gradient: 'from-blue-400 to-indigo-500',
            bgColor: 'bg-blue-50',
            textColor: 'text-blue-700',
            borderColor: 'border-blue-200',
            badgeBg: 'bg-blue-100',
            badgeText: 'text-blue-700',
            emoji: '😄',
            rabbit: '🐰',
            title: '良好',
          };
        } else if (result.totalScore >= 55) {
          return {
            gradient: 'from-yellow-400 to-orange-400',
            bgColor: 'bg-yellow-50',
            textColor: 'text-yellow-700',
            borderColor: 'border-yellow-200',
            badgeBg: 'bg-yellow-100',
            badgeText: 'text-yellow-700',
            emoji: '😐',
            rabbit: '🐰',
            title: '一般',
          };
        } else if (result.totalScore >= 40) {
          return {
            gradient: 'from-orange-400 to-red-400',
            bgColor: 'bg-orange-50',
            textColor: 'text-orange-700',
            borderColor: 'border-orange-200',
            badgeBg: 'bg-orange-100',
            badgeText: 'text-orange-700',
            emoji: '😟',
            rabbit: '🐰',
            title: '较差',
          };
        } else {
          return {
            gradient: 'from-red-400 to-red-600',
            bgColor: 'bg-red-50',
            textColor: 'text-red-700',
            borderColor: 'border-red-200',
            badgeBg: 'bg-red-100',
            badgeText: 'text-red-700',
            emoji: '😰',
            rabbit: '🐰',
            title: '很差',
          };
        }
      };

      const theme = getScoreTheme();

      // BMI类别映射
      const getBMICategory = () => {
        if (result.bmiCategory === 'normal') return '正常';
        if (result.bmiCategory === 'overweight') return '超重';
        if (result.bmiCategory === 'obesity') return '肥胖';
        return '偏瘦';
      };

      // 生成完整报告HTML
      tempContainer.innerHTML = `
        <div style="max-width: 100%; margin: 0 auto;">
          <!-- 顶部品牌栏 -->
          <div style="display: flex; align-items: center; justify-content: space-between; padding: 20px 24px; border-bottom: 2px solid #e5e7eb; margin-bottom: 20px;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #2288D2, #0D2860); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <span style="color: white; font-weight: bold; font-size: 20px; line-height: 1;">悦</span>
              </div>
              <div>
                <div style="font-weight: bold; color: #111827; font-size: 16px; line-height: 1.2;">时悦健康</div>
                <div style="color: #6b7280; font-size: 12px; line-height: 1.2; margin-top: 2px;">生活方式评估报告</div>
              </div>
            </div>
            <div style="text-align: right; flex-shrink: 0;">
              <div style="color: #374151; font-size: 12px; font-weight: 500; line-height: 1.2;">
                ${formData.generalInfo?.name || '匿名'} · ${formData.generalInfo?.gender === 'male' ? '男' : '女'} · ${formData.generalInfo?.age}岁
              </div>
              <div style="color: #9ca3af; font-size: 11px; line-height: 1.2; margin-top: 2px;">评估日期</div>
              <div style="font-weight: 600; color: #374151; font-size: 14px; line-height: 1.2; margin-top: 2px;">${new Date().toLocaleDateString('zh-CN')}</div>
            </div>
          </div>

          <!-- 评分头部 -->
          <div style="background: linear-gradient(to bottom right, #2288D2, #0D2860); padding: 48px 32px; border-radius: 20px; color: white; text-align: center; margin-bottom: 24px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); position: relative; overflow: hidden;">
            <div style="font-size: 14px; font-weight: 600; opacity: 0.9; margin-bottom: 8px; letter-spacing: 0.5px;">科学减重生活方式评估报告</div>
            <div style="font-size: 72px; font-weight: bold; line-height: 1; margin-bottom: 8px;">${result.totalScore}</div>
            <div style="font-size: 16px; font-weight: 500; opacity: 0.9; margin-bottom: 16px;">总得分 · 满分100</div>
            <div style="display: inline-block; padding: 14px 36px; background: rgba(255, 255, 255, 0.15); backdrop-filter: blur(10px); border-radius: 16px; border: 1px solid rgba(255, 255, 255, 0.3); box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
              <span style="font-size: 24px; font-weight: bold; letter-spacing: 1px; line-height: 1;">${theme.title}</span>
            </div>
            <!-- 品牌图片 -->
            <div style="position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 50%; height: 50%; display: flex; align-items: flex-end; justify-content: center;">
              <img src="/003.png" alt="时悦健康" style="height: 100%; max-height: 120px; width: auto; opacity: 0.25;" />
            </div>
          </div>

          <!-- 评分等级 -->
          <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; margin-bottom: 24px;">
            ${[
              { range: '85-100', color: 'background-color: #22c55e; color: white;', min: 85, max: 100 },
              { range: '70-84', color: 'background-color: #3b82f6; color: white;', min: 70, max: 84 },
              { range: '55-69', color: 'background-color: #eab308; color: white;', min: 55, max: 69 },
              { range: '40-54', color: 'background-color: #f97316; color: white;', min: 40, max: 54 },
              { range: '0-39', color: 'background-color: #ef4444; color: white;', min: 0, max: 39 },
            ].map((item) => {
              const isActive = result.totalScore >= item.min && result.totalScore <= item.max;
              return `
                <div style="padding: 10px; text-align: center; border-radius: 10px; border: 2px solid ${isActive ? 'currentColor' : '#e5e7eb'}; ${isActive ? item.color + ' border: currentColor; font-weight: bold; box-shadow: 0 2px 4px rgba(0,0,0,0.1);' : 'background-color: #f9fafb; color: #4b5563;'}">
                  <div style="font-size: 11px; font-weight: bold; letter-spacing: 0.5px; line-height: 1.2;">${item.range}分</div>
                </div>
              `;
            }).join('')}
          </div>

          <!-- 各维度得分 -->
          <div style="margin-bottom: 24px;">
            <h3 style="font-size: 16px; font-weight: bold; color: #111827; margin-bottom: 16px; line-height: 1.2;">各维度得分</h3>
            <div style="background: white; padding: 16px; border-radius: 16px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);">
              <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px;">
                ${[
                  { label: '饮食', score: result.dimensionScores.diet, fullScore: 40, color: 'border: 2px solid #22c55e; background-color: #f0fdf4; color: #166534;' },
                  { label: '运动', score: result.dimensionScores.exercise, fullScore: 25, color: 'border: 2px solid #fb923c; background-color: #fff7ed; color: #c2410c;' },
                  { label: '睡眠', score: result.dimensionScores.sleep, fullScore: 15, color: 'border: 2px solid #a855f7; background-color: #faf5ff; color: #7e22ce;' },
                  { label: '基础健康', score: result.dimensionScores.basicHealth, fullScore: 10, color: 'border: 2px solid #ef4444; background-color: #fef2f2; color: #b91c1c;' },
                  { label: '风险控制', score: result.dimensionScores.riskFactors, fullScore: 10, color: 'border: 2px solid #3b82f6; background-color: #eff6ff; color: #1d4ed8;' },
                ].map(item => `
                  <div style="padding: 10px; border-radius: 10px; ${item.color} text-align: center;">
                    <div style="font-size: 11px; font-weight: bold; line-height: 1.2;">${item.label}</div>
                    <div style="font-size: 16px; font-weight: bold; margin-top: 4px; line-height: 1;">${item.score}</div>
                    <div style="font-size: 10px; font-weight: 500; opacity: 0.75; margin-top: 2px; line-height: 1;">/${item.fullScore}</div>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>

          <!-- 总体评价 -->
          <div style="background: linear-gradient(to bottom right, #dbeafe, #ede9fe); padding: 20px; border-radius: 16px; border: 2px solid #c7d2fe; margin-bottom: 20px;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
              <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #2288D2, #0D2860); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <span style="font-size: 20px; line-height: 1;">💡</span>
              </div>
              <h3 style="font-weight: bold; font-size: 16px; color: #111827; line-height: 1.2;">总体评价</h3>
            </div>
            <p style="font-size: 13px; color: #1f2937; line-height: 1.8; margin: 0; padding-left: 56px;">${result.analysis.overall}</p>
          </div>

          <!-- 各维度详细分析 -->
          <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 20px;">
            <!-- 饮食习惯 -->
            <div style="background: linear-gradient(to bottom right, #f0fdf4, #dcfce7); padding: 16px; border-radius: 16px; border: 1px solid #bbf7d0;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #22c55e, #16a34a); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">🍎</span>
                </div>
                <div>
                  <h3 style="font-weight: bold; font-size: 15px; color: #14532d; line-height: 1.2;">饮食习惯</h3>
                  <div style="font-size: 11px; font-weight: bold; color: #166534; margin-top: 2px; line-height: 1.2;">${result.dimensionScores.diet}/40分</div>
                </div>
              </div>
              <p style="font-size: 12px; color: #1f2937; line-height: 1.6; margin: 0;">${result.analysis.diet}</p>
            </div>

            <!-- 运动习惯 -->
            <div style="background: linear-gradient(to bottom right, #fff7ed, #ffedd5); padding: 16px; border-radius: 16px; border: 1px solid #fed7aa;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #fb923c, #ea580c); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">🏃</span>
                </div>
                <div>
                  <h3 style="font-weight: bold; font-size: 15px; color: #7c2d12; line-height: 1.2;">运动习惯</h3>
                  <div style="font-size: 11px; font-weight: bold; color: #c2410c; margin-top: 2px; line-height: 1.2;">${result.dimensionScores.exercise}/25分</div>
                </div>
              </div>
              <p style="font-size: 12px; color: #1f2937; line-height: 1.6; margin: 0;">${result.analysis.exercise}</p>
            </div>

            <!-- 睡眠质量 -->
            <div style="background: linear-gradient(to bottom right, #faf5ff, #f3e8ff); padding: 16px; border-radius: 16px; border: 1px solid #e9d5ff;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #a855f7, #7c3aed); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">😴</span>
                </div>
                <div>
                  <h3 style="font-weight: bold; font-size: 15px; color: #581c87; line-height: 1.2;">睡眠质量</h3>
                  <div style="font-size: 11px; font-weight: bold; color: #7e22ce; margin-top: 2px; line-height: 1.2;">${result.dimensionScores.sleep}/15分</div>
                </div>
              </div>
              <p style="font-size: 12px; color: #1f2937; line-height: 1.6; margin: 0;">${result.analysis.sleep}</p>
            </div>

            <!-- 基础健康 -->
            <div style="background: linear-gradient(to bottom right, #fef2f2, #fee2e2); padding: 16px; border-radius: 16px; border: 1px solid #fecaca;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #ef4444, #dc2626); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">❤️</span>
                </div>
                <div>
                  <h3 style="font-weight: bold; font-size: 15px; color: #7f1d1d; line-height: 1.2;">基础健康</h3>
                  <div style="font-size: 11px; font-weight: bold; color: #b91c1c; margin-top: 2px; line-height: 1.2;">${result.dimensionScores.basicHealth}/10分</div>
                </div>
              </div>
              <div style="display: flex; flex-direction: column; gap: 8px; margin-top: 10px;">
                <div style="display: flex; align-items: center; justify-content: space-between; padding: 8px; background: rgba(255,255,255,0.8); border-radius: 8px;">
                  <span style="font-size: 11px; font-weight: bold; color: #374151; line-height: 1.2;">BMI指数</span>
                  <span style="font-size: 11px; font-weight: bold; color: #dc2626; line-height: 1.2;">${result.bmi || '未提供'}</span>
                </div>
                <div style="display: flex; align-items: center; justify-content: space-between; padding: 8px; background: rgba(255,255,255,0.8); border-radius: 8px;">
                  <span style="font-size: 11px; font-weight: bold; color: #374151; line-height: 1.2;">健康状态</span>
                  <span style="font-size: 11px; font-weight: bold; color: #dc2626; line-height: 1.2;">${getBMICategory()}</span>
                </div>
              </div>
            </div>
          </div>

          <!-- 风险控制能力 -->
          <div style="background: linear-gradient(to bottom right, #eff6ff, #dbeafe); padding: 16px; border-radius: 16px; border: 1px solid #bfdbfe; margin-bottom: 20px;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
              <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #3b82f6, #2563eb); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                <span style="font-size: 20px; line-height: 1;">🛡️</span>
              </div>
              <div>
                <h3 style="font-weight: bold; font-size: 15px; color: #1e3a8a; line-height: 1.2;">风险控制能力</h3>
                <div style="font-size: 11px; font-weight: bold; color: #1d4ed8; margin-top: 2px; line-height: 1.2;">${result.dimensionScores.riskFactors}/10分</div>
              </div>
            </div>
            <div style="margin-bottom: 12px; padding: 8px; background: rgba(59, 130, 246, 0.15); border-radius: 8px;">
              <p style="font-size: 11px; font-weight: bold; color: #1e40af; line-height: 1.4; margin: 0;">💡 分数越高，风险控制能力越强</p>
            </div>
            <p style="font-size: 12px; color: #1f2937; line-height: 1.6; margin: 0; padding: 12px; background: rgba(255,255,255,0.8); border-radius: 8px;">
              ${result.dimensionScores.riskFactors >= 10 ? '✅ 无吸烟和过量饮酒，风险控制能力优秀！继续保持' :
               result.dimensionScores.riskFactors >= 7 ? '✨ 基本无重大危险因素，风险控制能力良好，建议继续保持健康习惯' :
               result.dimensionScores.riskFactors >= 4 ? '⚠️ 存在一定危险因素，风险控制能力一般，建议改善' :
               '🚨 危险因素较多，风险控制能力较弱，强烈建议立即改善生活方式'}
            </p>
          </div>

          <!-- 健康风险提示 -->
          ${result.analysis.healthRisks && result.analysis.healthRisks.length > 0 ? `
            <div style="background: linear-gradient(to bottom right, #fef2f2, #ffedd5); padding: 16px; border-radius: 16px; border: 2px solid #fca5a5; margin-bottom: 20px;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #ef4444, #f97316); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">⚠️</span>
                </div>
                <h3 style="font-weight: bold; font-size: 15px; color: #7f1d1d; line-height: 1.2;">健康风险提示</h3>
              </div>
              <ul style="list-style: disc; padding-left: 20px; margin: 0; font-size: 12px; color: #1f2937; line-height: 1.8; background: rgba(255,255,255,0.8); padding: 12px 12px 12px 32px; border-radius: 8px;">
                ${result.analysis.healthRisks.map((risk: string) => `<li style="line-height: 1.8;">${risk}</li>`).join('')}
              </ul>
            </div>
          ` : ''}

          <!-- 改善建议 -->
          <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 20px;">
            <!-- 饮食建议 -->
            <div style="background: linear-gradient(to bottom right, #f0fdf4, #ecfccb); padding: 16px; border-radius: 16px; border: 1px solid #bbf7d0;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #22c55e, #84cc16); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">🥗</span>
                </div>
                <h3 style="font-weight: bold; font-size: 15px; color: #14532d; line-height: 1.2;">饮食建议</h3>
              </div>
              <ul style="list-style: disc; padding-left: 20px; margin: 0; font-size: 12px; color: #1f2937; line-height: 1.8;">
                ${result.recommendations.diet.map((rec: string) => `<li style="line-height: 1.8;">${rec}</li>`).join('')}
              </ul>
            </div>

            <!-- 运动建议 -->
            <div style="background: linear-gradient(to bottom right, #eff6ff, #cffafe); padding: 16px; border-radius: 16px; border: 1px solid #bfdbfe;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #3b82f6, #06b6d4); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">💪</span>
                </div>
                <h3 style="font-weight: bold; font-size: 15px; color: #1e3a8a; line-height: 1.2;">运动建议</h3>
              </div>
              <ul style="list-style: disc; padding-left: 20px; margin: 0; font-size: 12px; color: #1f2937; line-height: 1.8;">
                ${result.recommendations.exercise.map((rec: string) => `<li style="line-height: 1.8;">${rec}</li>`).join('')}
              </ul>
            </div>

            <!-- 睡眠建议 -->
            <div style="background: linear-gradient(to bottom right, #faf5ff, #fae8ff); padding: 16px; border-radius: 16px; border: 1px solid #e9d5ff;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #a855f7, #d946ef); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">🌙</span>
                </div>
                <h3 style="font-weight: bold; font-size: 15px; color: #581c87; line-height: 1.2;">睡眠建议</h3>
              </div>
              <ul style="list-style: disc; padding-left: 20px; margin: 0; font-size: 12px; color: #1f2937; line-height: 1.8;">
                ${result.recommendations.sleep.map((rec: string) => `<li style="line-height: 1.8;">${rec}</li>`).join('')}
              </ul>
            </div>

            <!-- 健康监测 -->
            <div style="background: linear-gradient(to bottom right, #fdf2f8, #fce7f3); padding: 16px; border-radius: 16px; border: 1px solid #fbcfe8;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #ec4899, #f43f5e); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">📊</span>
                </div>
                <h3 style="font-weight: bold; font-size: 15px; color: #831843; line-height: 1.2;">健康监测</h3>
              </div>
              <ul style="list-style: disc; padding-left: 20px; margin: 0; font-size: 12px; color: #1f2937; line-height: 1.8;">
                ${result.recommendations.healthMonitoring.map((rec: string) => `<li style="line-height: 1.8;">${rec}</li>`).join('')}
              </ul>
            </div>

            <!-- 心理支持 - 跨两列 -->
            <div style="grid-column: 1 / -1; background: linear-gradient(to bottom right, #f0fdfa, #ccfbf1); padding: 16px; border-radius: 16px; border: 1px solid #99f6e4;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #14b8a6, #06b6d4); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">💖</span>
                </div>
                <h3 style="font-weight: bold; font-size: 15px; color: #134e4a; line-height: 1.2;">心理支持</h3>
              </div>
              <ul style="list-style: disc; padding-left: 20px; margin: 0; font-size: 12px; color: #1f2937; line-height: 1.8;">
                ${result.recommendations.psychologicalSupport.map((rec: string) => `<li style="line-height: 1.8;">${rec}</li>`).join('')}
              </ul>
            </div>
          </div>

          <!-- 品牌图片 -->
          <div style="margin-top: 24px; margin-bottom: 24px;">
            <img src="/003.png" alt="时悦健康品牌" style="width: 100%; border-radius: 16px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); border: 1px solid #e5e7eb; display: block;" />
          </div>

          <!-- 品牌宣传语 -->
          <div style="text-align: center; padding: 24px; background: linear-gradient(to right, #eff6ff, #eef2ff); border-radius: 16px; border: 1px solid #e5e7eb;">
            <div style="display: flex; align-items: center; justify-content: center; gap: 12px; margin-bottom: 12px;">
              <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #2288D2, #0D2860); border-radius: 12px; display: flex; align-items: center; justify-content: center; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                <span style="color: white; font-weight: bold; font-size: 20px; line-height: 1;">悦</span>
              </div>
            </div>
            <p style="font-size: 15px; font-weight: bold; color: #111827; margin-bottom: 8px; line-height: 1.3;">
              时悦 sayIFine，陪伴减重，轻自生活
            </p>
            <p style="font-size: 13px; color: #6b7280; font-weight: 500; margin: 0; line-height: 1.3;">
              Right By your side，For A lighter Life
            </p>
          </div>
        </div>
      `;

      // 等待内容渲染和图片加载
      await new Promise(resolve => setTimeout(resolve, 1000));

      // 使用html2canvas截图
      const canvas = await html2canvas(tempContainer, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
        imageTimeout: 30000,
        width: tempContainer.scrollWidth,
        height: tempContainer.scrollHeight,
        scrollX: 0,
        scrollY: 0,
        windowWidth: tempContainer.scrollWidth,
        windowHeight: tempContainer.scrollHeight,
      });

      // 转换为图片并下载
      canvas.toBlob(async (blob) => {
        if (!blob) {
          alert('生成图片失败');
          setExporting(false);
          return;
        }

        const timestamp = new Date().toISOString().slice(0, 10);
        const filename = `生活方式评估报告_${timestamp}.png`;

        // 检测是否在移动端
        const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

        if (isMobile || window.navigator.userAgent.includes('MicroMessenger')) {
          // 移动端：尝试使用 navigator.share（如果支持）
          const file = new File([blob], filename, { type: 'image/png' });
          if (navigator.share && typeof navigator.canShare === 'function' && navigator.canShare({ files: [file] })) {
            try {
              await navigator.share({
                files: [file],
                title: '生活方式评估报告',
                text: '我的生活方式评估报告'
              });
            } catch (shareError) {
              console.log('分享失败，使用下载方式', shareError);
              downloadBlob(blob, filename);
            }
          } else {
            downloadBlob(blob, filename);
          }
        } else {
          // 桌面端：直接下载
          downloadBlob(blob, filename);
        }

        // 清理临时容器
        document.body.removeChild(tempContainer);
      }, 'image/png', 0.95);
    } catch (error) {
      console.error('导出失败:', error);
      alert('导出失败，请重试');

      // 清理临时容器
      const tempContainer = document.getElementById('temp-assessment-report');
      if (tempContainer) {
        document.body.removeChild(tempContainer);
      }
    } finally {
      setExporting(false);
    }
  };

  const downloadBlob = (blob: Blob, filename: string) => {
    try {
      // 创建对象 URL
      const url = window.URL.createObjectURL(blob);
      
      // 创建下载链接
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      
      // 设置样式确保链接可见（某些浏览器需要）
      link.style.display = 'none';
      document.body.appendChild(link);
      
      // 触发下载
      link.click();
      
      // 清理
      setTimeout(() => {
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      }, 100);
      
      // 提示用户
      setTimeout(() => {
        alert('图片已开始下载，请在下载文件夹中查看');
      }, 200);
    } catch (error) {
      console.error('下载失败:', error);
      alert('下载失败，请尝试长按图片保存');
    }
  };

  // 按钮选择组件
  const ButtonSelect = ({ options, value, onChange, label, colorScheme = 'blue' }: {
    options: { value: string; label: string; description?: string; score?: 'high' | 'medium' | 'low' | 'neutral' }[];
    value: string;
    onChange: (value: any) => void;
    label?: string;
    colorScheme?: 'red' | 'yellow' | 'blue' | 'green';
  }) => {
    const getColorClass = (score?: 'high' | 'medium' | 'low' | 'neutral') => {
      return 'bg-green-600 hover:bg-green-700';
    };

    return (
      <div className="space-y-2">
        {label && <Label className="text-sm font-medium">{label}</Label>}
        <div className="grid grid-cols-2 gap-2">
          {options.map((option) => (
            <Button
              key={option.value}
              type="button"
              variant={value === option.value ? "default" : "outline"}
              className={`h-auto py-3 text-xs ${
                value === option.value ? getColorClass(option.score) : ''
              }`}
              onClick={() => onChange(option.value)}
            >
              {option.label}
              {option.description && <div className="text-xs opacity-75 mt-1">{option.description}</div>}
            </Button>
          ))}
        </div>
      </div>
    );
  };

  // 是/否选择组件
  const YesNoSelect = ({ value, onChange, label, yesColor = 'green', noColor = 'red' }: {
    value: boolean | undefined;
    onChange: (value: boolean) => void;
    label: string;
    yesColor?: 'red' | 'blue' | 'green';
    noColor?: 'red' | 'blue' | 'green';
  }) => (
    <div className="space-y-2">
      <Label className="text-sm font-medium">{label}</Label>
      <div className="grid grid-cols-2 gap-2">
        <Button
          type="button"
          variant={value === true ? "default" : "outline"}
          className={`h-auto py-3 text-sm ${
            value === true ?
              (yesColor === 'green' ? 'bg-green-600 hover:bg-green-700' :
               yesColor === 'red' ? 'bg-red-600 hover:bg-red-700' :
               'bg-green-600 hover:bg-green-700') : ''
          }`}
          onClick={() => onChange(true)}
        >
          是
        </Button>
        <Button
          type="button"
          variant={value === false ? "default" : "outline"}
          className={`h-auto py-3 text-sm ${
            value === false ?
              (noColor === 'green' ? 'bg-green-600 hover:bg-green-700' :
               noColor === 'red' ? 'bg-red-600 hover:bg-red-700' :
               'bg-green-600 hover:bg-green-700') : ''
          }`}
          onClick={() => onChange(false)}
        >
          否
        </Button>
      </div>
    </div>
  );

  // 如果有结果，显示结果页面
  if (result) {
    // 根据得分获取主题颜色和兔子表情
    const getScoreTheme = () => {
      if (result.totalScore >= 85) {
        return {
          gradient: 'from-green-400 to-emerald-500',
          bgColor: 'bg-green-50',
          textColor: 'text-green-700',
          borderColor: 'border-green-200',
          badgeBg: 'bg-green-100',
          badgeText: 'text-green-700',
          emoji: '😊',
          rabbit: '🐰',
          title: '优秀',
          message: '太棒了！您的生活方式非常健康'
        };
      } else if (result.totalScore >= 70) {
        return {
          gradient: 'from-blue-400 to-indigo-500',
          bgColor: 'bg-blue-50',
          textColor: 'text-blue-700',
          borderColor: 'border-blue-200',
          badgeBg: 'bg-blue-100',
          badgeText: 'text-blue-700',
          emoji: '😄',
          rabbit: '🐰',
          title: '良好',
          message: '不错！您的生活方式较为健康'
        };
      } else if (result.totalScore >= 55) {
        return {
          gradient: 'from-yellow-400 to-orange-400',
          bgColor: 'bg-yellow-50',
          textColor: 'text-yellow-700',
          borderColor: 'border-yellow-200',
          badgeBg: 'bg-yellow-100',
          badgeText: 'text-yellow-700',
          emoji: '😐',
          rabbit: '🐰',
          title: '一般',
          message: '需要改善，您的生活方式有待提升'
        };
      } else if (result.totalScore >= 40) {
        return {
          gradient: 'from-orange-400 to-red-400',
          bgColor: 'bg-orange-50',
          textColor: 'text-orange-700',
          borderColor: 'border-orange-200',
          badgeBg: 'bg-orange-100',
          badgeText: 'text-orange-700',
          emoji: '😟',
          rabbit: '🐰',
          title: '较差',
          message: '要注意了！您的生活方式需要立即改善'
        };
      } else {
        return {
          gradient: 'from-red-400 to-red-600',
          bgColor: 'bg-red-50',
          textColor: 'text-red-700',
          borderColor: 'border-red-200',
          badgeBg: 'bg-red-100',
          badgeText: 'text-red-700',
          emoji: '😢',
          rabbit: '🐰',
          title: '差',
          message: '警告！您的生活方式非常不健康'
        };
      }
    };

    const theme = getScoreTheme();

    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white pb-8">
        <div className="max-w-4xl mx-auto p-3 sm:p-4 lg:p-6">
          {/* 顶部卡片 - 得分展示 */}
          {/* 结果报告卡片 */}
          <div id="assessment-report" className="mb-4 bg-white rounded-3xl shadow-xl border-2 border-gray-100 overflow-hidden">
            {/* 顶部品牌栏 - 简洁版本 */}
            <div className="px-6 py-4 sm:px-8 sm:py-5 border-b-2 border-gray-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 bg-gradient-to-br from-[#2288D2] to-[#0D2860] rounded-xl flex items-center justify-center shadow-sm">
                  <span className="text-white font-bold text-xl">悦</span>
                </div>
                <div>
                  <div className="font-bold text-gray-900 text-base">时悦健康</div>
                  <div className="text-xs text-gray-500">生活方式评估报告</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-gray-700 font-medium">
                  {formData.generalInfo?.name || '匿名'} · {formData.generalInfo?.gender === 'male' ? '男' : '女'} · {formData.generalInfo?.age}岁
                </div>
                <div className="text-xs text-gray-400 mt-1">评估日期</div>
                <div className="text-sm font-semibold text-gray-700">
                  {new Date().toLocaleDateString('zh-CN')}
                </div>
              </div>
            </div>

            {/* 评分头部 - 专业简洁版本 */}
            <div className="bg-gradient-to-br from-[#2288D2] to-[#0D2860] px-6 py-8 sm:px-10 sm:py-10 text-white relative overflow-hidden">
              {/* 简洁的装饰背景 */}
              <div className="absolute top-0 right-0 w-72 h-72 bg-white rounded-full opacity-5 -mr-36 -mt-36 blur-3xl"></div>
              <div className="absolute bottom-0 left-0 w-56 h-56 bg-white rounded-full opacity-5 -ml-28 -mb-28 blur-3xl"></div>

              <div className="relative z-10 text-center">
                {/* 标题 */}
                <div className="text-sm font-semibold opacity-90 mb-4 tracking-wide uppercase">
                  科学减重生活方式评估报告
                </div>

                {/* 得分展示 */}
                <div className="mb-5">
                  <div className="text-8xl sm:text-9xl font-bold leading-none tracking-tight" style={{ textShadow: '0 4px 20px rgba(0,0,0,0.2)' }}>
                    {result.totalScore}
                  </div>
                  <div className="text-base font-medium opacity-90 mt-3">总得分 · 满分100</div>
                </div>

                {/* 评级标签 */}
                <div className="inline-flex items-center px-8 py-4 bg-white/15 backdrop-blur-md rounded-2xl border border-white/30 shadow-lg">
                  <span className="text-2xl sm:text-3xl font-bold tracking-wide">
                    {theme.title}
                  </span>
                </div>

                {/* 简短评语 */}
                <div className="mt-5 text-sm opacity-95 font-medium max-w-md mx-auto leading-relaxed">
                  {theme.message}
                </div>
              </div>

              {/* 品牌图片 */}
              <div className="absolute bottom-0 left-0 right-0 h-1/2 flex items-center justify-center">
                <img
                  src="/003.png"
                  alt="时悦健康"
                  className="h-full max-h-[200px] w-auto opacity-20 object-contain"
                />
              </div>
            </div>

            {/* 评分等级表 - 简洁专业 */}
            <div className="px-6 py-5 sm:px-8 sm:py-6 border-b-2 border-gray-100">
              <div className="text-sm font-bold text-gray-800 mb-4 text-center">评分等级标准</div>
              <div className="grid grid-cols-5 gap-2">
                {[
                  { range: '85-100', label: '优秀', min: 85, max: 100, color: 'bg-green-500' },
                  { range: '70-84', label: '良好', min: 70, max: 84, color: 'bg-blue-500' },
                  { range: '55-69', label: '一般', min: 55, max: 69, color: 'bg-yellow-500' },
                  { range: '40-54', label: '较差', min: 40, max: 54, color: 'bg-orange-500' },
                  { range: '<40', label: '差', min: 0, max: 39, color: 'bg-red-500' },
                ].map((item, index) => {
                  const isActive = result.totalScore >= item.min && result.totalScore <= item.max;
                  return (
                    <div
                      key={index}
                      className={`p-3 text-center rounded-xl border-2 transition-all duration-300 ${
                        isActive
                          ? `${item.color} text-white border-current shadow-lg transform scale-105 font-bold`
                          : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                      }`}
                    >
                      <div className="text-xs font-bold tracking-wide">{item.range}分</div>
                      <div className="text-xs font-medium mt-1">{item.label}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 主要内容区域 */}
            <div className="px-6 py-6 sm:px-8 sm:py-8 space-y-6">
              {/* 雷达图与各维度得分 */}
              <div className="bg-gray-50 p-5 sm:p-6 rounded-2xl border border-gray-200">
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 bg-gradient-to-br from-[#2288D2] to-[#0D2860] rounded-xl flex items-center justify-center shadow-sm">
                    <span className="text-white text-lg">📊</span>
                  </div>
                  <h3 className="font-bold text-gray-900 text-lg">各维度得分分析</h3>
                </div>

                {/* 雷达图 */}
                <div className="flex justify-center mb-5">
                  <div className="w-full max-w-md">
                    <HealthRadarChart
                      data={[
                        { subject: '饮食', score: result.dimensionScores.diet, fullScore: 40 },
                        { subject: '运动', score: result.dimensionScores.exercise, fullScore: 25 },
                        { subject: '睡眠', score: result.dimensionScores.sleep, fullScore: 15 },
                        { subject: '基础健康', score: result.dimensionScores.basicHealth, fullScore: 10 },
                        { subject: '风险控制', score: result.dimensionScores.riskFactors, fullScore: 10 }
                      ]}
                    />
                  </div>
                </div>

                {/* 维度得分卡片 */}
                <div className="grid grid-cols-5 gap-2">
                  {[
                    { label: '饮食', score: result.dimensionScores.diet, fullScore: 40, color: 'border-green-400 bg-green-50 text-green-700' },
                    { label: '运动', score: result.dimensionScores.exercise, fullScore: 25, color: 'border-orange-400 bg-orange-50 text-orange-700' },
                    { label: '睡眠', score: result.dimensionScores.sleep, fullScore: 15, color: 'border-purple-400 bg-purple-50 text-purple-700' },
                    { label: '基础健康', score: result.dimensionScores.basicHealth, fullScore: 10, color: 'border-red-400 bg-red-50 text-red-700' },
                    { label: '风险控制', score: result.dimensionScores.riskFactors, fullScore: 10, color: 'border-blue-400 bg-blue-50 text-blue-700' },
                  ].map((item, index) => (
                    <div key={index} className={`p-3 rounded-xl border-2 ${item.color} text-center`}>
                      <div className="text-xs font-bold">{item.label}</div>
                      <div className="text-lg font-bold mt-1">{item.score}</div>
                      <div className="text-xs font-medium opacity-75">/{item.fullScore}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 总体评价 */}
              <div className={`${theme.bgColor} p-5 sm:p-6 rounded-2xl border-2 ${theme.borderColor}`}>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-11 h-11 bg-gradient-to-br from-[#2288D2] to-[#0D2860] rounded-xl flex items-center justify-center text-xl shadow-sm">
                    💡
                  </div>
                  <h3 className={`font-bold text-lg ${theme.textColor}`}>总体评价</h3>
                </div>
                <p className="text-sm text-gray-700 leading-relaxed pl-14">{result.analysis.overall}</p>
              </div>

              {/* 各维度详细分析 */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* 饮食习惯 */}
                <div className="bg-gradient-to-br from-green-50 to-emerald-100 p-5 rounded-2xl border border-green-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center text-xl shadow-sm">
                      🍎
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-green-900">饮食习惯</h3>
                      <div className="text-xs font-bold text-green-700">{result.dimensionScores.diet}/40分</div>
                    </div>
                  </div>
                  <p className="text-xs text-gray-800 leading-relaxed">{result.analysis.diet}</p>
                </div>

                {/* 运动习惯 */}
                <div className="bg-gradient-to-br from-orange-50 to-amber-100 p-5 rounded-2xl border border-orange-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 bg-gradient-to-br from-orange-500 to-amber-600 rounded-xl flex items-center justify-center text-xl shadow-sm">
                      🏃
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-orange-900">运动习惯</h3>
                      <div className="text-xs font-bold text-orange-700">{result.dimensionScores.exercise}/25分</div>
                    </div>
                  </div>
                  <p className="text-xs text-gray-800 leading-relaxed">{result.analysis.exercise}</p>
                </div>

                {/* 睡眠质量 */}
                <div className="bg-gradient-to-br from-purple-50 to-violet-100 p-5 rounded-2xl border border-purple-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 bg-gradient-to-br from-purple-500 to-violet-600 rounded-xl flex items-center justify-center text-xl shadow-sm">
                      😴
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-purple-900">睡眠质量</h3>
                      <div className="text-xs font-bold text-purple-700">{result.dimensionScores.sleep}/15分</div>
                    </div>
                  </div>
                  <p className="text-xs text-gray-800 leading-relaxed">{result.analysis.sleep}</p>
                </div>

                {/* 基础健康 */}
                <div className="bg-gradient-to-br from-red-50 to-rose-100 p-5 rounded-2xl border border-red-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 bg-gradient-to-br from-red-500 to-rose-600 rounded-xl flex items-center justify-center text-xl shadow-sm">
                      ❤️
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-red-900">基础健康</h3>
                      <div className="text-xs font-bold text-red-700">{result.dimensionScores.basicHealth}/10分</div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 bg-white/80 rounded-lg">
                      <span className="text-xs font-bold text-gray-700">BMI指数</span>
                      <span className="text-xs font-bold text-red-600">{result.bmi || '未提供'}</span>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-white/80 rounded-lg">
                      <span className="text-xs font-bold text-gray-700">健康状态</span>
                      <span className="text-xs font-bold text-red-600">
                        {result.bmiCategory === 'normal' ? '正常' :
                         result.bmiCategory === 'overweight' ? '超重' :
                         result.bmiCategory === 'obesity' ? '肥胖' : '偏瘦'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 风险控制能力 */}
              <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-5 rounded-2xl border border-blue-200">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-11 h-11 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center text-xl shadow-sm">
                    🛡️
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-blue-900">风险控制能力</h3>
                    <div className="text-xs font-bold text-blue-700">{result.dimensionScores.riskFactors}/10分</div>
                  </div>
                </div>
                <div className="mb-3 p-2 bg-blue-100/70 rounded-lg">
                  <p className="text-xs font-bold text-blue-800">💡 分数越高，风险控制能力越强</p>
                </div>
                <p className="text-xs text-gray-800 leading-relaxed bg-white/80 p-3 rounded-lg">
                  {result.dimensionScores.riskFactors >= 10 ? '✅ 无吸烟和过量饮酒，风险控制能力优秀！继续保持' :
                   result.dimensionScores.riskFactors >= 7 ? '✨ 基本无重大危险因素，风险控制能力良好，建议继续保持健康习惯' :
                   result.dimensionScores.riskFactors >= 4 ? '⚠️ 存在一定危险因素，风险控制能力一般，建议改善' :
                   '🚨 危险因素较多，风险控制能力较弱，强烈建议立即改善生活方式'}
                </p>
              </div>

              {/* 健康风险提示 */}
              {result.analysis.healthRisks.length > 0 && (
                <div className="bg-gradient-to-br from-red-50 to-orange-100 p-5 rounded-2xl border-2 border-red-300">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 bg-gradient-to-br from-red-500 to-orange-600 rounded-xl flex items-center justify-center text-xl shadow-sm">
                      ⚠️
                    </div>
                    <h3 className="font-bold text-base text-red-900">健康风险提示</h3>
                  </div>
                  <ul className="list-disc list-inside text-xs text-gray-800 space-y-2 bg-white/80 p-3 rounded-lg">
                    {result.analysis.healthRisks.map((risk: string, index: number) => (
                      <li key={index} className="leading-relaxed">{risk}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* 改善建议 */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* 饮食建议 */}
                <div className="bg-gradient-to-br from-green-50 to-lime-100 p-5 rounded-2xl border border-green-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 bg-gradient-to-br from-green-500 to-lime-600 rounded-xl flex items-center justify-center text-xl shadow-sm">
                      🥗
                    </div>
                    <h3 className="font-bold text-base text-green-900">饮食建议</h3>
                  </div>
                  <ul className="list-disc list-inside text-xs text-gray-800 space-y-2">
                    {result.recommendations.diet.map((rec: string, index: number) => (
                      <li key={index} className="leading-relaxed">{rec}</li>
                    ))}
                  </ul>
                </div>

                {/* 运动建议 */}
                <div className="bg-gradient-to-br from-blue-50 to-cyan-100 p-5 rounded-2xl border border-blue-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center text-xl shadow-sm">
                      💪
                    </div>
                    <h3 className="font-bold text-base text-blue-900">运动建议</h3>
                  </div>
                  <ul className="list-disc list-inside text-xs text-gray-800 space-y-2">
                    {result.recommendations.exercise.map((rec: string, index: number) => (
                      <li key={index} className="leading-relaxed">{rec}</li>
                    ))}
                  </ul>
                </div>

                {/* 睡眠建议 */}
                <div className="bg-gradient-to-br from-purple-50 to-fuchsia-100 p-5 rounded-2xl border border-purple-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 bg-gradient-to-br from-purple-500 to-fuchsia-600 rounded-xl flex items-center justify-center text-xl shadow-sm">
                      🌙
                    </div>
                    <h3 className="font-bold text-base text-purple-900">睡眠建议</h3>
                  </div>
                  <ul className="list-disc list-inside text-xs text-gray-800 space-y-2">
                    {result.recommendations.sleep.map((rec: string, index: number) => (
                      <li key={index} className="leading-relaxed">{rec}</li>
                    ))}
                  </ul>
                </div>

                {/* 健康监测 */}
                <div className="bg-gradient-to-br from-pink-50 to-rose-100 p-5 rounded-2xl border border-pink-200">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 bg-gradient-to-br from-pink-500 to-rose-600 rounded-xl flex items-center justify-center text-xl shadow-sm">
                      📊
                    </div>
                    <h3 className="font-bold text-base text-pink-900">健康监测</h3>
                  </div>
                  <ul className="list-disc list-inside text-xs text-gray-800 space-y-2">
                    {result.recommendations.healthMonitoring.map((rec: string, index: number) => (
                      <li key={index} className="leading-relaxed">{rec}</li>
                    ))}
                  </ul>
                </div>

                {/* 心理支持 */}
                <div className="bg-gradient-to-br from-teal-50 to-cyan-100 p-5 rounded-2xl border border-teal-200 md:col-span-2">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-xl flex items-center justify-center text-xl shadow-sm">
                      💖
                    </div>
                    <h3 className="font-bold text-base text-teal-900">心理支持</h3>
                  </div>
                  <ul className="list-disc list-inside text-xs text-gray-800 space-y-2">
                    {result.recommendations.psychologicalSupport.map((rec: string, index: number) => (
                      <li key={index} className="leading-relaxed">{rec}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* 品牌图片 */}
          <div className="mt-6 mb-4">
            <img
              src="/测试报告底部.png"
              alt="时悦健康品牌"
              className="w-full rounded-2xl shadow-lg border border-gray-200"
            />
          </div>

          {/* 操作按钮 */}
          <div className="space-y-3">
            <Button
              onClick={handleExportAsImage}
              disabled={exporting}
              variant="outline"
              className="w-full h-13 text-base font-semibold shadow-sm hover:shadow-md transition-all rounded-2xl border-2 border-gray-300"
            >
              <Download className="mr-2 h-5 w-5" />
              {exporting ? '导出中...' : '导出为图片'}
            </Button>

            <Button
              onClick={() => { setResult(null); setCurrentStep(1); }}
              className="w-full h-13 text-base font-semibold bg-gradient-to-r from-[#2288D2] to-[#0D2860] hover:from-[#1976D2] hover:to-[#0A1F4D] shadow-sm hover:shadow-md transition-all rounded-2xl"
            >
              <ArrowLeft className="mr-2 h-5 w-5" />
              重新测评
            </Button>
          </div>

          {/* 品牌宣传语 - 简洁版本 */}
          <div className="mt-8 text-center p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl border border-gray-200">
            <div className="flex items-center justify-center gap-3 mb-3">
              <div className="w-11 h-11 bg-gradient-to-br from-[#2288D2] to-[#0D2860] rounded-xl flex items-center justify-center shadow-sm">
                <span className="text-white font-bold text-xl">悦</span>
              </div>
            </div>
            <p className="text-base font-bold text-gray-900 mb-2">
              时悦 sayIFine，陪伴减重，轻自生活
            </p>
            <p className="text-sm text-gray-600 font-medium">
              Right By your side，For A lighter Life
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="max-w-2xl mx-auto p-4">
        {/* Logo和吉祥物 */}
        <div className="flex items-center justify-center mb-6">
          <img src="/logo-mascot.png" alt="Logo" className="h-20 w-auto" />
        </div>

        {/* 进度指示器 */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            {Array.from({ length: TOTAL_STEPS }).map((_, index) => (
              <div
                key={index}
                className={`flex items-center justify-center w-8 h-8 rounded-full text-xs font-semibold ${
                  currentStep > index + 1
                    ? 'bg-green-500 text-white'
                    : currentStep === index + 1
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-600'
                }`}
              >
                {currentStep > index + 1 ? (
                  <Check className="w-4 h-4" />
                ) : (
                  index + 1
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-xs text-gray-600">
            <span>基本信息</span>
            <span>身体情况</span>
            <span>既往史</span>
            <span>饮食评估</span>
            <span>运动评估</span>
            <span>睡眠评估</span>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">
              {currentStep === 1 && '一般信息'}
              {currentStep === 2 && '身体情况'}
              {currentStep === 3 && '既往史'}
              {currentStep === 4 && '饮食评估'}
              {currentStep === 5 && '运动评估'}
              {currentStep === 6 && '睡眠评估'}
            </CardTitle>
            <CardDescription className="text-sm">
              生活方式评估问卷 - 第 {currentStep}/{TOTAL_STEPS} 步
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* 步骤 1: 一般信息 */}
            {currentStep === 1 && (
              <div className="space-y-4">
                <div data-field="generalInfo.name" className="mb-4">
                  {fieldErrors['generalInfo.name'] && (
                    <div className="mb-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-sm text-red-600 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 flex-shrink-0" />
                        {fieldErrors['generalInfo.name']}
                      </p>
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">姓名</Label>
                    <Input
                      type="text"
                      placeholder="请输入您的姓名"
                      value={formData.generalInfo?.name || ''}
                      onChange={(e) =>
                        updateFormData('generalInfo', { ...formData.generalInfo, name: e.target.value }, 'generalInfo.name')
                      }
                    />
                  </div>
                </div>

                <div data-field="generalInfo.gender" className="mb-4">
                  {fieldErrors['generalInfo.gender'] && (
                    <div className="mb-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-sm text-red-600 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 flex-shrink-0" />
                        {fieldErrors['generalInfo.gender']}
                      </p>
                    </div>
                  )}
                  <ButtonSelect
                    label="性别"
                    options={[
                      { value: 'male', label: '男' },
                      { value: 'female', label: '女' }
                    ]}
                    value={formData.generalInfo?.gender as 'male' | 'female'}
                    onChange={(value: 'male' | 'female') =>
                      updateFormData('generalInfo', { ...formData.generalInfo, gender: value }, 'generalInfo.gender')
                    }
                  />
                </div>

                <div data-field="generalInfo.age" className="mb-4">
                  {fieldErrors['generalInfo.age'] && (
                    <div className="mb-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-sm text-red-600 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 flex-shrink-0" />
                        {fieldErrors['generalInfo.age']}
                      </p>
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">年龄（岁）</Label>
                    <Input
                      type="number"
                      inputMode="numeric"
                      value={formData.generalInfo?.age || ''}
                      onChange={(e) =>
                        updateFormData('generalInfo', { ...formData.generalInfo, age: parseInt(e.target.value) || 0 }, 'generalInfo.age')
                      }
                      placeholder="请输入年龄"
                    />
                  </div>
                </div>

                <div data-field="generalInfo.smoking.isSmoking" className="mb-4">
                  {fieldErrors['generalInfo.smoking.isSmoking'] && (
                    <div className="mb-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-sm text-red-600 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 flex-shrink-0" />
                        {fieldErrors['generalInfo.smoking.isSmoking']}
                      </p>
                    </div>
                  )}
                  <YesNoSelect
                    label="是否吸烟"
                    value={formData.generalInfo?.smoking?.isSmoking}
                    onChange={(value) =>
                      updateFormData('generalInfo', {
                        ...formData.generalInfo,
                        smoking: { isSmoking: value, cigarettesPerDay: value ? 10 : undefined }
                      }, 'generalInfo.smoking.isSmoking')
                    }
                    yesColor="red"
                    noColor="green"
                  />
                </div>
                {formData.generalInfo?.smoking?.isSmoking && (
                  <div data-field="generalInfo.smoking.cigarettesPerDay" className="mb-4 ml-2">
                    {fieldErrors['generalInfo.smoking.cigarettesPerDay'] && (
                      <div className="mb-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                        <p className="text-sm text-red-600 flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 flex-shrink-0" />
                          {fieldErrors['generalInfo.smoking.cigarettesPerDay']}
                        </p>
                      </div>
                    )}
                    <Label className="text-xs text-gray-600">每天吸烟支数（支/天）</Label>
                    <Input
                      type="number"
                      inputMode="numeric"
                      placeholder="如：10"
                      value={formData.generalInfo?.smoking?.cigarettesPerDay || ''}
                      onChange={(e) =>
                        updateFormData('generalInfo', {
                          ...formData.generalInfo,
                          smoking: { ...formData.generalInfo!.smoking, cigarettesPerDay: parseInt(e.target.value) }
                        }, 'generalInfo.smoking.cigarettesPerDay')
                      }
                    />
                  </div>
                )}

                <div data-field="generalInfo.drinking.isDrinking" className="mb-4">
                  {fieldErrors['generalInfo.drinking.isDrinking'] && (
                    <div className="mb-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-sm text-red-600 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 flex-shrink-0" />
                        {fieldErrors['generalInfo.drinking.isDrinking']}
                      </p>
                    </div>
                  )}
                  <YesNoSelect
                    label="是否饮酒"
                    value={formData.generalInfo?.drinking?.isDrinking}
                    onChange={(value) =>
                      updateFormData('generalInfo', {
                        ...formData.generalInfo,
                        drinking: { isDrinking: value, gramsOfAlcoholPerDay: value ? 10 : undefined }
                      }, 'generalInfo.drinking.isDrinking')
                  }
                  yesColor="red"
                  noColor="green"
                />
                {formData.generalInfo?.drinking?.isDrinking && (
                  <div data-field="generalInfo.drinking.gramsOfAlcoholPerDay" className="mb-4 ml-2">
                    {fieldErrors['generalInfo.drinking.gramsOfAlcoholPerDay'] && (
                      <div className="mb-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                        <p className="text-sm text-red-600 flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 flex-shrink-0" />
                          {fieldErrors['generalInfo.drinking.gramsOfAlcoholPerDay']}
                        </p>
                      </div>
                    )}
                    <Label className="text-xs text-gray-600">
                      每天摄入酒精量（克/天）
                      <div className="flex items-center text-xs text-gray-500 mt-1">
                        <Info className="w-3 h-3 mr-1" />
                        计算：摄入量（毫升）× 含酒精度（%）
                      </div>
                    </Label>
                    <Input
                      type="number"
                      inputMode="decimal"
                      placeholder="如：15"
                      value={formData.generalInfo?.drinking?.gramsOfAlcoholPerDay || ''}
                      onChange={(e) =>
                        updateFormData('generalInfo', {
                          ...formData.generalInfo,
                          drinking: { ...formData.generalInfo!.drinking, gramsOfAlcoholPerDay: parseInt(e.target.value) }
                        }, 'generalInfo.drinking.gramsOfAlcoholPerDay')
                      }
                    />
                  </div>
                )}
              </div>
            </div>
            )}

            {/* 步骤 2: 身体情况 */}
            {currentStep === 2 && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div data-field="enrollmentInfo.height" className="mb-4">
                    {fieldErrors['enrollmentInfo.height'] && (
                      <div className="mb-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                        <p className="text-sm text-red-600 flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 flex-shrink-0" />
                          {fieldErrors['enrollmentInfo.height']}
                        </p>
                      </div>
                    )}
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">身高</Label>
                      <Input
                        type="number"
                        inputMode="decimal"
                        step="0.1"
                        min="0"
                        max="300"
                        placeholder="如：175.5"
                        value={formData.enrollmentInfo?.height || ''}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          updateFormData('enrollmentInfo', {
                            ...formData.enrollmentInfo,
                            height: val || undefined
                          }, 'enrollmentInfo.height');
                        }}
                      />
                    </div>
                  </div>
                  <div data-field="enrollmentInfo.weight" className="mb-4">
                    {fieldErrors['enrollmentInfo.weight'] && (
                      <div className="mb-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                        <p className="text-sm text-red-600 flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 flex-shrink-0" />
                          {fieldErrors['enrollmentInfo.weight']}
                        </p>
                      </div>
                    )}
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">体重</Label>
                      <Input
                        type="number"
                        inputMode="decimal"
                        step="0.1"
                        min="0"
                        max="500"
                        placeholder="如：70.5"
                        value={formData.enrollmentInfo?.weight || ''}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          updateFormData('enrollmentInfo', {
                            ...formData.enrollmentInfo,
                            weight: val || undefined
                          }, 'enrollmentInfo.weight');
                        }}
                      />
                      {formData.enrollmentInfo?.weight && formData.enrollmentInfo?.height && formData.enrollmentInfo.weight > (formData.enrollmentInfo.height - 100) * 2 && (
                        <div className="flex items-start text-xs text-orange-600 mt-1">
                          <AlertCircle className="w-3 h-3 mr-1 mt-0.5 flex-shrink-0" />
                          <span>体重数据偏高，请确认单位是否正确（应为千克/kg）</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div data-field="enrollmentInfo.waistline" className="mb-4">
                  {fieldErrors['enrollmentInfo.waistline'] && (
                    <div className="mb-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-sm text-red-600 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 flex-shrink-0" />
                        {fieldErrors['enrollmentInfo.waistline']}
                      </p>
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">腰围</Label>
                    <Input
                      type="number"
                      inputMode="decimal"
                      step="0.1"
                      min="0"
                      max="200"
                      placeholder="如：85.5"
                      value={formData.enrollmentInfo?.waistline || ''}
                      onChange={(e) =>
                        updateFormData('enrollmentInfo', { ...formData.enrollmentInfo, waistline: parseFloat(e.target.value) || undefined }, 'enrollmentInfo.waistline')
                      }
                    />
                  </div>
                </div>

                <div data-field="enrollmentInfo.weightLossDetermination" className="mb-4">
                  {fieldErrors['enrollmentInfo.weightLossDetermination'] && (
                    <div className="mb-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-sm text-red-600 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 flex-shrink-0" />
                        {fieldErrors['enrollmentInfo.weightLossDetermination']}
                      </p>
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">减重决心</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        type="button"
                        variant={formData.enrollmentInfo?.weightLossDetermination === 'low' ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.enrollmentInfo?.weightLossDetermination === 'low' ? 'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() => updateFormData('enrollmentInfo', { ...formData.enrollmentInfo, weightLossDetermination: 'low' }, 'enrollmentInfo.weightLossDetermination')}
                      >
                        低决心（0-3分）
                      </Button>
                      <Button
                        type="button"
                        variant={formData.enrollmentInfo?.weightLossDetermination === 'medium' ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.enrollmentInfo?.weightLossDetermination === 'medium' ? 'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() => updateFormData('enrollmentInfo', { ...formData.enrollmentInfo, weightLossDetermination: 'medium' }, 'enrollmentInfo.weightLossDetermination')}
                      >
                        中等（4-6分）
                      </Button>
                      <Button
                        type="button"
                        variant={formData.enrollmentInfo?.weightLossDetermination === 'high' ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.enrollmentInfo?.weightLossDetermination === 'high' ? 'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() => updateFormData('enrollmentInfo', { ...formData.enrollmentInfo, weightLossDetermination: 'high' }, 'enrollmentInfo.weightLossDetermination')}
                      >
                        高决心（7-9分）
                      </Button>
                      <Button
                        type="button"
                        variant={formData.enrollmentInfo?.weightLossDetermination === 'veryHigh' ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.enrollmentInfo?.weightLossDetermination === 'veryHigh' ? 'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() => updateFormData('enrollmentInfo', { ...formData.enrollmentInfo, weightLossDetermination: 'veryHigh' }, 'enrollmentInfo.weightLossDetermination')}
                      >
                        极高（10分）
                      </Button>
                    </div>
                  </div>
                </div>

                <div data-field="enrollmentInfo.bloodPressurePulseUnknown" className="mb-4">
                  {fieldErrors['enrollmentInfo.bloodPressurePulseUnknown'] && (
                    <div className="mb-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-sm text-red-600 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 flex-shrink-0" />
                        {fieldErrors['enrollmentInfo.bloodPressurePulseUnknown']}
                      </p>
                    </div>
                  )}
                  {!formData.enrollmentInfo?.bloodPressurePulseUnknown && (
                    <div className="space-y-3">
                      <Label className="text-sm font-medium">血压与脉搏</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          {fieldErrors['enrollmentInfo.systolicBloodPressure'] && (
                            <div className="mb-1 p-2 bg-red-50 border border-red-200 rounded-lg">
                              <p className="text-xs text-red-600">{fieldErrors['enrollmentInfo.systolicBloodPressure']}</p>
                            </div>
                          )}
                          <Label className="text-xs text-gray-600">收缩压</Label>
                          <Input
                            type="number"
                            inputMode="numeric"
                            min="0"
                            max="300"
                            placeholder="如：120"
                            value={formData.enrollmentInfo?.systolicBloodPressure || ''}
                            onChange={(e) =>
                              updateFormData('enrollmentInfo', { ...formData.enrollmentInfo, systolicBloodPressure: parseInt(e.target.value) || undefined, bloodPressurePulseUnknown: false }, 'enrollmentInfo.systolicBloodPressure')
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          {fieldErrors['enrollmentInfo.diastolicBloodPressure'] && (
                            <div className="mb-1 p-2 bg-red-50 border border-red-200 rounded-lg">
                              <p className="text-xs text-red-600">{fieldErrors['enrollmentInfo.diastolicBloodPressure']}</p>
                            </div>
                          )}
                          <Label className="text-xs text-gray-600">舒张压</Label>
                          <Input
                            type="number"
                            inputMode="numeric"
                            min="0"
                            max="200"
                            placeholder="如：80"
                            value={formData.enrollmentInfo?.diastolicBloodPressure || ''}
                            onChange={(e) =>
                              updateFormData('enrollmentInfo', { ...formData.enrollmentInfo, diastolicBloodPressure: parseInt(e.target.value) || undefined, bloodPressurePulseUnknown: false }, 'enrollmentInfo.diastolicBloodPressure')
                            }
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        {fieldErrors['enrollmentInfo.pulse'] && (
                          <div className="mb-1 p-2 bg-red-50 border border-red-200 rounded-lg">
                            <p className="text-xs text-red-600">{fieldErrors['enrollmentInfo.pulse']}</p>
                          </div>
                        )}
                        <Label className="text-xs text-gray-600">脉搏（次/分）</Label>
                        <Input
                          type="number"
                          inputMode="numeric"
                          min="0"
                          max="200"
                          placeholder="如：72"
                          value={formData.enrollmentInfo?.pulse || ''}
                          onChange={(e) =>
                            updateFormData('enrollmentInfo', { ...formData.enrollmentInfo, pulse: parseInt(e.target.value) || undefined, bloodPressurePulseUnknown: false }, 'enrollmentInfo.pulse')
                          }
                        />
                      </div>
                    </div>
                  )}

                  <Button
                    type="button"
                    variant={formData.enrollmentInfo?.bloodPressurePulseUnknown ? "default" : "outline"}
                    className={`w-full h-auto py-3 text-sm ${
                      formData.enrollmentInfo?.bloodPressurePulseUnknown ? 'bg-green-600 hover:bg-green-700' : ''
                    }`}
                    onClick={() => {
                      updateFormData('enrollmentInfo', {
                        ...formData.enrollmentInfo,
                        bloodPressurePulseUnknown: !formData.enrollmentInfo?.bloodPressurePulseUnknown
                      }, 'enrollmentInfo.bloodPressurePulseUnknown');
                    }}
                  >
                    {formData.enrollmentInfo?.bloodPressurePulseUnknown ? '✓ 我不知道血压与脉搏数据' : '我不知道血压与脉搏数据'}
                  </Button>
                </div>
              </div>
            )}

            {/* 步骤 3: 既往史 */}
            {currentStep === 3 && (
              <div className="space-y-4">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <Label className="text-sm font-medium flex items-center">
                    <Info className="w-4 h-4 mr-2" />
                    请选择您是否患有以下疾病
                  </Label>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {[
                    { key: 'hyperlipidemia', label: '高脂血症' },
                    { key: 'fattyLiver', label: '脂肪肝' },
                    { key: 'hypertension', label: '高血压' },
                    { key: 'coronaryHeartDisease', label: '冠心病' },
                    { key: 'heartFailure', label: '心衰' },
                    { key: 'highBloodSugar', label: '高血糖' },
                    { key: 'diabetes', label: '糖尿病' },
                    { key: 'hyperuricemia', label: '高尿酸血症' },
                    { key: 'gout', label: '痛风' },
                    { key: 'pancreatitis', label: '胰腺炎' },
                    { key: 'thyroidRelated', label: '甲状腺相关' }
                  ].map((item) => (
                    <Button
                      key={item.key}
                      type="button"
                      variant={formData.medicalHistory?.[item.key as keyof typeof formData.medicalHistory] ? "default" : "outline"}
                      className={`h-auto py-3 text-xs ${
                        formData.medicalHistory?.[item.key as keyof typeof formData.medicalHistory] ? 'bg-green-600 hover:bg-green-700' : ''
                      }`}
                      onClick={() => {
                        updateFormData('medicalHistory', {
                          ...formData.medicalHistory,
                          noDiseases: false,
                          [item.key]: !formData.medicalHistory?.[item.key as keyof typeof formData.medicalHistory]
                        }, 'medicalHistory.any');
                        clearFieldError('medicalHistory.any');
                      }}
                    >
                      {formData.medicalHistory?.[item.key as keyof typeof formData.medicalHistory] ? '✓ ' : ''}{item.label}
                    </Button>
                  ))}
                </div>

                <Button
                  type="button"
                  variant={formData.medicalHistory?.noDiseases ? "default" : "outline"}
                  className={`w-full h-auto py-3 text-sm font-semibold ${
                    formData.medicalHistory?.noDiseases ? 'bg-green-600 hover:bg-green-700' : ''
                  }`}
                  onClick={() => {
                    updateFormData('medicalHistory', {
                      noDiseases: true,
                      hyperlipidemia: false,
                      fattyLiver: false,
                      hypertension: false,
                      coronaryHeartDisease: false,
                      heartFailure: false,
                      highBloodSugar: false,
                      diabetes: false,
                      hyperuricemia: false,
                      gout: false,
                      pancreatitis: false,
                      thyroidRelated: false,
                      others: ''
                    }, 'medicalHistory.any');
                    clearFieldError('medicalHistory.any');
                  }}
                >
                  我没有以上疾病
                </Button>

                <div className="space-y-2">
                  <Label className="text-xs text-gray-600">其他疾病（选填）</Label>
                  <Input
                    placeholder="如有其他疾病，请填写"
                    value={formData.medicalHistory?.others || ''}
                    onChange={(e) =>
                      updateFormData('medicalHistory', {
                        ...formData.medicalHistory,
                        others: e.target.value
                      })
                    }
                  />
                </div>

                {fieldErrors['medicalHistory.any'] && (
                  <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-sm text-red-600 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                      {fieldErrors['medicalHistory.any']}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* 步骤 4: 饮食评估 */}
            {currentStep === 4 && (
              <div className="space-y-4">
                {Object.keys(fieldErrors).filter(key => key.startsWith('dietAssessment')).length > 0 && (
                  <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-sm font-medium text-red-700 mb-2 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                      请完成以下必填项
                    </p>
                    <ul className="list-disc list-inside text-xs text-red-600 space-y-1">
                      {Object.keys(fieldErrors).filter(key => key.startsWith('dietAssessment')).map((key, index) => (
                        <li key={index}>{fieldErrors[key]}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="space-y-3">
                  <Label className="text-sm font-medium">您每日饮食的主食类型是？</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={formData.dietAssessment?.foodSelection?.stapleFood === 'refined' ? "default" : "outline"}
                      className={`h-auto py-3 text-xs ${
                        formData.dietAssessment?.foodSelection?.stapleFood === 'refined' ? 'bg-green-600 hover:bg-green-700' : ''
                      }`}
                      onClick={() =>
                        updateFormData('dietAssessment', {
                          ...formData.dietAssessment,
                          foodSelection: { ...formData.dietAssessment!.foodSelection, stapleFood: 'refined' }
                        })
                      }
                    >
                      以精制米面为主
                    </Button>
                    <Button
                      type="button"
                      variant={formData.dietAssessment?.foodSelection?.stapleFood === 'mixed' ? "default" : "outline"}
                      className={`h-auto py-3 text-xs ${
                        formData.dietAssessment?.foodSelection?.stapleFood === 'mixed' ? 'bg-green-600 hover:bg-green-700' : ''
                      }`}
                      onClick={() =>
                        updateFormData('dietAssessment', {
                          ...formData.dietAssessment,
                          foodSelection: { ...formData.dietAssessment!.foodSelection, stapleFood: 'mixed' }
                        })
                      }
                    >
                      粗细搭配
                      <div className="text-xs opacity-75 mt-1">杂粮、薯类</div>
                    </Button>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">您每日饮食中蛋白质的主要来源是？</Label>
                  <div className="grid grid-cols-1 gap-2">
                    <Button
                      type="button"
                      variant={formData.dietAssessment?.foodSelection?.proteinSource === 'balanced' ? "default" : "outline"}
                      className={`h-auto py-3 text-xs ${
                        formData.dietAssessment?.foodSelection?.proteinSource === 'balanced' ? 'bg-green-600 hover:bg-green-700' : ''
                      }`}
                      onClick={() =>
                        updateFormData('dietAssessment', {
                          ...formData.dietAssessment,
                          foodSelection: { ...formData.dietAssessment!.foodSelection, proteinSource: 'balanced' }
                        })
                      }
                    >
                      均衡搭配
                      <div className="text-xs opacity-75 mt-1">畜肉+禽肉+鱼虾+豆制品+蛋奶</div>
                    </Button>
                    <Button
                      type="button"
                      variant={formData.dietAssessment?.foodSelection?.proteinSource === 'simple' ? "default" : "outline"}
                      className={`h-auto py-3 text-xs ${
                        formData.dietAssessment?.foodSelection?.proteinSource === 'simple' ? 'bg-green-600 hover:bg-green-700' : ''
                      }`}
                      onClick={() =>
                        updateFormData('dietAssessment', {
                          ...formData.dietAssessment,
                          foodSelection: { ...formData.dietAssessment!.foodSelection, proteinSource: 'simple' }
                        })
                      }
                    >
                      较单一
                      <div className="text-xs opacity-75 mt-1">如以畜肉为主</div>
                    </Button>
                    <Button
                      type="button"
                      variant={formData.dietAssessment?.foodSelection?.proteinSource === 'insufficient' ? "default" : "outline"}
                      className={`h-auto py-3 px-4 text-xs flex flex-col items-center text-center ${
                        formData.dietAssessment?.foodSelection?.proteinSource === 'insufficient' ? 'bg-green-600 hover:bg-green-700' : ''
                      }`}
                      onClick={() =>
                        updateFormData('dietAssessment', {
                          ...formData.dietAssessment,
                          foodSelection: { ...formData.dietAssessment!.foodSelection, proteinSource: 'insufficient' }
                        })
                      }
                    >
                      <div className="font-semibold">蛋白质摄入不足</div>
                      <div className="text-xs opacity-75 mt-2 w-full space-y-1">
                        <div className="font-medium">科学标准：成人每日需0.8-1.2g/kg体重</div>
                        <div>60kg成人约需48-72g蛋白质</div>
                        <div className="mt-1 opacity-75">不足可致：肌肉流失、代谢下降、免疫力降低</div>
                      </div>
                    </Button>
                  </div>
                </div>

                <YesNoSelect
                  label="您每日饮食中是否偏好吃加工肉（香肠、培根等）？"
                  value={formData.dietAssessment?.foodSelection?.processedMeatPreference}
                  onChange={(value) =>
                    updateFormData('dietAssessment', {
                      ...formData.dietAssessment,
                      foodSelection: { ...formData.dietAssessment!.foodSelection, processedMeatPreference: value }
                    })
                  }
                  yesColor="red"
                  noColor="green"
                />

                <div className="space-y-3">
                  <Label className="text-sm font-medium flex items-center">
                    <Info className="w-4 h-4 mr-2" />
                    蔬果摄入情况
                  </Label>

                  <YesNoSelect
                    label="每日蔬菜量≥300g"
                    value={formData.dietAssessment?.fruitVegetableIntake?.vegetable300gOrMore}
                    onChange={(value) =>
                      updateFormData('dietAssessment', {
                        ...formData.dietAssessment,
                        fruitVegetableIntake: { ...formData.dietAssessment!.fruitVegetableIntake, vegetable300gOrMore: value }
                      })
                    }
                    yesColor="green"
                    noColor="red"
                  />

                  {formData.dietAssessment?.fruitVegetableIntake?.vegetable300gOrMore && (
                    <div className="space-y-2 ml-2">
                      <Label className="text-xs text-gray-600">深色菜占比（%）</Label>
                      <Input
                        type="number"
                        inputMode="numeric"
                        min="0"
                        max="100"
                        placeholder="如：50"
                        value={formData.dietAssessment?.fruitVegetableIntake?.darkVegetableRatio || ''}
                        onChange={(e) =>
                          updateFormData('dietAssessment', {
                            ...formData.dietAssessment,
                            fruitVegetableIntake: { ...formData.dietAssessment!.fruitVegetableIntake, darkVegetableRatio: parseInt(e.target.value) || 0 }
                          })
                        }
                      />
                    </div>
                  )}

                  <YesNoSelect
                    label="每日水果量≥200g"
                    value={formData.dietAssessment?.fruitVegetableIntake?.fruit200gOrMore}
                    onChange={(value) =>
                      updateFormData('dietAssessment', {
                        ...formData.dietAssessment,
                        fruitVegetableIntake: { ...formData.dietAssessment!.fruitVegetableIntake, fruit200gOrMore: value }
                      })
                    }
                    yesColor="green"
                    noColor="red"
                  />

                  <YesNoSelect
                    label="用果汁替代水果"
                    value={formData.dietAssessment?.fruitVegetableIntake?.juiceInsteadOfFruit}
                    onChange={(value) =>
                      updateFormData('dietAssessment', {
                        ...formData.dietAssessment,
                        fruitVegetableIntake: { ...formData.dietAssessment!.fruitVegetableIntake, juiceInsteadOfFruit: value }
                      })
                    }
                    yesColor="red"
                  noColor="green"
                  />

                  <YesNoSelect
                    label="常吃腌制/罐头果蔬"
                    value={formData.dietAssessment?.fruitVegetableIntake?.cannedPickledFruitsAndVegetables}
                    onChange={(value) =>
                      updateFormData('dietAssessment', {
                        ...formData.dietAssessment,
                        fruitVegetableIntake: { ...formData.dietAssessment!.fruitVegetableIntake, cannedPickledFruitsAndVegetables: value }
                      })
                    }
                    yesColor="red"
                    noColor="green"
                  />
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">油脂与调味</Label>

                  <div className="space-y-2">
                    <Label className="text-xs text-gray-600">烹饪用油</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        type="button"
                        variant={formData.dietAssessment?.oilAndSeasoning?.cookingOilType === 'vegetable' ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.dietAssessment?.oilAndSeasoning?.cookingOilType === 'vegetable' ? 'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() =>
                          updateFormData('dietAssessment', {
                            ...formData.dietAssessment,
                            oilAndSeasoning: { ...formData.dietAssessment!.oilAndSeasoning, cookingOilType: 'vegetable' }
                          })
                        }
                      >
                        以植物油为主
                      </Button>
                      <Button
                        type="button"
                        variant={formData.dietAssessment?.oilAndSeasoning?.cookingOilType === 'animal' ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.dietAssessment?.oilAndSeasoning?.cookingOilType === 'animal' ? 'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() =>
                          updateFormData('dietAssessment', {
                            ...formData.dietAssessment,
                            oilAndSeasoning: { ...formData.dietAssessment!.oilAndSeasoning, cookingOilType: 'animal' }
                          })
                        }
                      >
                        以动物油为主
                      </Button>
                    </div>
                    <Button
                      type="button"
                      variant={formData.dietAssessment?.oilAndSeasoning?.cookingOilType === 'mixed' ? "default" : "outline"}
                      className={`w-full h-auto py-3 text-xs ${
                        formData.dietAssessment?.oilAndSeasoning?.cookingOilType === 'mixed' ? 'bg-green-600 hover:bg-green-700' : ''
                      }`}
                      onClick={() =>
                        updateFormData('dietAssessment', {
                          ...formData.dietAssessment,
                          oilAndSeasoning: { ...formData.dietAssessment!.oilAndSeasoning, cookingOilType: 'mixed' }
                        })
                      }
                    >
                      植物油与动物油混合使用
                    </Button>
                  </div>

                  <YesNoSelect
                    label="每日油量超标（推荐25-30g）"
                    value={formData.dietAssessment?.oilAndSeasoning?.oilIntakeExceeded}
                    onChange={(value) =>
                      updateFormData('dietAssessment', {
                        ...formData.dietAssessment,
                        oilAndSeasoning: { ...formData.dietAssessment!.oilAndSeasoning, oilIntakeExceeded: value }
                      })
                    }
                    yesColor="red"
                    noColor="green"
                  />

                  <YesNoSelect
                    label="每日盐摄入超标（推荐≤5g）"
                    value={formData.dietAssessment?.oilAndSeasoning?.saltIntakeExceeded}
                    onChange={(value) =>
                      updateFormData('dietAssessment', {
                        ...formData.dietAssessment,
                        oilAndSeasoning: { ...formData.dietAssessment!.oilAndSeasoning, saltIntakeExceeded: value }
                      })
                    }
                    yesColor="red"
                    noColor="green"
                  />
                  <div className="flex items-start text-xs text-gray-500 ml-2">
                    <Info className="w-3 h-3 mr-1 mt-0.5 flex-shrink-0" />
                    <span>注：鸡精、酱油中均含有大量的盐</span>
                  </div>

                  <YesNoSelect
                    label="每日添加糖摄入超标（推荐≤25g）"
                    value={formData.dietAssessment?.oilAndSeasoning?.sugarIntakeExceeded}
                    onChange={(value) =>
                      updateFormData('dietAssessment', {
                        ...formData.dietAssessment,
                        oilAndSeasoning: { ...formData.dietAssessment!.oilAndSeasoning, sugarIntakeExceeded: value }
                      })
                    }
                    yesColor="red"
                    noColor="green"
                  />
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">您进餐的速度通常为？</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={formData.dietAssessment?.eatingSpeed === 'veryFast' ? "default" : "outline"}
                      className={`h-auto py-3 text-xs ${
                        formData.dietAssessment?.eatingSpeed === 'veryFast' ? 'bg-green-600 hover:bg-green-700' : ''
                      }`}
                      onClick={() => updateFormData('dietAssessment', { ...formData.dietAssessment, eatingSpeed: 'veryFast' })}
                    >
                      非常快
                      <div className="text-xs opacity-75 mt-1">&lt;10分钟</div>
                    </Button>
                    <Button
                      type="button"
                      variant={formData.dietAssessment?.eatingSpeed === 'fast' ? "default" : "outline"}
                      className={`h-auto py-3 text-xs ${
                        formData.dietAssessment?.eatingSpeed === 'fast' ? 'bg-green-600 hover:bg-green-700' : ''
                      }`}
                      onClick={() => updateFormData('dietAssessment', { ...formData.dietAssessment, eatingSpeed: 'fast' })}
                    >
                      较快
                      <div className="text-xs opacity-75 mt-1">10-15分钟</div>
                    </Button>
                    <Button
                      type="button"
                      variant={formData.dietAssessment?.eatingSpeed === 'normal' ? "default" : "outline"}
                      className={`h-auto py-3 text-xs ${
                        formData.dietAssessment?.eatingSpeed === 'normal' ? 'bg-green-600 hover:bg-green-700' : ''
                      }`}
                      onClick={() => updateFormData('dietAssessment', { ...formData.dietAssessment, eatingSpeed: 'normal' })}
                    >
                      正常
                      <div className="text-xs opacity-75 mt-1">15-20分钟</div>
                    </Button>
                    <Button
                      type="button"
                      variant={formData.dietAssessment?.eatingSpeed === 'slow' ? "default" : "outline"}
                      className={`h-auto py-3 text-xs ${
                        formData.dietAssessment?.eatingSpeed === 'slow' ? 'bg-green-600 hover:bg-green-700' : ''
                      }`}
                      onClick={() => updateFormData('dietAssessment', { ...formData.dietAssessment, eatingSpeed: 'slow' })}
                    >
                      较慢
                      <div className="text-xs opacity-75 mt-1">&gt;20分钟</div>
                    </Button>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">您吃早餐的频率为？</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: 'daily', label: '每天吃', score: 'high' as const },
                      { value: '5-6days', label: '5-6天/周', score: 'medium' as const },
                      { value: '≤4days', label: '≤4天/周', score: 'low' as const }
                    ].map((option) => (
                      <Button
                        key={option.value}
                        type="button"
                        variant={formData.dietAssessment?.mealRegularity?.breakfastFrequency === option.value ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.dietAssessment?.mealRegularity?.breakfastFrequency === option.value ? 
                            'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() =>
                          updateFormData('dietAssessment', {
                            ...formData.dietAssessment,
                            mealRegularity: { ...formData.dietAssessment!.mealRegularity, breakfastFrequency: option.value }
                          })
                        }
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">您晚餐的时间通常为？</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: '≤19:00', label: '≤19:00', score: 'high' as const },
                      { value: '19:00-21:00', label: '19:00-21:00', score: 'medium' as const },
                      { value: '≥21:00', label: '≥21:00', score: 'low' as const }
                    ].map((option) => (
                      <Button
                        key={option.value}
                        type="button"
                        variant={formData.dietAssessment?.mealRegularity?.dinnerTime === option.value ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.dietAssessment?.mealRegularity?.dinnerTime === option.value ? 
                            'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() =>
                          updateFormData('dietAssessment', {
                            ...formData.dietAssessment,
                            mealRegularity: { ...formData.dietAssessment!.mealRegularity, dinnerTime: option.value }
                          })
                        }
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">您吃夜宵的频率为？</Label>
                  <div className="flex items-start text-xs text-gray-500 mb-1">
                    <Info className="w-3 h-3 mr-1 mt-0.5 flex-shrink-0" />
                    <span>晚上除少量喝水、奶之外，吃其他食物都是夜宵</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: 'none', label: '无', score: 'high' as const },
                      { value: '1-2times', label: '1-2次/周', score: 'medium' as const },
                      { value: '≥3times', label: '≥3次/周', score: 'low' as const }
                    ].map((option) => (
                      <Button
                        key={option.value}
                        type="button"
                        variant={formData.dietAssessment?.mealRegularity?.midnightSnackFrequency === option.value ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.dietAssessment?.mealRegularity?.midnightSnackFrequency === option.value ? 
                            'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() =>
                          updateFormData('dietAssessment', {
                            ...formData.dietAssessment,
                            mealRegularity: { ...formData.dietAssessment!.mealRegularity, midnightSnackFrequency: option.value }
                          })
                        }
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">您外食或外卖的频率为？</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: '0times', label: '0次/周', score: 'high' as const },
                      { value: '1-3times', label: '1-3次/周', score: 'medium' as const },
                      { value: '4-6times', label: '4-6次/周', score: 'low' as const },
                      { value: 'daily', label: '每天', score: 'low' as const }
                    ].map((option) => (
                      <Button
                        key={option.value}
                        type="button"
                        variant={formData.dietAssessment?.eatingOut?.frequency === option.value ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.dietAssessment?.eatingOut?.frequency === option.value ? 
                            'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() =>
                          updateFormData('dietAssessment', {
                            ...formData.dietAssessment,
                            eatingOut: { ...formData.dietAssessment!.eatingOut, frequency: option.value }
                          })
                        }
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>

                {formData.dietAssessment?.eatingOut?.frequency !== '0times' && (
                  <div className="space-y-3">
                    <Label className="text-sm font-medium">
                      您外食时的食物类型主要是？（可多选） <span className="text-red-500">*</span>
                    </Label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { value: 'fastFood', label: '快餐' },
                        { value: 'hotpotBBQ', label: '火锅/烧烤' },
                        { value: 'stirFry', label: '炒菜' },
                        { value: 'lightMeal', label: '轻食' }
                      ].map((option) => {
                        const isSelected = formData.dietAssessment?.eatingOut?.mainTypes?.includes(option.value);
                        return (
                          <Button
                            key={option.value}
                            type="button"
                            variant={isSelected ? "default" : "outline"}
                            className={`h-auto py-3 text-xs ${
                              isSelected ? 'bg-green-600 hover:bg-green-700' : ''
                            }`}
                            onClick={() => {
                              const currentTypes = formData.dietAssessment?.eatingOut?.mainTypes || [];
                              const newTypes = isSelected
                                ? currentTypes.filter(t => t !== option.value)
                                : [...currentTypes, option.value];
                              updateFormData('dietAssessment', {
                                ...formData.dietAssessment,
                                eatingOut: { ...formData.dietAssessment!.eatingOut, mainTypes: newTypes }
                              });
                            }}
                          >
                            {option.label}
                          </Button>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  <Label className="text-sm font-medium">您偏好的烹饪方式是？</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: 'frying', label: '煎炸', score: 'low' as const },
                      { value: 'stirFrying', label: '炒', score: 'medium' as const },
                      { value: 'steamingBoiling', label: '蒸煮', score: 'high' as const },
                      { value: 'coldDish', label: '凉拌', score: 'high' as const }
                    ].map((option) => (
                      <Button
                        key={option.value}
                        type="button"
                        variant={formData.dietAssessment?.cookingMethodPreference === option.value ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.dietAssessment?.cookingMethodPreference === option.value ? 
                            'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() => updateFormData('dietAssessment', { ...formData.dietAssessment, cookingMethodPreference: option.value })}
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <YesNoSelect
                  label="代餐使用情况"
                  value={formData.dietAssessment?.mealReplacement?.isUsing}
                  onChange={(value) =>
                    updateFormData('dietAssessment', {
                      ...formData.dietAssessment,
                      mealReplacement: { isUsing: value }
                    })
                  }
                  yesColor="blue"
                  noColor="green"
                />

                <YesNoSelect
                  label="饮食禁忌"
                  value={formData.dietAssessment?.foodAllergyOrTaboo?.hasTaboo}
                  onChange={(value) =>
                    updateFormData('dietAssessment', {
                      ...formData.dietAssessment,
                      foodAllergyOrTaboo: { hasTaboo: value, specificFoods: '' }
                    })
                  }
                  yesColor="red"
                  noColor="green"
                />
                {formData.dietAssessment?.foodAllergyOrTaboo?.hasTaboo && (
                  <div className="space-y-2 ml-2">
                    <Label className="text-xs text-gray-600">具体食物（选填）</Label>
                    <Input
                      placeholder="如：海鲜、花生等"
                      value={formData.dietAssessment?.foodAllergyOrTaboo?.specificFoods || ''}
                      onChange={(e) =>
                        updateFormData('dietAssessment', {
                          ...formData.dietAssessment,
                          foodAllergyOrTaboo: { ...formData.dietAssessment!.foodAllergyOrTaboo!, specificFoods: e.target.value }
                        })
                      }
                    />
                  </div>
                )}

                <div className="space-y-3">
                  <Label className="text-sm font-medium">每日饮水</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: '<1L', label: '<1L', score: 'low' as const },
                      { value: '1-2L', label: '1-2L', score: 'medium' as const },
                      { value: '>2L', label: '>2L', score: 'high' as const },
                      { value: 'sugaryDrinks', label: '常喝含糖饮料', score: 'low' as const }
                    ].map((option) => (
                      <Button
                        key={option.value}
                        type="button"
                        variant={formData.dietAssessment?.dailyWaterIntake === option.value ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.dietAssessment?.dailyWaterIntake === option.value ? 
                            (option.score === 'high' ? 'bg-green-600 hover:bg-green-700' :
                             option.score === 'medium' ? 'bg-green-600 hover:bg-green-700' :
                             'bg-green-600 hover:bg-green-700') : ''
                        }`}
                        onClick={() => updateFormData('dietAssessment', { ...formData.dietAssessment, dailyWaterIntake: option.value })}
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">饮食偏好与习惯（可多选）</Label>

                  <div className="grid grid-cols-2 gap-2">
                    {['偏好甜食', '偏好油炸食物', '暴饮暴食', '饮食不规律'].map((pref) => (
                      <Button
                        key={pref}
                        type="button"
                        variant={formData.dietAssessment?.dietaryPreferences?.includes(pref) ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.dietAssessment?.dietaryPreferences?.includes(pref) ? 'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() => {
                          const current = formData.dietAssessment?.dietaryPreferences || [];
                          const updated = current.includes(pref)
                            ? current.filter((p) => p !== pref)
                            : [...current, pref];
                          updateFormData('dietAssessment', {
                            ...formData.dietAssessment,
                            dietaryPreferences: updated,
                            dietaryPreferencesNone: false
                          });
                        }}
                      >
                        {formData.dietAssessment?.dietaryPreferences?.includes(pref) ? '✓ ' : ''}{pref}
                      </Button>
                    ))}
                  </div>

                  <Button
                    type="button"
                    variant={formData.dietAssessment?.dietaryPreferencesNone ? "default" : "outline"}
                    className={`w-full h-auto py-3 text-sm font-semibold ${
                      formData.dietAssessment?.dietaryPreferencesNone ? 'bg-green-600 hover:bg-green-700' : ''
                    }`}
                    onClick={() => {
                      updateFormData('dietAssessment', {
                        ...formData.dietAssessment,
                        dietaryPreferencesNone: true,
                        dietaryPreferences: []
                      });
                    }}
                  >
                    无以上偏好
                  </Button>
                </div>
              </div>
            )}

            {/* 步骤 5: 运动评估 */}
            {currentStep === 5 && (
              <div className="space-y-4">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <Label className="text-sm font-medium flex items-center">
                    <Info className="w-4 h-4 mr-2" />
                    请填写您的运动情况
                  </Label>
                  <p className="text-xs text-gray-600 mt-1">如不进行某类运动，请留空。日常步数对于健康也非常重要！</p>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">您每日的步数大约为？</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: '<3000', label: '< 3000步', score: 'low' as const },
                      { value: '3000-6000', label: '3000～6000步', score: 'medium' as const },
                      { value: '6000-9000', label: '6000～9000步', score: 'high' as const },
                      { value: '>9000', label: '> 9000步', score: 'high' as const }
                    ].map((option) => (
                      <Button
                        key={option.value}
                        type="button"
                        variant={formData.exerciseAssessment?.dailySteps === option.value ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.exerciseAssessment?.dailySteps === option.value ? 'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() => updateFormData('exerciseAssessment', { ...formData.exerciseAssessment, dailySteps: option.value as any })}
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">有氧运动</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-600">每周次数</Label>
                      <Input
                        type="number"
                        inputMode="numeric"
                        min="0"
                        max="7"
                        placeholder="如：3"
                        value={formData.exerciseAssessment?.aerobicExercise?.frequency || ''}
                        onChange={(e) =>
                          updateFormData('exerciseAssessment', {
                            ...formData.exerciseAssessment,
                            aerobicExercise: { ...formData.exerciseAssessment!.aerobicExercise, frequency: parseInt(e.target.value) || undefined }
                          })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-600">每次分钟</Label>
                      <Input
                        type="number"
                        inputMode="numeric"
                        min="0"
                        placeholder="如：30"
                        value={formData.exerciseAssessment?.aerobicExercise?.duration || ''}
                        onChange={(e) =>
                          updateFormData('exerciseAssessment', {
                            ...formData.exerciseAssessment,
                            aerobicExercise: { ...formData.exerciseAssessment!.aerobicExercise, duration: parseInt(e.target.value) || undefined }
                          })
                        }
                      />
                    </div>
                  </div>
                  <p className="text-xs text-gray-500">可选：快走、跑步、游泳、骑自行车、跳绳、有氧操、椭圆机等</p>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">抗阻运动</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-600">每周次数</Label>
                      <Input
                        type="number"
                        inputMode="numeric"
                        min="0"
                        max="7"
                        placeholder="如：2"
                        value={formData.exerciseAssessment?.resistanceExercise?.frequency || ''}
                        onChange={(e) =>
                          updateFormData('exerciseAssessment', {
                            ...formData.exerciseAssessment,
                            resistanceExercise: { ...formData.exerciseAssessment!.resistanceExercise, frequency: parseInt(e.target.value) || undefined }
                          })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-600">每次分钟</Label>
                      <Input
                        type="number"
                        inputMode="numeric"
                        min="0"
                        placeholder="如：20"
                        value={formData.exerciseAssessment?.resistanceExercise?.duration || ''}
                        onChange={(e) =>
                          updateFormData('exerciseAssessment', {
                            ...formData.exerciseAssessment,
                            resistanceExercise: { ...formData.exerciseAssessment!.resistanceExercise, duration: parseInt(e.target.value) || undefined }
                          })
                        }
                      />
                    </div>
                  </div>
                  <p className="text-xs text-gray-500">可选：举重、弹力带、俯卧撑、引体向上、深蹲、器械训练、拳击对练等</p>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">柔韧性训练</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-600">每周次数</Label>
                      <Input
                        type="number"
                        inputMode="numeric"
                        min="0"
                        max="7"
                        placeholder="如：2"
                        value={formData.exerciseAssessment?.flexibilityTraining?.frequency || ''}
                        onChange={(e) =>
                          updateFormData('exerciseAssessment', {
                            ...formData.exerciseAssessment,
                            flexibilityTraining: { ...formData.exerciseAssessment!.flexibilityTraining, frequency: parseInt(e.target.value) || undefined }
                          })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-600">每次分钟</Label>
                      <Input
                        type="number"
                        inputMode="numeric"
                        min="0"
                        placeholder="如：15"
                        value={formData.exerciseAssessment?.flexibilityTraining?.duration || ''}
                        onChange={(e) =>
                          updateFormData('exerciseAssessment', {
                            ...formData.exerciseAssessment,
                            flexibilityTraining: { ...formData.exerciseAssessment!.flexibilityTraining, duration: parseInt(e.target.value) || undefined }
                          })
                        }
                      />
                    </div>
                  </div>
                  <p className="text-xs text-gray-500">可选：瑜伽、普拉提、拉伸练习等</p>
                </div>
              </div>
            )}

            {/* 步骤 6: 睡眠评估 */}
            {currentStep === 6 && (
              <div className="space-y-4">
                {Object.keys(fieldErrors).filter(key => key.startsWith('sleepAssessment')).length > 0 && (
                  <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-sm font-medium text-red-700 mb-2 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                      请完成以下必填项
                    </p>
                    <ul className="list-disc list-inside text-xs text-red-600 space-y-1">
                      {Object.keys(fieldErrors).filter(key => key.startsWith('sleepAssessment')).map((key, index) => (
                        <li key={index}>{fieldErrors[key]}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="space-y-3">
                  <Label className="text-sm font-medium">每天睡眠时间</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: '<5hours', label: '<5小时', score: 'low' as const },
                      { value: '5-7hours', label: '5-7小时', score: 'medium' as const },
                      { value: '7-9hours', label: '7-9小时', score: 'high' as const },
                      { value: '>9hours', label: '>9小时', score: 'medium' as const }
                    ].map((option) => (
                      <Button
                        key={option.value}
                        type="button"
                        variant={formData.sleepAssessment?.sleepHours === option.value ? "default" : "outline"}
                        className={`h-auto py-3 text-xs ${
                          formData.sleepAssessment?.sleepHours === option.value ? 
                            'bg-green-600 hover:bg-green-700' : ''
                        }`}
                        onClick={() => updateFormData('sleepAssessment', { ...formData.sleepAssessment, sleepHours: option.value as any })}
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium">入睡时间</Label>
                  <Input
                    type="time"
                    value={formData.sleepAssessment?.bedtime || ''}
                    onChange={(e) =>
                      updateFormData('sleepAssessment', { ...formData.sleepAssessment, bedtime: e.target.value })
                    }
                  />
                </div>

                <YesNoSelect
                  label="打鼾"
                  value={formData.sleepAssessment?.snoring}
                  onChange={(value) =>
                    updateFormData('sleepAssessment', { ...formData.sleepAssessment, snoring: value })
                  }
                  yesColor="red"
                  noColor="green"
                />

                <YesNoSelect
                  label="使用助眠药物或呼吸机"
                  value={formData.sleepAssessment?.sleepAidOrCPAP}
                  onChange={(value) =>
                    updateFormData('sleepAssessment', { ...formData.sleepAssessment, sleepAidOrCPAP: value })
                  }
                  yesColor="red"
                  noColor="green"
                />

                <div className="space-y-3">
                  <Label className="text-sm font-medium">白天精力</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      type="button"
                      variant={formData.sleepAssessment?.daytimeEnergy === 'energetic' ? "default" : "outline"}
                      className={`h-auto py-3 text-sm ${
                        formData.sleepAssessment?.daytimeEnergy === 'energetic' ? 'bg-green-600 hover:bg-green-700' : ''
                      }`}
                      onClick={() => updateFormData('sleepAssessment', { ...formData.sleepAssessment, daytimeEnergy: 'energetic' })}
                    >
                      充沛
                    </Button>
                    <Button
                      type="button"
                      variant={formData.sleepAssessment?.daytimeEnergy === 'tired' ? "default" : "outline"}
                      className={`h-auto py-3 text-sm ${
                        formData.sleepAssessment?.daytimeEnergy === 'tired' ? 'bg-green-600 hover:bg-green-700' : ''
                      }`}
                      onClick={() => updateFormData('sleepAssessment', { ...formData.sleepAssessment, daytimeEnergy: 'tired' })}
                    >
                      疲倦
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {/* 导航按钮 */}
            <div className="flex justify-between pt-4 gap-3">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentStep === 1}
                className="flex-1 min-h-[44px]"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                上一步
              </Button>

              {currentStep < TOTAL_STEPS ? (
                <Button onClick={handleNext} className="flex-1 min-h-[44px]">
                  下一步
                  <ArrowLeft className="ml-2 h-4 w-4 rotate-180" />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  disabled={loading}
                  className="flex-1 min-h-[44px] bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 text-white font-semibold"
                >
                  {loading ? '生成报告中...' : '生成评估报告'}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="mt-4 text-center text-xs text-gray-500 mb-20">
          <p>本评估系统基于生活方式医学理论和循证医学证据</p>
          <p>评估结果仅供参考，如有健康问题请咨询专业医生</p>
        </div>
      </div>
    </div>
  );
}
