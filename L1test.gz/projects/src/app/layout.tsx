import type { Metadata } from 'next';
import { Inspector } from 'react-dev-inspector';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: '时悦sayIFine，陪伴减重，轻自生活',
    template: '时悦sayIFine',
  },
  description:
    '时悦sayIFine，陪伴减重，轻自生活',
  keywords: [
    '体重管理',
    '时悦 sayIFine',
    '减肥',
    '生活方式医学',
  ],
  authors: [{ name: 'Coze Code Team', url: 'https://code.coze.cn' }],
  generator: 'Coze Code',
  // icons: {
  //   icon: '',
  // },
  openGraph: {
    title: '时悦sayIFine，陪伴减重，轻自生活',
    description:
      '时悦sayIFine，陪伴减重，轻自生活',
    url: 'https://code.coze.cn',
    siteName: '时悦 sayIFine',
    locale: 'zh_CN',
    type: 'website',
    // images: [
    //   {
    //     url: '',
    //     width: 1200,
    //     height: 630,
    //     alt: '扣子编程 - 你的 AI 工程师',
    //   },
    // ],
  },
  // twitter: {
  //   card: 'summary_large_image',
  //   title: 'Coze Code | Your AI Engineer is Here',
  //   description:
  //     'Build and deploy full-stack applications through AI conversation. No env setup, just flow.',
  //   // images: [''],
  // },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const isDev = process.env.NODE_ENV === 'development';

  return (
    <html lang="zh-CN">
      <body className={`antialiased`} suppressHydrationWarning={true}>
        {isDev && <Inspector />}
        {children}
      </body>
    </html>
  );
}
