'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, TrendingUp, Award, Clock, Activity } from 'lucide-react';
import { ArrowLeft } from 'lucide-react';
import Link from 'next/link';

interface DashboardStats {
  totalAssessments: number;
  todayCount: number;
  weekCount: number;
  averageTotalScore: number;
  scoreDistribution: Record<string, number>;
  genderDistribution: Record<string, number>;
  dimensionAverages: {
    diet: number;
    exercise: number;
    sleep: number;
    basicHealth: number;
    riskFactors: number;
  };
}

export default function AdminDashboardPage() {
  const router = useRouter();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 检查登录状态
    const isAuthenticated = localStorage.getItem('adminAuthenticated');
    if (!isAuthenticated) {
      router.push('/admin/login');
      return;
    }

    // 获取统计数据
    fetchStats();
  }, [router]);

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/admin/dashboard');
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error('获取统计数据失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('adminAuthenticated');
    router.push('/admin/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">加载中...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* 顶部导航栏 */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <h1 className="text-2xl font-bold text-gray-900">后台管理系统</h1>
            <div className="flex gap-3">
              <Link href="/admin/assessments">
                <Button variant="outline">评估记录</Button>
              </Link>
              <Link href="/admin/users">
                <Button variant="outline">管理员管理</Button>
              </Link>
              <Button variant="outline" onClick={handleLogout}>退出登录</Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* 统计卡片 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">总评估数</CardTitle>
              <Users className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalAssessments || 0}</div>
              <p className="text-xs text-gray-500">累计评估用户</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">今日新增</CardTitle>
              <Clock className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.todayCount || 0}</div>
              <p className="text-xs text-gray-500">今天新提交</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">本周新增</CardTitle>
              <TrendingUp className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.weekCount || 0}</div>
              <p className="text-xs text-gray-500">最近7天</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">平均总分</CardTitle>
              <Award className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.averageTotalScore.toFixed(1) || 0}</div>
              <p className="text-xs text-gray-500">满分100分</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 评分等级分布 */}
          <Card>
            <CardHeader>
              <CardTitle>评分等级分布</CardTitle>
              <CardDescription>用户评分等级统计</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {stats && (
                  <>
                    {[
                      { label: '优秀 (85-100分)', key: 'excellent', color: 'bg-green-500' },
                      { label: '良好 (70-84分)', key: 'good', color: 'bg-blue-500' },
                      { label: '中等 (55-69分)', key: 'average', color: 'bg-yellow-500' },
                      { label: '较差 (40-54分)', key: 'poor', color: 'bg-orange-500' },
                      { label: '很差 (<40分)', key: 'veryPoor', color: 'bg-red-500' },
                    ].map((item) => (
                      <div key={item.key} className="flex items-center gap-3">
                        <div className="flex-1">
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-700">{item.label}</span>
                            <span className="font-semibold">{stats.scoreDistribution[item.key] || 0}人</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className={`${item.color} h-2 rounded-full transition-all`}
                              style={{
                                width: `${((stats.scoreDistribution[item.key] || 0) / (stats.totalAssessments || 1)) * 100}%`,
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          {/* 性别分布 */}
          <Card>
            <CardHeader>
              <CardTitle>性别分布</CardTitle>
              <CardDescription>用户性别比例</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {stats && (
                  <>
                    {[
                      { label: '男性', key: 'male', color: 'bg-blue-600' },
                      { label: '女性', key: 'female', color: 'bg-pink-500' },
                    ].map((item) => (
                      <div key={item.key} className="flex items-center gap-3">
                        <div className="flex-1">
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-700">{item.label}</span>
                            <span className="font-semibold">{stats.genderDistribution[item.key] || 0}人</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className={`${item.color} h-2 rounded-full transition-all`}
                              style={{
                                width: `${((stats.genderDistribution[item.key] || 0) / (stats.totalAssessments || 1)) * 100}%`,
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          {/* 各维度平均分 */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>各维度平均得分</CardTitle>
              <CardDescription>用户在各评估维度的平均表现</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                {stats && (
                  <>
                    {[
                      { label: '饮食', score: stats.dimensionAverages.diet, max: 40, color: 'bg-green-500' },
                      { label: '运动', score: stats.dimensionAverages.exercise, max: 25, color: 'bg-blue-500' },
                      { label: '睡眠', score: stats.dimensionAverages.sleep, max: 15, color: 'bg-purple-500' },
                      { label: '基础健康', score: stats.dimensionAverages.basicHealth, max: 10, color: 'bg-orange-500' },
                      { label: '风险控制', score: stats.dimensionAverages.riskFactors, max: 10, color: 'bg-red-500' },
                  ].map((item) => (
                    <div key={item.label} className="text-center">
                      <div className="text-sm text-gray-600 mb-2">{item.label}</div>
                      <div className="text-2xl font-bold mb-2">{item.score.toFixed(1)}</div>
                      <div className="text-xs text-gray-500">满分{item.max}分</div>
                      <div className="mt-2 w-full bg-gray-200 rounded-full h-2 mx-auto">
                        <div
                          className={`${item.color} h-2 rounded-full transition-all`}
                          style={{
                            width: `${(item.score / item.max) * 100}%`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </>
              )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
