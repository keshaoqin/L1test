'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { UserPlus, Trash2, Lock, ArrowLeft, CheckCircle2, XCircle, AlertTriangle } from 'lucide-react';
import Link from 'next/link';

interface AdminUser {
  id: string;
  username: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string | null;
}

export default function AdminUsersPage() {
  const router = useRouter();
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [deletingUser, setDeletingUser] = useState<AdminUser | null>(null);
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [changePassword, setChangePassword] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    const isAuthenticated = localStorage.getItem('adminAuthenticated');
    if (!isAuthenticated) {
      router.push('/admin/login');
      return;
    }
    fetchUsers();
  }, [router]);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/users');
      if (response.ok) {
        const data = await response.json();
        setUsers(data);
      } else {
        router.push('/admin/login');
      }
    } catch (error) {
      console.error('获取管理员列表失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!newUsername || !newPassword) {
      setError('请填写所有必填字段');
      return;
    }

    try {
      const response = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: newUsername, password: newPassword }),
      });

      if (response.ok) {
        setShowAddDialog(false);
        setNewUsername('');
        setNewPassword('');
        setError('');
        fetchUsers();
      } else {
        const data = await response.json();
        setError(data.error || '创建失败');
      }
    } catch (err) {
      setError('网络错误，请重试');
    }
  };

  const handleDeleteUser = async () => {
    if (!deletingUser) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/users/${deletingUser.id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        setShowDeleteDialog(false);
        setDeletingUser(null);
        setSuccessMessage('管理员已删除');
        setTimeout(() => setSuccessMessage(''), 3000);
        fetchUsers();
      } else {
        setError('删除失败，请重试');
      }
    } catch (err) {
      setError('网络错误，请重试');
    }
  };

  const openDeleteDialog = (user: AdminUser) => {
    setDeletingUser(user);
    setError('');
    setShowDeleteDialog(true);
  };

  const cancelDelete = () => {
    setShowDeleteDialog(false);
    setDeletingUser(null);
    setError('');
  };

  const handleToggleStatus = async (id: string, isActive: boolean) => {
    try {
      const response = await fetch(`/api/admin/users/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !isActive }),
      });

      if (response.ok) {
        const action = !isActive ? '启用' : '禁用';
        setSuccessMessage(`管理员已${action}`);
        setTimeout(() => setSuccessMessage(''), 3000);
        fetchUsers();
      } else {
        setError('更新状态失败，请重试');
      }
    } catch (err) {
      setError('网络错误，请重试');
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!changePassword) {
      setError('请输入新密码');
      return;
    }

    if (!selectedUser) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/users/${selectedUser.id}/password`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPassword: changePassword }),
      });

      if (response.ok) {
        setShowPasswordDialog(false);
        setChangePassword('');
        setSelectedUser(null);
        setError('');
        setSuccessMessage('密码修改成功');
        setTimeout(() => setSuccessMessage(''), 3000);
      } else {
        const data = await response.json();
        setError(data.error || '修改失败');
      }
    } catch (err) {
      setError('网络错误，请重试');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('adminAuthenticated');
    localStorage.removeItem('adminUsername');
    localStorage.removeItem('adminId');
    router.push('/admin/login');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* 顶部导航栏 */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-4">
              <Link href="/admin/dashboard">
                <Button variant="ghost" size="icon" title="返回首页">
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </Link>
              <h1 className="text-2xl font-bold text-gray-900">管理员管理</h1>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={handleLogout}>
                退出登录
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* 成功/错误消息提示 */}
        {successMessage && (
          <div className="mb-4 flex items-center gap-2 p-4 bg-green-50 border border-green-200 rounded-lg">
            <CheckCircle2 className="h-5 w-5 text-green-600" />
            <span className="text-green-700">{successMessage}</span>
          </div>
        )}

        {error && !showAddDialog && !showPasswordDialog && !showDeleteDialog && (
          <div className="mb-4 flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg">
            <XCircle className="h-5 w-5 text-red-600" />
            <span className="text-red-700">{error}</span>
          </div>
        )}

        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>管理员列表</CardTitle>
                <CardDescription>管理后台管理员账户</CardDescription>
              </div>
              <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                <DialogTrigger asChild>
                  <Button>
                    <UserPlus className="h-4 w-4 mr-2" />
                    新增管理员
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>新增管理员</DialogTitle>
                    <DialogDescription>创建新的管理员账户</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreateUser}>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="username">用户名 *</Label>
                        <Input
                          id="username"
                          value={newUsername}
                          onChange={(e) => setNewUsername(e.target.value)}
                          placeholder="请输入用户名"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="password">密码 *</Label>
                        <Input
                          id="password"
                          type="password"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          placeholder="请输入密码（至少6位）"
                          required
                          minLength={6}
                        />
                      </div>
                      {error && (
                        <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
                          {error}
                        </div>
                      )}
                    </div>
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
                        取消
                      </Button>
                      <Button type="submit">创建</Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8 text-gray-500">加载中...</div>
            ) : (
              <div className="space-y-4">
                {users.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    暂无管理员账户
                  </div>
                ) : (
                  users.map((user) => (
                    <div
                      key={user.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <div className="font-semibold">{user.username}</div>
                          {!user.isActive && (
                            <span className="px-2 py-1 bg-gray-200 text-gray-600 text-xs rounded">
                              已禁用
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-gray-500 mt-1">
                          创建时间: {new Date(user.createdAt).toLocaleString('zh-CN')}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Dialog open={showPasswordDialog && selectedUser?.id === user.id} onOpenChange={(open) => {
                          setShowPasswordDialog(open);
                          if (open) setSelectedUser(user);
                          else setSelectedUser(null);
                        }}>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Lock className="h-4 w-4 mr-1" />
                              修改密码
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>修改密码</DialogTitle>
                              <DialogDescription>
                                为用户 "{user.username}" 修改密码
                              </DialogDescription>
                            </DialogHeader>
                            <form onSubmit={handleChangePassword}>
                              <div className="space-y-4 py-4">
                                <div className="space-y-2">
                                  <Label htmlFor="changePassword">新密码 *</Label>
                                  <Input
                                    id="changePassword"
                                    type="password"
                                    value={changePassword}
                                    onChange={(e) => setChangePassword(e.target.value)}
                                    placeholder="请输入新密码（至少6位）"
                                    required
                                    minLength={6}
                                  />
                                </div>
                                {error && (
                                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
                                    {error}
                                  </div>
                                )}
                              </div>
                              <DialogFooter>
                                <Button type="button" variant="outline" onClick={() => {
                                  setShowPasswordDialog(false);
                                  setSelectedUser(null);
                                  setChangePassword('');
                                }}>
                                  取消
                                </Button>
                                <Button type="submit">确定修改</Button>
                              </DialogFooter>
                            </form>
                          </DialogContent>
                        </Dialog>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleToggleStatus(user.id, user.isActive)}
                        >
                          {user.isActive ? '禁用' : '启用'}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openDeleteDialog(user)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* 删除确认对话框 */}
        <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-red-600">
                <AlertTriangle className="h-5 w-5" />
                确认删除
              </DialogTitle>
              <DialogDescription>
                确定要删除管理员 "{deletingUser?.username}" 吗？此操作无法撤销。
              </DialogDescription>
            </DialogHeader>
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
                {error}
              </div>
            )}
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={cancelDelete}
              >
                取消
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={handleDeleteUser}
              >
                确认删除
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
