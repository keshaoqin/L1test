'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Lock } from 'lucide-react';

export default function AdminLoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [initMessage, setInitMessage] = useState('');

  // 页面加载时自动检查并初始化
  useEffect(() => {
    const checkAndInit = async () => {
      try {
        console.log('检查系统是否需要初始化...');
        const response = await fetch('/api/admin/init', {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' },
        });

        const data = await response.json();
        if (data.success) {
          console.log('系统初始化检查:', data.details);
          if (data.details?.includes('已创建') || data.details?.includes('密码已重置')) {
            setInitMessage('系统已自动初始化，请使用默认账户登录');
            // 3秒后清除提示
            setTimeout(() => setInitMessage(''), 3000);
          }
        }
      } catch (err) {
        console.error('初始化检查失败:', err);
      }
    };

    checkAndInit();
  }, []);

  const handleLogin = async (e: React.FormEvent, isRetry: boolean = false) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/admin/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();

      if (response.ok) {
        // 保存登录状态到 localStorage
        localStorage.setItem('adminAuthenticated', 'true');
        localStorage.setItem('adminUsername', data.username);
        localStorage.setItem('adminId', data.id);
        router.push('/admin/dashboard');
      } else {
        // 如果返回 needRetry 标志，自动重试登录
        if (data.needRetry && !isRetry) {
          console.log('系统已初始化，自动重试登录...');
          // 显示提示信息
          setError('系统正在初始化，请稍候...');
          // 延迟1秒后自动重试
          setTimeout(() => {
            handleLogin(e, true);
          }, 1000);
          return;
        }
        setError(data.error || '登录失败');
        setLoading(false);
      }
    } catch (err) {
      setError('网络错误，请重试');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-blue-100 rounded-full">
              <Lock className="h-8 w-8 text-blue-600" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold">后台管理系统</CardTitle>
          <CardDescription>请输入用户名和密码登录</CardDescription>
        </CardHeader>
        <CardContent>
          {initMessage && (
            <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-600">
              {initMessage}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="username" className="text-sm font-medium">
                用户名
              </label>
              <Input
                id="username"
                type="text"
                placeholder="请输入用户名"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="password" className="text-sm font-medium">
                密码
              </label>
              <Input
                id="password"
                type="password"
                placeholder="请输入密码"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
                {error}
              </div>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? '登录中...' : '登录'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
