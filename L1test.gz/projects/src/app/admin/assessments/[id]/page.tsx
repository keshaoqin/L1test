'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Download, User, Activity, Calendar } from 'lucide-react';
import Link from 'next/link';
import html2canvas from 'html2canvas';

interface AssessmentDetail {
  id: string;
  name: string | null;
  gender: 'male' | 'female';
  age: number;
  requestData: any;
  responseData: any;
  totalScore: number;
  totalScoreLevel: string;
  bmi: string;
  bmiCategory: string;
  createdAt: string;
  updatedAt: string;
}

const SCORE_LEVEL_MAP: Record<string, { label: string; color: string }> = {
  excellent: { label: '优秀', color: 'bg-green-500' },
  good: { label: '良好', color: 'bg-blue-500' },
  average: { label: '中等', color: 'bg-yellow-500' },
  poor: { label: '较差', color: 'bg-orange-500' },
  veryPoor: { label: '很差', color: 'bg-red-500' },
};

export default function AssessmentDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const router = useRouter();
  const [assessment, setAssessment] = useState<AssessmentDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    const init = async () => {
      // 检查登录状态
      const isAuthenticated = localStorage.getItem('adminAuthenticated');
      if (!isAuthenticated) {
        router.push('/admin/login');
        return;
      }

      const { id } = await params;
      fetchAssessment(id);
    };

    init();
  }, [router, params]);

  const fetchAssessment = async (id: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/admin/assessments/${id}`);
      if (response.ok) {
        const data = await response.json();
        setAssessment(data);
      } else {
        router.push('/admin/assessments');
      }
    } catch (error) {
      console.error('获取评估详情失败:', error);
      router.push('/admin/assessments');
    } finally {
      setLoading(false);
    }
  };

  const handleExportAsImage = async () => {
    if (!assessment) return;

    setExporting(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 300));

      const element = document.getElementById('assessment-detail-content');
      if (!element) return;

      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      await new Promise(resolve => setTimeout(resolve, 500));

      const canvas = await html2canvas(element, {
        scale: window.devicePixelRatio || 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
        imageTimeout: 15000,
        width: element.scrollWidth,
        height: element.scrollHeight,
        scrollX: 0,
        scrollY: -window.scrollY,
      });

      canvas.toBlob(async (blob) => {
        if (!blob) return;

        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `评估详情_${assessment.name || '匿名'}_${new Date().toISOString().slice(0, 10)}.png`;
        document.body.appendChild(link);
        link.click();
        setTimeout(() => {
          document.body.removeChild(link);
          window.URL.revokeObjectURL(url);
        }, 100);

        alert('图片已开始下载');
      }, 'image/png', 0.95);
    } catch (error) {
      console.error('导出失败:', error);
      alert('导出失败，请重试');
    } finally {
      setExporting(false);
    }
  };

  const handleExportUserReport = async () => {
    if (!assessment) return;

    setExporting(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 300));

      // 创建一个隐藏的临时容器
      const tempContainer = document.createElement('div');
      tempContainer.id = 'temp-user-report';
      tempContainer.style.position = 'fixed';
      tempContainer.style.left = '-9999px';
      tempContainer.style.top = '0';
      tempContainer.style.width = '800px';
      tempContainer.style.backgroundColor = '#ffffff';
      tempContainer.style.padding = '24px';
      tempContainer.style.fontFamily = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      document.body.appendChild(tempContainer);

      // 生成用户报告内容
      const result = responseData;
      const getScoreTheme = () => {
        if (result.totalScore >= 85) {
          return {
            gradient: 'from-green-400 to-emerald-500',
            bgColor: 'bg-green-50',
            textColor: 'text-green-700',
            borderColor: 'border-green-200',
            badgeBg: 'bg-green-100',
            badgeText: 'text-green-700',
            emoji: '😊',
            rabbit: '🐰',
            title: '优秀',
          };
        } else if (result.totalScore >= 70) {
          return {
            gradient: 'from-blue-400 to-indigo-500',
            bgColor: 'bg-blue-50',
            textColor: 'text-blue-700',
            borderColor: 'border-blue-200',
            badgeBg: 'bg-blue-100',
            badgeText: 'text-blue-700',
            emoji: '😄',
            rabbit: '🐰',
            title: '良好',
          };
        } else if (result.totalScore >= 55) {
          return {
            gradient: 'from-yellow-400 to-orange-400',
            bgColor: 'bg-yellow-50',
            textColor: 'text-yellow-700',
            borderColor: 'border-yellow-200',
            badgeBg: 'bg-yellow-100',
            badgeText: 'text-yellow-700',
            emoji: '😐',
            rabbit: '🐰',
            title: '一般',
          };
        } else if (result.totalScore >= 40) {
          return {
            gradient: 'from-orange-400 to-red-400',
            bgColor: 'bg-orange-50',
            textColor: 'text-orange-700',
            borderColor: 'border-orange-200',
            badgeBg: 'bg-orange-100',
            badgeText: 'text-orange-700',
            emoji: '😟',
            rabbit: '🐰',
            title: '较差',
          };
        } else {
          return {
            gradient: 'from-red-400 to-red-600',
            bgColor: 'bg-red-50',
            textColor: 'text-red-700',
            borderColor: 'border-red-200',
            badgeBg: 'bg-red-100',
            badgeText: 'text-red-700',
            emoji: '😰',
            rabbit: '🐰',
            title: '很差',
          };
        }
      };

      const theme = getScoreTheme();

      // BMI类别映射
      const getBMICategory = () => {
        if (result.bmiCategory === 'normal') return '正常';
        if (result.bmiCategory === 'overweight') return '超重';
        if (result.bmiCategory === 'obesity') return '肥胖';
        return '偏瘦';
      };

      // 生成完整报告HTML
      tempContainer.innerHTML = `
        <div style="max-width: 100%; margin: 0 auto;">
          <!-- 顶部品牌栏 -->
          <div style="display: flex; align-items: center; justify-content: space-between; padding: 20px 24px; border-bottom: 2px solid #e5e7eb; margin-bottom: 20px;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #2288D2, #0D2860); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <span style="color: white; font-weight: bold; font-size: 20px; line-height: 1;">悦</span>
              </div>
              <div>
                <div style="font-weight: bold; color: #111827; font-size: 16px; line-height: 1.2;">时悦健康</div>
                <div style="color: #6b7280; font-size: 12px; line-height: 1.2; margin-top: 2px;">生活方式评估报告</div>
              </div>
            </div>
            <div style="text-align: right; flex-shrink: 0;">
              <div style="color: #9ca3af; font-size: 11px; line-height: 1.2;">评估日期</div>
              <div style="font-weight: 600; color: #374151; font-size: 14px; line-height: 1.2; margin-top: 2px;">${new Date().toLocaleDateString('zh-CN')}</div>
            </div>
          </div>

          <!-- 评分头部 -->
          <div style="background: linear-gradient(to bottom right, #2288D2, #0D2860); padding: 48px 32px; border-radius: 20px; color: white; text-align: center; margin-bottom: 24px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
            <div style="font-size: 72px; font-weight: bold; line-height: 1; margin-bottom: 8px;">${result.totalScore}</div>
            <div style="font-size: 16px; font-weight: 500; opacity: 0.9; margin-bottom: 16px;">总得分 · 满分100</div>
            <div style="display: inline-block; padding: 14px 36px; background: rgba(255, 255, 255, 0.15); backdrop-filter: blur(10px); border-radius: 16px; border: 1px solid rgba(255, 255, 255, 0.3); box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
              <span style="font-size: 24px; font-weight: bold; letter-spacing: 1px; line-height: 1;">${theme.title}</span>
            </div>
          </div>

          <!-- 评分等级 -->
          <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; margin-bottom: 24px;">
            ${[
              { range: '85-100', color: 'background-color: #22c55e; color: white;', min: 85, max: 100 },
              { range: '70-84', color: 'background-color: #3b82f6; color: white;', min: 70, max: 84 },
              { range: '55-69', color: 'background-color: #eab308; color: white;', min: 55, max: 69 },
              { range: '40-54', color: 'background-color: #f97316; color: white;', min: 40, max: 54 },
              { range: '0-39', color: 'background-color: #ef4444; color: white;', min: 0, max: 39 },
            ].map((item) => {
              const isActive = result.totalScore >= item.min && result.totalScore <= item.max;
              return `
                <div style="padding: 10px; text-align: center; border-radius: 10px; border: 2px solid ${isActive ? 'currentColor' : '#e5e7eb'}; ${isActive ? item.color + ' border: currentColor; font-weight: bold; box-shadow: 0 2px 4px rgba(0,0,0,0.1);' : 'background-color: #f9fafb; color: #4b5563;'}">
                  <div style="font-size: 11px; font-weight: bold; letter-spacing: 0.5px; line-height: 1.2;">${item.range}分</div>
                </div>
              `;
            }).join('')}
          </div>

          <!-- 各维度得分 -->
          <div style="margin-bottom: 24px;">
            <h3 style="font-size: 16px; font-weight: bold; color: #111827; margin-bottom: 16px; line-height: 1.2;">各维度得分</h3>
            <div style="background: white; padding: 16px; border-radius: 16px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);">
              <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px;">
                ${[
                  { label: '饮食', score: result.dimensionScores.diet, fullScore: 40, color: 'border: 2px solid #22c55e; background-color: #f0fdf4; color: #166534;' },
                  { label: '运动', score: result.dimensionScores.exercise, fullScore: 25, color: 'border: 2px solid #fb923c; background-color: #fff7ed; color: #c2410c;' },
                  { label: '睡眠', score: result.dimensionScores.sleep, fullScore: 15, color: 'border: 2px solid #a855f7; background-color: #faf5ff; color: #7e22ce;' },
                  { label: '基础健康', score: result.dimensionScores.basicHealth, fullScore: 10, color: 'border: 2px solid #ef4444; background-color: #fef2f2; color: #b91c1c;' },
                  { label: '风险控制', score: result.dimensionScores.riskFactors, fullScore: 10, color: 'border: 2px solid #3b82f6; background-color: #eff6ff; color: #1d4ed8;' },
                ].map(item => `
                  <div style="padding: 10px; border-radius: 10px; ${item.color} text-align: center;">
                    <div style="font-size: 11px; font-weight: bold; line-height: 1.2;">${item.label}</div>
                    <div style="font-size: 16px; font-weight: bold; margin-top: 4px; line-height: 1;">${item.score}</div>
                    <div style="font-size: 10px; font-weight: 500; opacity: 0.75; margin-top: 2px; line-height: 1;">/${item.fullScore}</div>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>

          <!-- 总体评价 -->
          <div style="background: linear-gradient(to bottom right, #dbeafe, #ede9fe); padding: 20px; border-radius: 16px; border: 2px solid #c7d2fe; margin-bottom: 20px;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
              <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #2288D2, #0D2860); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <span style="font-size: 20px; line-height: 1;">💡</span>
              </div>
              <h3 style="font-weight: bold; font-size: 16px; color: #111827; line-height: 1.2;">总体评价</h3>
            </div>
            <p style="font-size: 13px; color: #1f2937; line-height: 1.8; margin: 0; padding-left: 56px;">${result.analysis.overall}</p>
          </div>

          <!-- 各维度详细分析 -->
          <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 20px;">
            <!-- 饮食习惯 -->
            <div style="background: linear-gradient(to bottom right, #f0fdf4, #dcfce7); padding: 16px; border-radius: 16px; border: 1px solid #bbf7d0;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #22c55e, #16a34a); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">🍎</span>
                </div>
                <div>
                  <h3 style="font-weight: bold; font-size: 15px; color: #14532d; line-height: 1.2;">饮食习惯</h3>
                  <div style="font-size: 11px; font-weight: bold; color: #166534; margin-top: 2px; line-height: 1.2;">${result.dimensionScores.diet}/40分</div>
                </div>
              </div>
              <p style="font-size: 12px; color: #1f2937; line-height: 1.6; margin: 0;">${result.analysis.diet}</p>
            </div>

            <!-- 运动习惯 -->
            <div style="background: linear-gradient(to bottom right, #fff7ed, #ffedd5); padding: 16px; border-radius: 16px; border: 1px solid #fed7aa;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #fb923c, #ea580c); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">🏃</span>
                </div>
                <div>
                  <h3 style="font-weight: bold; font-size: 15px; color: #7c2d12; line-height: 1.2;">运动习惯</h3>
                  <div style="font-size: 11px; font-weight: bold; color: #c2410c; margin-top: 2px; line-height: 1.2;">${result.dimensionScores.exercise}/25分</div>
                </div>
              </div>
              <p style="font-size: 12px; color: #1f2937; line-height: 1.6; margin: 0;">${result.analysis.exercise}</p>
            </div>

            <!-- 睡眠质量 -->
            <div style="background: linear-gradient(to bottom right, #faf5ff, #f3e8ff); padding: 16px; border-radius: 16px; border: 1px solid #e9d5ff;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #a855f7, #7c3aed); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">😴</span>
                </div>
                <div>
                  <h3 style="font-weight: bold; font-size: 15px; color: #581c87; line-height: 1.2;">睡眠质量</h3>
                  <div style="font-size: 11px; font-weight: bold; color: #7e22ce; margin-top: 2px; line-height: 1.2;">${result.dimensionScores.sleep}/15分</div>
                </div>
              </div>
              <p style="font-size: 12px; color: #1f2937; line-height: 1.6; margin: 0;">${result.analysis.sleep}</p>
            </div>

            <!-- 基础健康 -->
            <div style="background: linear-gradient(to bottom right, #fef2f2, #fee2e2); padding: 16px; border-radius: 16px; border: 1px solid #fecaca;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #ef4444, #dc2626); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">❤️</span>
                </div>
                <div>
                  <h3 style="font-weight: bold; font-size: 15px; color: #7f1d1d; line-height: 1.2;">基础健康</h3>
                  <div style="font-size: 11px; font-weight: bold; color: #b91c1c; margin-top: 2px; line-height: 1.2;">${result.dimensionScores.basicHealth}/10分</div>
                </div>
              </div>
              <div style="display: flex; flex-direction: column; gap: 8px; margin-top: 10px;">
                <div style="display: flex; align-items: center; justify-content: space-between; padding: 8px; background: rgba(255,255,255,0.8); border-radius: 8px;">
                  <span style="font-size: 11px; font-weight: bold; color: #374151; line-height: 1.2;">BMI指数</span>
                  <span style="font-size: 11px; font-weight: bold; color: #dc2626; line-height: 1.2;">${result.bmi || '未提供'}</span>
                </div>
                <div style="display: flex; align-items: center; justify-content: space-between; padding: 8px; background: rgba(255,255,255,0.8); border-radius: 8px;">
                  <span style="font-size: 11px; font-weight: bold; color: #374151; line-height: 1.2;">健康状态</span>
                  <span style="font-size: 11px; font-weight: bold; color: #dc2626; line-height: 1.2;">${getBMICategory()}</span>
                </div>
              </div>
            </div>
          </div>

          <!-- 风险控制能力 -->
          <div style="background: linear-gradient(to bottom right, #eff6ff, #dbeafe); padding: 16px; border-radius: 16px; border: 1px solid #bfdbfe; margin-bottom: 20px;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
              <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #3b82f6, #2563eb); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                <span style="font-size: 20px; line-height: 1;">🛡️</span>
              </div>
              <div>
                <h3 style="font-weight: bold; font-size: 15px; color: #1e3a8a; line-height: 1.2;">风险控制能力</h3>
                <div style="font-size: 11px; font-weight: bold; color: #1d4ed8; margin-top: 2px; line-height: 1.2;">${result.dimensionScores.riskFactors}/10分</div>
              </div>
            </div>
            <div style="margin-bottom: 12px; padding: 8px; background: rgba(59, 130, 246, 0.15); border-radius: 8px;">
              <p style="font-size: 11px; font-weight: bold; color: #1e40af; line-height: 1.4; margin: 0;">💡 分数越高，风险控制能力越强</p>
            </div>
            <p style="font-size: 12px; color: #1f2937; line-height: 1.6; margin: 0; padding: 12px; background: rgba(255,255,255,0.8); border-radius: 8px;">
              ${result.dimensionScores.riskFactors >= 10 ? '✅ 无吸烟和过量饮酒，风险控制能力优秀！继续保持' :
               result.dimensionScores.riskFactors >= 7 ? '✨ 基本无重大危险因素，风险控制能力良好，建议继续保持健康习惯' :
               result.dimensionScores.riskFactors >= 4 ? '⚠️ 存在一定危险因素，风险控制能力一般，建议改善' :
               '🚨 危险因素较多，风险控制能力较弱，强烈建议立即改善生活方式'}
            </p>
          </div>

          <!-- 健康风险提示 -->
          ${result.analysis.healthRisks && result.analysis.healthRisks.length > 0 ? `
            <div style="background: linear-gradient(to bottom right, #fef2f2, #ffedd5); padding: 16px; border-radius: 16px; border: 2px solid #fca5a5; margin-bottom: 20px;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #ef4444, #f97316); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">⚠️</span>
                </div>
                <h3 style="font-weight: bold; font-size: 15px; color: #7f1d1d; line-height: 1.2;">健康风险提示</h3>
              </div>
              <ul style="list-style: disc; padding-left: 20px; margin: 0; font-size: 12px; color: #1f2937; line-height: 1.8; background: rgba(255,255,255,0.8); padding: 12px 12px 12px 32px; border-radius: 8px;">
                ${result.analysis.healthRisks.map((risk: string) => `<li style="line-height: 1.8;">${risk}</li>`).join('')}
              </ul>
            </div>
          ` : ''}

          <!-- 改善建议 -->
          <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 20px;">
            <!-- 饮食建议 -->
            <div style="background: linear-gradient(to bottom right, #f0fdf4, #ecfccb); padding: 16px; border-radius: 16px; border: 1px solid #bbf7d0;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #22c55e, #84cc16); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">🥗</span>
                </div>
                <h3 style="font-weight: bold; font-size: 15px; color: #14532d; line-height: 1.2;">饮食建议</h3>
              </div>
              <ul style="list-style: disc; padding-left: 20px; margin: 0; font-size: 12px; color: #1f2937; line-height: 1.8;">
                ${result.recommendations.diet.map((rec: string) => `<li style="line-height: 1.8;">${rec}</li>`).join('')}
              </ul>
            </div>

            <!-- 运动建议 -->
            <div style="background: linear-gradient(to bottom right, #eff6ff, #cffafe); padding: 16px; border-radius: 16px; border: 1px solid #bfdbfe;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #3b82f6, #06b6d4); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">💪</span>
                </div>
                <h3 style="font-weight: bold; font-size: 15px; color: #1e3a8a; line-height: 1.2;">运动建议</h3>
              </div>
              <ul style="list-style: disc; padding-left: 20px; margin: 0; font-size: 12px; color: #1f2937; line-height: 1.8;">
                ${result.recommendations.exercise.map((rec: string) => `<li style="line-height: 1.8;">${rec}</li>`).join('')}
              </ul>
            </div>

            <!-- 睡眠建议 -->
            <div style="background: linear-gradient(to bottom right, #faf5ff, #fae8ff); padding: 16px; border-radius: 16px; border: 1px solid #e9d5ff;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #a855f7, #d946ef); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">🌙</span>
                </div>
                <h3 style="font-weight: bold; font-size: 15px; color: #581c87; line-height: 1.2;">睡眠建议</h3>
              </div>
              <ul style="list-style: disc; padding-left: 20px; margin: 0; font-size: 12px; color: #1f2937; line-height: 1.8;">
                ${result.recommendations.sleep.map((rec: string) => `<li style="line-height: 1.8;">${rec}</li>`).join('')}
              </ul>
            </div>

            <!-- 健康监测 -->
            <div style="background: linear-gradient(to bottom right, #fdf2f8, #fce7f3); padding: 16px; border-radius: 16px; border: 1px solid #fbcfe8;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #ec4899, #f43f5e); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">📊</span>
                </div>
                <h3 style="font-weight: bold; font-size: 15px; color: #831843; line-height: 1.2;">健康监测</h3>
              </div>
              <ul style="list-style: disc; padding-left: 20px; margin: 0; font-size: 12px; color: #1f2937; line-height: 1.8;">
                ${result.recommendations.healthMonitoring.map((rec: string) => `<li style="line-height: 1.8;">${rec}</li>`).join('')}
              </ul>
            </div>

            <!-- 心理支持 - 跨两列 -->
            <div style="grid-column: 1 / -1; background: linear-gradient(to bottom right, #f0fdfa, #ccfbf1); padding: 16px; border-radius: 16px; border: 1px solid #99f6e4;">
              <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #14b8a6, #06b6d4); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                  <span style="font-size: 20px; line-height: 1;">💖</span>
                </div>
                <h3 style="font-weight: bold; font-size: 15px; color: #134e4a; line-height: 1.2;">心理支持</h3>
              </div>
              <ul style="list-style: disc; padding-left: 20px; margin: 0; font-size: 12px; color: #1f2937; line-height: 1.8;">
                ${result.recommendations.psychologicalSupport.map((rec: string) => `<li style="line-height: 1.8;">${rec}</li>`).join('')}
              </ul>
            </div>
          </div>

          <!-- 品牌图片 -->
          <div style="margin-top: 24px; margin-bottom: 24px;">
            <img src="/003.png" alt="时悦健康品牌" style="width: 100%; border-radius: 16px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); border: 1px solid #e5e7eb; display: block;" />
          </div>

          <!-- 品牌宣传语 -->
          <div style="text-align: center; padding: 24px; background: linear-gradient(to right, #eff6ff, #eef2ff); border-radius: 16px; border: 1px solid #e5e7eb;">
            <div style="display: flex; align-items: center; justify-content: center; gap: 12px; margin-bottom: 12px;">
              <div style="width: 44px; height: 44px; background: linear-gradient(to bottom right, #2288D2, #0D2860); border-radius: 12px; display: flex; align-items: center; justify-content: center; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
                <span style="color: white; font-weight: bold; font-size: 20px; line-height: 1;">悦</span>
              </div>
            </div>
            <p style="font-size: 15px; font-weight: bold; color: #111827; margin-bottom: 8px; line-height: 1.3;">
              时悦 sayIFine，陪伴减重，轻自生活
            </p>
            <p style="font-size: 13px; color: #6b7280; font-weight: 500; margin: 0; line-height: 1.3;">
              Right By your side，For A lighter Life
            </p>
          </div>
        </div>
      `;

      // 等待内容渲染和图片加载
      await new Promise(resolve => setTimeout(resolve, 1000));

      // 使用html2canvas截图
      const canvas = await html2canvas(tempContainer, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
        imageTimeout: 30000,
        width: tempContainer.scrollWidth,
        height: tempContainer.scrollHeight,
        scrollX: 0,
        scrollY: 0,
        windowWidth: tempContainer.scrollWidth,
        windowHeight: tempContainer.scrollHeight,
      });

      // 转换为图片并下载
      canvas.toBlob(async (blob) => {
        if (!blob) return;

        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `用户报告_${assessment.name || '匿名'}_${new Date().toISOString().slice(0, 10)}.png`;
        document.body.appendChild(link);
        link.click();
        setTimeout(() => {
          document.body.removeChild(link);
          window.URL.revokeObjectURL(url);
        }, 100);

        alert('用户报告已开始下载');

        // 清理临时容器
        document.body.removeChild(tempContainer);
      }, 'image/png', 0.95);
    } catch (error) {
      console.error('生成用户报告失败:', error);
      alert('生成用户报告失败，请重试');

      // 清理临时容器
      const tempContainer = document.getElementById('temp-user-report');
      if (tempContainer) {
        document.body.removeChild(tempContainer);
      }
    } finally {
      setExporting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">加载中...</p>
        </div>
      </div>
    );
  }

  if (!assessment) {
    return null;
  }

  const requestData = assessment.requestData;
  const responseData = assessment.responseData;

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* 顶部导航栏 */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-4">
              <Link href="/admin/assessments">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </Link>
              <h1 className="text-2xl font-bold text-gray-900">评估详情</h1>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={handleExportUserReport} disabled={exporting}>
                <Download className="h-4 w-4 mr-2" />
                {exporting ? '生成中...' : '下载用户报告'}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div id="assessment-detail-content" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* 用户基本信息 */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              用户基本信息
            </CardTitle>
            <CardDescription>评估记录 ID: {assessment.id}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <div className="text-sm text-gray-500">姓名</div>
                <div className="font-semibold">{assessment.name || '匿名'}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500">性别</div>
                <div className="font-semibold">{assessment.gender === 'male' ? '男' : '女'}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500">年龄</div>
                <div className="font-semibold">{assessment.age}岁</div>
              </div>
              <div>
                <div className="text-sm text-gray-500">提交时间</div>
                <div className="font-semibold">{formatDate(assessment.createdAt)}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 评分结果概览 */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              评分结果
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* 总分 */}
              <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
                <div className="text-5xl font-bold text-blue-600 mb-2">{assessment.totalScore}</div>
                <div className="text-sm text-gray-600 mb-2">总分（满分100）</div>
                <span className={`px-3 py-1 rounded-full text-sm font-semibold ${SCORE_LEVEL_MAP[assessment.totalScoreLevel]?.color || 'bg-gray-100 text-gray-700'}`}>
                  {SCORE_LEVEL_MAP[assessment.totalScoreLevel]?.label || assessment.totalScoreLevel}
                </span>
              </div>

              {/* BMI */}
              <div className="text-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
                <div className="text-5xl font-bold text-purple-600 mb-2">{assessment.bmi}</div>
                <div className="text-sm text-gray-600 mb-2">BMI</div>
                <div className="text-sm font-semibold">
                  {assessment.bmiCategory === 'normal' ? '正常' :
                   assessment.bmiCategory === 'overweight' ? '超重' :
                   assessment.bmiCategory === 'obesity' ? '肥胖' :
                   assessment.bmiCategory === 'underweight' ? '偏瘦' : assessment.bmiCategory}
                </div>
              </div>

              {/* 各维度得分 */}
              <div className="p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
                <div className="text-sm text-gray-600 mb-3 font-semibold">各维度得分</div>
                <div className="space-y-2">
                  {responseData.dimensionScores && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-sm">饮食</span>
                        <span className="font-semibold">{responseData.dimensionScores.diet}/40</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">运动</span>
                        <span className="font-semibold">{responseData.dimensionScores.exercise}/25</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">睡眠</span>
                        <span className="font-semibold">{responseData.dimensionScores.sleep}/15</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">基础健康</span>
                        <span className="font-semibold">{responseData.dimensionScores.basicHealth}/10</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">风险控制</span>
                        <span className="font-semibold">{responseData.dimensionScores.riskFactors}/10</span>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 分析和建议 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* 分析 */}
          <Card>
            <CardHeader>
              <CardTitle>分析</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {responseData.analysis && (
                <>
                  <div>
                    <div className="font-semibold mb-1">总体评价</div>
                    <div className="text-sm text-gray-600">{responseData.analysis.overall}</div>
                  </div>
                  <div>
                    <div className="font-semibold mb-1">饮食分析</div>
                    <div className="text-sm text-gray-600">{responseData.analysis.diet}</div>
                  </div>
                  <div>
                    <div className="font-semibold mb-1">运动分析</div>
                    <div className="text-sm text-gray-600">{responseData.analysis.exercise}</div>
                  </div>
                  <div>
                    <div className="font-semibold mb-1">睡眠分析</div>
                    <div className="text-sm text-gray-600">{responseData.analysis.sleep}</div>
                  </div>
                  <div>
                    <div className="font-semibold mb-1">基础健康</div>
                    <div className="text-sm text-gray-600">
                      BMI指数: {responseData.bmi || '未提供'}，
                      健康状态: {responseData.bmiCategory === 'normal' ? '正常' :
                                responseData.bmiCategory === 'overweight' ? '超重' :
                                responseData.bmiCategory === 'obesity' ? '肥胖' : '偏瘦'}
                    </div>
                  </div>
                  <div>
                    <div className="font-semibold mb-1">风险控制能力</div>
                    <div className="text-sm text-gray-600">
                      {responseData.dimensionScores.riskFactors >= 10 ? '✅ 无吸烟和过量饮酒，风险控制能力优秀！继续保持' :
                       responseData.dimensionScores.riskFactors >= 7 ? '✨ 基本无重大危险因素，风险控制能力良好，建议继续保持健康习惯' :
                       responseData.dimensionScores.riskFactors >= 4 ? '⚠️ 存在一定危险因素，风险控制能力一般，建议改善' :
                       '🚨 危险因素较多，风险控制能力较弱，强烈建议立即改善生活方式'}
                    </div>
                  </div>
                  {responseData.analysis.healthRisks && responseData.analysis.healthRisks.length > 0 && (
                    <div>
                      <div className="font-semibold mb-1">健康风险</div>
                      <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                        {responseData.analysis.healthRisks.map((risk: string, index: number) => (
                          <li key={index}>{risk}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>

          {/* 建议 */}
          <Card>
            <CardHeader>
              <CardTitle>建议</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {responseData.recommendations && (
                <>
                  {responseData.recommendations.diet && responseData.recommendations.diet.length > 0 && (
                    <div>
                      <div className="font-semibold mb-1">饮食建议</div>
                      <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                        {responseData.recommendations.diet.map((rec: string, index: number) => (
                          <li key={index}>{rec}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {responseData.recommendations.exercise && responseData.recommendations.exercise.length > 0 && (
                    <div>
                      <div className="font-semibold mb-1">运动建议</div>
                      <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                        {responseData.recommendations.exercise.map((rec: string, index: number) => (
                          <li key={index}>{rec}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {responseData.recommendations.sleep && responseData.recommendations.sleep.length > 0 && (
                    <div>
                      <div className="font-semibold mb-1">睡眠建议</div>
                      <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                        {responseData.recommendations.sleep.map((rec: string, index: number) => (
                          <li key={index}>{rec}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {responseData.recommendations.healthMonitoring && responseData.recommendations.healthMonitoring.length > 0 && (
                    <div>
                      <div className="font-semibold mb-1">健康监测</div>
                      <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                        {responseData.recommendations.healthMonitoring.map((rec: string, index: number) => (
                          <li key={index}>{rec}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {responseData.recommendations.psychologicalSupport && responseData.recommendations.psychologicalSupport.length > 0 && (
                    <div>
                      <div className="font-semibold mb-1">心理支持</div>
                      <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                        {responseData.recommendations.psychologicalSupport.map((rec: string, index: number) => (
                          <li key={index}>{rec}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* 问卷调查详细内容 */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>问卷调查详细内容</CardTitle>
            <CardDescription>用户填写的详细问卷信息</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* 基本信息 */}
            <div>
              <h3 className="font-semibold mb-3 text-lg">基本信息</h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  <div>
                    <div className="text-xs text-gray-500">吸烟</div>
                    <div className="text-sm font-medium">{requestData.generalInfo?.smoking?.isSmoking ? '是' : '否'}</div>
                  </div>
                  {requestData.generalInfo?.smoking?.isSmoking && (
                    <div>
                      <div className="text-xs text-gray-500">每日吸烟量</div>
                      <div className="text-sm font-medium">{requestData.generalInfo.smoking.cigarettesPerDay} 支</div>
                    </div>
                  )}
                  <div>
                    <div className="text-xs text-gray-500">饮酒</div>
                    <div className="text-sm font-medium">{requestData.generalInfo?.drinking?.isDrinking ? '是' : '否'}</div>
                  </div>
                  {requestData.generalInfo?.drinking?.isDrinking && (
                    <div>
                      <div className="text-xs text-gray-500">每日饮酒量</div>
                      <div className="text-sm font-medium">{requestData.generalInfo.drinking.gramsOfAlcoholPerDay} 克</div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* 身体情况 */}
            <div>
              <h3 className="font-semibold mb-3 text-lg">身体情况</h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  <div>
                    <div className="text-xs text-gray-500">身高</div>
                    <div className="text-sm font-medium">{requestData.enrollmentInfo?.height} cm</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">体重</div>
                    <div className="text-sm font-medium">{requestData.enrollmentInfo?.weight} kg</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">BMI</div>
                    <div className="text-sm font-medium">{assessment.bmi}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">肥胖情况</div>
                    <div className="text-sm font-medium">
                      {assessment.bmiCategory === 'normal' ? '正常' :
                       assessment.bmiCategory === 'overweight' ? '超重' :
                       assessment.bmiCategory === 'obesity' ? '肥胖' :
                       assessment.bmiCategory === 'underweight' ? '偏瘦' : assessment.bmiCategory}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">腰围</div>
                    <div className="text-sm font-medium">{requestData.enrollmentInfo?.waistline} cm</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">肥胖类型</div>
                    <div className="text-sm font-medium">
                      {(() => {
                        const waistline = requestData.enrollmentInfo?.waistline;
                        const gender = assessment.gender;
                        if (!waistline || !gender) return '-';
                        
                        if (gender === 'male') {
                          if (waistline < 85) return '正常';
                          if (waistline < 90) return '中心型肥胖前期';
                          return '中心型肥胖';
                        } else {
                          if (waistline < 80) return '正常';
                          if (waistline < 85) return '中心型肥胖前期';
                          return '中心型肥胖';
                        }
                      })()}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">减重决心</div>
                    <div className="text-sm font-medium">
                      {requestData.enrollmentInfo?.weightLossDetermination === 'high' ? '高' :
                       requestData.enrollmentInfo?.weightLossDetermination === 'medium' ? '中' : '低'}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 既往史 */}
            <div>
              <h3 className="font-semibold mb-3 text-lg">既往史</h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {requestData.medicalHistory?.hypertension && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">高血压</span>
                      <span className="text-sm text-red-600 font-semibold">有</span>
                    </div>
                  )}
                  {requestData.medicalHistory?.diabetes && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">糖尿病</span>
                      <span className="text-sm text-red-600 font-semibold">有</span>
                    </div>
                  )}
                  {requestData.medicalHistory?.hyperlipidemia && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">高血脂</span>
                      <span className="text-sm text-red-600 font-semibold">有</span>
                    </div>
                  )}
                  {requestData.medicalHistory?.fattyLiver && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">脂肪肝</span>
                      <span className="text-sm text-red-600 font-semibold">有</span>
                    </div>
                  )}
                  {requestData.medicalHistory?.coronaryHeartDisease && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">冠心病</span>
                      <span className="text-sm text-red-600 font-semibold">有</span>
                    </div>
                  )}
                  {requestData.medicalHistory?.heartFailure && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">心衰</span>
                      <span className="text-sm text-red-600 font-semibold">有</span>
                    </div>
                  )}
                  {requestData.medicalHistory?.hyperuricemia && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">高尿酸</span>
                      <span className="text-sm text-red-600 font-semibold">有</span>
                    </div>
                  )}
                  {requestData.medicalHistory?.gout && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">痛风</span>
                      <span className="text-sm text-red-600 font-semibold">有</span>
                    </div>
                  )}
                  {requestData.medicalHistory?.other && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">其他</span>
                      <span className="text-sm text-red-600 font-semibold">{requestData.medicalHistory.other}</span>
                    </div>
                  )}
                  {!requestData.medicalHistory?.hypertension &&
                   !requestData.medicalHistory?.diabetes &&
                   !requestData.medicalHistory?.hyperlipidemia &&
                   !requestData.medicalHistory?.fattyLiver &&
                   !requestData.medicalHistory?.coronaryHeartDisease &&
                   !requestData.medicalHistory?.heartFailure &&
                   !requestData.medicalHistory?.hyperuricemia &&
                   !requestData.medicalHistory?.gout &&
                   !requestData.medicalHistory?.other && (
                    <div className="col-span-2 md:col-span-4 text-sm text-gray-600">无既往史</div>
                  )}
                </div>
              </div>
            </div>

            {/* 饮食评估 */}
            <div>
              <h3 className="font-semibold mb-3 text-lg">饮食评估</h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {/* 食物选择 */}
                  <div>
                    <div className="text-xs text-gray-500">主食偏好</div>
                    <div className="text-sm font-medium">
                      {requestData.dietAssessment?.foodSelection?.stapleFood === 'refined' ? '精细主食为主' :
                       requestData.dietAssessment?.foodSelection?.stapleFood === 'mixed' ? '粗细搭配' : '-'}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">蛋白质来源</div>
                    <div className="text-sm font-medium">
                      {requestData.dietAssessment?.foodSelection?.proteinSource === 'balanced' ? '优质蛋白均衡（鱼禽蛋奶豆全）' :
                       requestData.dietAssessment?.foodSelection?.proteinSource === 'simple' ? '简单优质蛋白（1-2种）' :
                       requestData.dietAssessment?.foodSelection?.proteinSource === 'insufficient' ? '优质蛋白不足' : '-'}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">偏好加工肉</div>
                    <div className="text-sm font-medium">{requestData.dietAssessment?.foodSelection?.processedMeatPreference === true ? '是' : requestData.dietAssessment?.foodSelection?.processedMeatPreference === false ? '否' : '-'}</div>
                  </div>
                  
                  {/* 蔬菜水果摄入 */}
                  <div>
                    <div className="text-xs text-gray-500">每日蔬菜≥300g</div>
                    <div className="text-sm font-medium">{requestData.dietAssessment?.fruitVegetableIntake?.vegetable300gOrMore === true ? '是' : requestData.dietAssessment?.fruitVegetableIntake?.vegetable300gOrMore === false ? '否' : '-'}</div>
                  </div>
                  {requestData.dietAssessment?.fruitVegetableIntake?.vegetable300gOrMore && (
                    <div>
                      <div className="text-xs text-gray-500">深色蔬菜占比</div>
                      <div className="text-sm font-medium">{requestData.dietAssessment.fruitVegetableIntake.darkVegetableRatio}%</div>
                    </div>
                  )}
                  <div>
                    <div className="text-xs text-gray-500">每日水果≥200g</div>
                    <div className="text-sm font-medium">{requestData.dietAssessment?.fruitVegetableIntake?.fruit200gOrMore === true ? '是' : requestData.dietAssessment?.fruitVegetableIntake?.fruit200gOrMore === false ? '否' : '-'}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">用果汁代替水果</div>
                    <div className="text-sm font-medium">{requestData.dietAssessment?.fruitVegetableIntake?.juiceInsteadOfFruit === true ? '是' : requestData.dietAssessment?.fruitVegetableIntake?.juiceInsteadOfFruit === false ? '否' : '-'}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">常吃腌制/罐头果蔬</div>
                    <div className="text-sm font-medium">{requestData.dietAssessment?.fruitVegetableIntake?.cannedPickledFruitsAndVegetables === true ? '是' : requestData.dietAssessment?.fruitVegetableIntake?.cannedPickledFruitsAndVegetables === false ? '否' : '-'}</div>
                  </div>
                  
                  {/* 油脂和调料 */}
                  <div>
                    <div className="text-xs text-gray-500">烹饪用油</div>
                    <div className="text-sm font-medium">
                      {requestData.dietAssessment?.oilAndSeasoning?.cookingOilType === 'vegetable' ? '植物油为主' :
                       requestData.dietAssessment?.oilAndSeasoning?.cookingOilType === 'animal' ? '动物油为主' :
                       requestData.dietAssessment?.oilAndSeasoning?.cookingOilType === 'mixed' ? '混合使用' : '-'}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">油脂摄入超标</div>
                    <div className="text-sm font-medium">{requestData.dietAssessment?.oilAndSeasoning?.oilIntakeExceeded === true ? '是' : requestData.dietAssessment?.oilAndSeasoning?.oilIntakeExceeded === false ? '否' : '-'}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">盐摄入超标</div>
                    <div className="text-sm font-medium">{requestData.dietAssessment?.oilAndSeasoning?.saltIntakeExceeded === true ? '是' : requestData.dietAssessment?.oilAndSeasoning?.saltIntakeExceeded === false ? '否' : '-'}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">添加糖摄入超标</div>
                    <div className="text-sm font-medium">{requestData.dietAssessment?.oilAndSeasoning?.sugarIntakeExceeded === true ? '是' : requestData.dietAssessment?.oilAndSeasoning?.sugarIntakeExceeded === false ? '否' : '-'}</div>
                  </div>
                  
                  {/* 进食习惯 */}
                  <div>
                    <div className="text-xs text-gray-500">进食速度</div>
                    <div className="text-sm font-medium">
                      {requestData.dietAssessment?.eatingSpeed === 'veryFast' ? '非常快' :
                       requestData.dietAssessment?.eatingSpeed === 'fast' ? '较快' :
                       requestData.dietAssessment?.eatingSpeed === 'normal' ? '正常' :
                       requestData.dietAssessment?.eatingSpeed === 'slow' ? '较慢' : '-'}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">早餐频率</div>
                    <div className="text-sm font-medium">
                      {requestData.dietAssessment?.mealRegularity?.breakfastFrequency === 'daily' ? '每天' :
                       requestData.dietAssessment?.mealRegularity?.breakfastFrequency === 'frequent' ? '经常' :
                       requestData.dietAssessment?.mealRegularity?.breakfastFrequency === 'occasional' ? '偶尔' : '-'}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">晚餐时间</div>
                    <div className="text-sm font-medium">{requestData.dietAssessment?.mealRegularity?.dinnerTime || '-'}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">夜宵频率</div>
                    <div className="text-sm font-medium">
                      {(() => {
                        const freq = requestData.dietAssessment?.mealRegularity?.midnightSnackFrequency;
                        if (freq === 'none') return '无';
                        if (freq === '1-2times') return '1-2次/周';
                        if (freq === '≥3times') return '≥3次/周';
                        return freq || '-';
                      })()}
                    </div>
                  </div>
                  
                  {/* 外出就餐 */}
                  <div>
                    <div className="text-xs text-gray-500">外出就餐频率</div>
                    <div className="text-sm font-medium">
                      {(() => {
                        const freq = requestData.dietAssessment?.eatingOut?.frequency;
                        if (freq === '0times') return '0次/周';
                        if (freq === '1-3times') return '1-3次/周';
                        if (freq === '4-6times') return '4-6次/周';
                        if (freq === 'daily') return '每天';
                        return freq || '-';
                      })()}
                    </div>
                  </div>
                  {requestData.dietAssessment?.eatingOut?.frequency && requestData.dietAssessment.eatingOut.frequency !== '0times' && (
                    <div>
                      <div className="text-xs text-gray-500">外出就餐类型</div>
                      <div className="text-sm font-medium">
                        {requestData.dietAssessment?.eatingOut?.mainTypes?.length > 0 
                          ? requestData.dietAssessment.eatingOut.mainTypes.map((type: string) => {
                              if (type === 'fastFood') return '快餐';
                              if (type === 'hotpotBBQ') return '火锅/烧烤';
                              if (type === 'stirFry') return '炒菜';
                              if (type === 'lightMeal') return '轻食';
                              return type;
                            }).join('、')
                          : '-'}
                      </div>
                    </div>
                  )}
                  
                  {/* 烹饪方式 */}
                  <div>
                    <div className="text-xs text-gray-500">烹饪方式偏好</div>
                    <div className="text-sm font-medium">
                      {requestData.dietAssessment?.cookingMethodPreference === 'steamed' ? '蒸煮炖' :
                       requestData.dietAssessment?.cookingMethodPreference === 'mixed' ? '多样化（含蒸煮）' :
                       requestData.dietAssessment?.cookingMethodPreference === 'fried' ? '煎炸烤' : '-'}
                    </div>
                  </div>
                  
                  {/* 代餐 */}
                  <div>
                    <div className="text-xs text-gray-500">使用代餐</div>
                    <div className="text-sm font-medium">{requestData.dietAssessment?.mealReplacement?.isUsing === true ? '是' : requestData.dietAssessment?.mealReplacement?.isUsing === false ? '否' : '-'}</div>
                  </div>
                  
                  {/* 饮食禁忌 */}
                  <div>
                    <div className="text-xs text-gray-500">饮食禁忌</div>
                    <div className="text-sm font-medium">{requestData.dietAssessment?.foodAllergyOrTaboo?.hasTaboo === true ? '是' : requestData.dietAssessment?.foodAllergyOrTaboo?.hasTaboo === false ? '否' : '-'}</div>
                  </div>
                  {requestData.dietAssessment?.foodAllergyOrTaboo?.hasTaboo && requestData.dietAssessment.foodAllergyOrTaboo.specificFoods && (
                    <div>
                      <div className="text-xs text-gray-500">具体食物</div>
                      <div className="text-sm font-medium">{requestData.dietAssessment.foodAllergyOrTaboo.specificFoods}</div>
                    </div>
                  )}
                  
                  {/* 饮水量 */}
                  <div>
                    <div className="text-xs text-gray-500">每日饮水量</div>
                    <div className="text-sm font-medium">{requestData.dietAssessment?.dailyWaterIntake || '-'}</div>
                  </div>
                  
                  {/* 饮食偏好 */}
                  {requestData.dietAssessment?.dietaryPreferences?.length > 0 && (
                    <div>
                      <div className="text-xs text-gray-500">饮食偏好</div>
                      <div className="text-sm font-medium">{requestData.dietAssessment.dietaryPreferences.join('、')}</div>
                    </div>
                  )}
                  {requestData.dietAssessment?.dietaryPreferencesNone && (
                    <div>
                      <div className="text-xs text-gray-500">饮食偏好</div>
                      <div className="text-sm font-medium">无偏好</div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* 运动评估 */}
            <div>
              <h3 className="font-semibold mb-3 text-lg">运动评估</h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  <div>
                    <div className="text-xs text-gray-500">每日步数</div>
                    <div className="text-sm font-medium">{requestData.exerciseAssessment?.dailySteps}</div>
                  </div>
                  {requestData.exerciseAssessment?.aerobicExercise && (
                    <>
                      <div>
                        <div className="text-xs text-gray-500">有氧运动频率</div>
                        <div className="text-sm font-medium">{requestData.exerciseAssessment.aerobicExercise.frequency} 次/周</div>
                      </div>
                      <div>
                        <div className="text-xs text-gray-500">有氧运动时长</div>
                        <div className="text-sm font-medium">{requestData.exerciseAssessment.aerobicExercise.duration} 分钟/次</div>
                      </div>
                    </>
                  )}
                  {requestData.exerciseAssessment?.resistanceExercise && (
                    <>
                      <div>
                        <div className="text-xs text-gray-500">抗阻运动频率</div>
                        <div className="text-sm font-medium">{requestData.exerciseAssessment.resistanceExercise.frequency} 次/周</div>
                      </div>
                      <div>
                        <div className="text-xs text-gray-500">抗阻运动时长</div>
                        <div className="text-sm font-medium">{requestData.exerciseAssessment.resistanceExercise.duration} 分钟/次</div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* 睡眠评估 */}
            <div>
              <h3 className="font-semibold mb-3 text-lg">睡眠评估</h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  <div>
                    <div className="text-xs text-gray-500">睡眠时长</div>
                    <div className="text-sm font-medium">{requestData.sleepAssessment?.sleepHours}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">入睡时间</div>
                    <div className="text-sm font-medium">{requestData.sleepAssessment?.bedtime}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">白天精力</div>
                    <div className="text-sm font-medium">
                      {requestData.sleepAssessment?.daytimeEnergy === 'energetic' ? '精力充沛' :
                       requestData.sleepAssessment?.daytimeEnergy === 'tired' ? '疲劳困倦' : '-'}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">是否打鼾</div>
                    <div className="text-sm font-medium">{requestData.sleepAssessment?.snoring ? '是' : '否'}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">使用助眠/CPAP</div>
                    <div className="text-sm font-medium">{requestData.sleepAssessment?.sleepAidOrCPAP ? '是' : '否'}</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 底部操作按钮 */}
        <div className="flex gap-4 mt-6">
          <Link href="/admin/assessments" className="flex-1">
            <Button variant="outline" className="w-full">
              返回列表
            </Button>
          </Link>
          <Button onClick={handleExportUserReport} disabled={exporting} className="flex-1 bg-gradient-to-r from-[#2288D2] to-[#0D2860] hover:from-[#1976D2] hover:to-[#0A1F4D]">
            <Download className="h-4 w-4 mr-2" />
            {exporting ? '生成中...' : '下载用户报告'}
          </Button>
        </div>
      </div>
    </div>
  );
}
