'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, ArrowLeft, Eye } from 'lucide-react';
import Link from 'next/link';

interface Assessment {
  id: string;
  name: string | null;
  gender: 'male' | 'female';
  age: number;
  totalScore: number;
  totalScoreLevel: string;
  bmi: string;
  createdAt: string;
}

const SCORE_LEVEL_MAP: Record<string, { label: string; color: string }> = {
  excellent: { label: '优秀', color: 'bg-green-100 text-green-700' },
  good: { label: '良好', color: 'bg-blue-100 text-blue-700' },
  average: { label: '中等', color: 'bg-yellow-100 text-yellow-700' },
  poor: { label: '较差', color: 'bg-orange-100 text-orange-700' },
  veryPoor: { label: '很差', color: 'bg-red-100 text-red-700' },
};

export default function AdminAssessmentsPage() {
  const router = useRouter();
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const pageSize = 20;

  // 筛选条件
  const [filters, setFilters] = useState({
    search: '',
    gender: 'all' as 'male' | 'female' | 'all',
    totalScoreLevel: 'all' as any,
    startDate: '',
    endDate: '',
    id: '',
  });

  useEffect(() => {
    // 检查登录状态
    const isAuthenticated = localStorage.getItem('adminAuthenticated');
    if (!isAuthenticated) {
      router.push('/admin/login');
      return;
    }

    fetchAssessments();
  }, [router, page, filters]);

  const fetchAssessments = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        skip: ((page - 1) * pageSize).toString(),
        limit: pageSize.toString(),
      });

      if (filters.search) params.append('search', filters.search);
      if (filters.gender && filters.gender !== 'all') params.append('gender', filters.gender);
      if (filters.totalScoreLevel && filters.totalScoreLevel !== 'all') params.append('totalScoreLevel', filters.totalScoreLevel);
      if (filters.startDate) params.append('startDate', filters.startDate);
      if (filters.endDate) params.append('endDate', filters.endDate);
      if (filters.id) params.append('id', filters.id);

      console.log('Fetching with params:', params.toString());

      const response = await fetch(`/api/admin/assessments?${params}`);
      if (response.ok) {
        const data = await response.json();
        console.log('Response data:', data);
        setAssessments(data.data || []);
        setTotal(data.total || 0);
      } else {
        console.error('API error:', response.status, response.statusText);
        const errorData = await response.json();
        console.error('Error data:', errorData);
        setAssessments([]);
        setTotal(0);
      }
    } catch (error) {
      console.error('获取评估列表失败:', error);
      setAssessments([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('adminAuthenticated');
    router.push('/admin/login');
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const handleFilterChange = (key: string, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setPage(1); // 重置到第一页
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* 顶部导航栏 */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-4">
              <Link href="/admin/dashboard">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </Link>
              <h1 className="text-2xl font-bold text-gray-900">评估记录</h1>
            </div>
            <Button variant="outline" onClick={handleLogout}>退出登录</Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* 筛选区域 */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">筛选条件</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
              {/* ID 筛选 */}
              <Input
                placeholder="按 ID 筛选..."
                value={filters.id}
                onChange={(e) => handleFilterChange('id', e.target.value)}
              />

              {/* 搜索 */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="搜索用户名..."
                  value={filters.search}
                  onChange={(e) => handleFilterChange('search', e.target.value)}
                  className="pl-10"
                />
              </div>

              {/* 性别筛选 */}
              <Select value={filters.gender} onValueChange={(value) => handleFilterChange('gender', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="性别" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  <SelectItem value="male">男性</SelectItem>
                  <SelectItem value="female">女性</SelectItem>
                </SelectContent>
              </Select>

              {/* 评分等级筛选 */}
              <Select value={filters.totalScoreLevel} onValueChange={(value) => handleFilterChange('totalScoreLevel', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="评分等级" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  <SelectItem value="excellent">优秀</SelectItem>
                  <SelectItem value="good">良好</SelectItem>
                  <SelectItem value="average">中等</SelectItem>
                  <SelectItem value="poor">较差</SelectItem>
                  <SelectItem value="veryPoor">很差</SelectItem>
                </SelectContent>
              </Select>

              {/* 开始日期 */}
              <Input
                type="date"
                value={filters.startDate}
                onChange={(e) => handleFilterChange('startDate', e.target.value)}
              />

              {/* 结束日期 */}
              <Input
                type="date"
                value={filters.endDate}
                onChange={(e) => handleFilterChange('endDate', e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* 数据表格 */}
        <Card>
          <CardContent className="p-0">
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="mt-4 text-gray-600">加载中...</p>
              </div>
            ) : assessments.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                暂无数据
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">用户</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">性别</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">年龄</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">BMI</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">总分</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">等级</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">提交时间</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {assessments.map((assessment) => (
                      <tr key={assessment.id} className="hover:bg-gray-50">
                        <td className="px-4 py-4 whitespace-nowrap text-xs text-gray-500 font-mono">
                          {assessment.id.slice(0, 8)}...
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {assessment.name || '匿名'}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                          {assessment.gender === 'male' ? '男' : '女'}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                          {assessment.age}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                          {assessment.bmi}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">
                          {assessment.totalScore}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${SCORE_LEVEL_MAP[assessment.totalScoreLevel]?.color || 'bg-gray-100 text-gray-700'}`}>
                            {SCORE_LEVEL_MAP[assessment.totalScoreLevel]?.label || assessment.totalScoreLevel}
                          </span>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatDate(assessment.createdAt)}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm">
                          <Link href={`/admin/assessments/${assessment.id}`}>
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4 mr-1" />
                              查看
                            </Button>
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 分页 */}
        {total > pageSize && (
          <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-4">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                onClick={() => setPage(1)}
                disabled={page === 1}
                className="px-3"
              >
                首页
              </Button>
              <Button
                variant="outline"
                onClick={() => setPage(prev => Math.max(1, prev - 1))}
                disabled={page === 1}
              >
                上一页
              </Button>
            </div>

            <div className="flex items-center gap-1">
              {(() => {
                const totalPages = Math.ceil(total / pageSize);
                const pages: (number | string)[] = [];
                
                // 总是显示第一页
                if (totalPages > 0) {
                  pages.push(1);
                }

                // 如果第一页和最后一页之间有足够的空间
                if (totalPages > 1) {
                  // 显示当前页附近的页码
                  let startPage = Math.max(2, page - 1);
                  let endPage = Math.min(totalPages - 1, page + 1);

                  // 如果当前页靠近开头
                  if (page <= 3) {
                    startPage = 2;
                    endPage = Math.min(totalPages - 1, 4);
                  }
                  // 如果当前页靠近结尾
                  else if (page >= totalPages - 2) {
                    startPage = Math.max(2, totalPages - 3);
                    endPage = totalPages - 1;
                  }

                  // 添加省略号和中间页码
                  if (startPage > 2) {
                    pages.push('...');
                  }
                  for (let i = startPage; i <= endPage; i++) {
                    pages.push(i);
                  }
                  if (endPage < totalPages - 1) {
                    pages.push('...');
                  }

                  // 总是显示最后一页
                  if (totalPages > 1) {
                    pages.push(totalPages);
                  }
                }

                return pages.map((p, index) => (
                  typeof p === 'number' ? (
                    <Button
                      key={`page-${p}-${index}`}
                      variant={page === p ? 'default' : 'outline'}
                      onClick={() => setPage(p)}
                      className={`w-10 h-10 ${page === p ? 'bg-blue-600 hover:bg-blue-700' : ''}`}
                    >
                      {p}
                    </Button>
                  ) : (
                    <span key={`ellipsis-${index}`} className="px-2 py-2 text-gray-500">
                      {p}
                    </span>
                  )
                ));
              })()}
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                onClick={() => setPage(prev => Math.min(Math.ceil(total / pageSize), prev + 1))}
                disabled={page >= Math.ceil(total / pageSize)}
              >
                下一页
              </Button>
              <Button
                variant="outline"
                onClick={() => setPage(Math.ceil(total / pageSize))}
                disabled={page >= Math.ceil(total / pageSize)}
                className="px-3"
              >
                末页
              </Button>
            </div>

            <span className="text-sm text-gray-600 whitespace-nowrap">
              第 {page} 页 / 共 {Math.ceil(total / pageSize)} 页 ({total} 条记录)
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
