import { NextRequest, NextResponse } from 'next/server';
import { AssessmentRequest, AssessmentResult } from '@/types/assessment';
import { AssessmentScorer } from '@/lib/scoring';
import { assessmentManager } from '@/storage/database';

export async function POST(request: NextRequest) {
  try {
    const body: AssessmentRequest = await request.json();

    // 验证必填字段
    if (!body.generalInfo || !body.enrollmentInfo || !body.dietAssessment || !body.exerciseAssessment || !body.sleepAssessment) {
      return NextResponse.json(
        { error: '缺少必填字段' },
        { status: 400 }
      );
    }

    // 创建评分器并计算结果
    const scorer = new AssessmentScorer(body);
    const result: AssessmentResult = scorer.score();

    // 保存数据到数据库
    try {
      await assessmentManager.createAssessment({
        name: body.generalInfo.name,
        gender: body.generalInfo.gender,
        age: body.generalInfo.age,
        requestData: body,
        responseData: result,
        totalScore: result.totalScore,
        bmi: result.bmi.toFixed(1),
        totalScoreLevel: result.totalScoreLevel,
        bmiCategory: result.bmiCategory,
      });
    } catch (dbError) {
      console.error('保存评估数据到数据库失败:', dbError);
      // 即使保存失败，也返回评分结果（不影响用户体验）
      // 在生产环境中，应该记录错误并通知管理员
    }

    return NextResponse.json(result);
  } catch (error) {
    console.error('评分失败:', error);
    return NextResponse.json(
      { error: '评分失败，请检查输入数据' },
      { status: 500 }
    );
  }
}
