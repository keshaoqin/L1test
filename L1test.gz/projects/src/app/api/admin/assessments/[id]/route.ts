import { NextRequest, NextResponse } from 'next/server';
import { assessmentManager } from '@/storage/database';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // 获取评估详情
    const assessment = await assessmentManager.getAssessmentById(id);
    
    if (!assessment) {
      return NextResponse.json(
        { error: '评估记录不存在' },
        { status: 404 }
      );
    }

    return NextResponse.json(assessment);
  } catch (error) {
    console.error('获取评估详情失败:', error);
    return NextResponse.json(
      { error: '获取评估详情失败' },
      { status: 500 }
    );
  }
}
