import { NextRequest, NextResponse } from 'next/server';
import { assessmentManager } from '@/storage/database';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    
    // 解析查询参数
    const skip = parseInt(searchParams.get('skip') || '0');
    const limit = parseInt(searchParams.get('limit') || '20');
    const gender = searchParams.get('gender') as 'male' | 'female' | 'all' | null;
    const totalScoreLevel = searchParams.get('totalScoreLevel') as 
      'excellent' | 'good' | 'average' | 'poor' | 'veryPoor' | 'all' | null;
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const search = searchParams.get('search');
    const id = searchParams.get('id');

    // 构建筛选条件
    const filters: any = {};
    if (gender && gender !== 'all') filters.gender = gender;
    if (totalScoreLevel && totalScoreLevel !== 'all') filters.totalScoreLevel = totalScoreLevel;
    if (startDate) filters.startDate = startDate;
    if (endDate) filters.endDate = endDate;
    if (id) filters.id = id;

    // 获取评估列表
    const result = await assessmentManager.getAssessments({
      skip,
      limit,
      filters,
      search: search || undefined,
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error('获取评估列表失败:', error);
    return NextResponse.json(
      { error: '获取评估列表失败' },
      { status: 500 }
    );
  }
}
