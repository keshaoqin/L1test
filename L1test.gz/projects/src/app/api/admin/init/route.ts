import { NextRequest, NextResponse } from 'next/server';
import { adminManager } from '@/storage/database';

// GET /api/admin/init - 初始化所有管理员（admin 和 ksq）
export async function GET(request: NextRequest) {
  try {
    // 初始化所有管理员
    const result = await adminManager.initAllAdmins();

    const details = result.results.map(r => {
      let msg = '';
      switch (r.action) {
        case 'created':
          msg = `${r.username} 已创建`;
          break;
        case 'enabled':
          msg = `${r.username} 已启用`;
          break;
        case 'password_reset':
          msg = `${r.username} 密码已重置`;
          break;
        case 'exists':
          msg = `${r.username} 已存在且状态正常`;
          break;
      }
      return msg;
    }).join('；');

    return NextResponse.json({
      success: true,
      message: '所有管理员已初始化',
      details,
      results: result.results,
      credentials: [
        { username: 'admin', password: 'admin123' },
        { username: 'ksq', password: 'ksq123' }
      ]
    });
  } catch (error) {
    console.error('初始化失败:', error);
    return NextResponse.json(
      { error: '初始化失败', details: error instanceof Error ? error.message : String(error) },
      { status: 500 }
    );
  }
}
