import { NextRequest, NextResponse } from 'next/server';
import { adminManager } from '@/storage/database';

// DELETE /api/admin/users/[id] - 删除管理员
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const success = await adminManager.deleteAdmin(id);
    
    if (!success) {
      return NextResponse.json(
        { error: '管理员不存在' },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('删除管理员失败:', error);
    return NextResponse.json(
      { error: '删除管理员失败' },
      { status: 500 }
    );
  }
}

// PATCH /api/admin/users/[id] - 更新管理员状态
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { isActive, newPassword } = body;

    // 如果提供新密码，则修改密码
    if (newPassword) {
      const success = await adminManager.changePassword(id, newPassword);
      if (!success) {
        return NextResponse.json(
          { error: '管理员不存在' },
          { status: 404 }
        );
      }
    }

    // 如果提供状态，则更新状态
    if (isActive !== undefined) {
      const admin = await adminManager.updateAdminStatus(id, isActive);
      if (!admin) {
        return NextResponse.json(
          { error: '管理员不存在' },
          { status: 404 }
        );
      }
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('更新管理员失败:', error);
    return NextResponse.json(
      { error: '更新管理员失败' },
      { status: 500 }
    );
  }
}
