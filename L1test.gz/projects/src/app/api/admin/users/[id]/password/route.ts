import { NextRequest, NextResponse } from "next/server";
import { AdminManager } from "@/storage/database/adminManager";

const adminManager = new AdminManager();

/**
 * PATCH /api/admin/users/:id/password
 * 修改管理员密码
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { newPassword } = body;

    // 验证密码格式
    if (!newPassword || typeof newPassword !== "string" || newPassword.length < 6) {
      return NextResponse.json(
        { error: "密码长度至少为6位" },
        { status: 400 }
      );
    }

    // 修改密码
    const success = await adminManager.changePassword(id, newPassword);

    if (!success) {
      return NextResponse.json(
        { error: "修改密码失败，管理员不存在" },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("修改密码错误:", error);
    return NextResponse.json(
      { error: "修改密码失败" },
      { status: 500 }
    );
  }
}
