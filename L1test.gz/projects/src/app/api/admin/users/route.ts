import { NextRequest, NextResponse } from 'next/server';
import { adminManager } from '@/storage/database';

// GET /api/admin/users - 获取所有管理员
export async function GET(request: NextRequest) {
  try {
    // 从session或token中获取当前用户信息（简化版，实际应该验证权限）
    const admins = await adminManager.getAllAdmins();
    
    // 不返回密码哈希
    const sanitizedAdmins = admins.map(admin => ({
      id: admin.id,
      username: admin.username,
      isActive: admin.isActive,
      createdAt: admin.createdAt,
      updatedAt: admin.updatedAt,
    }));

    return NextResponse.json(sanitizedAdmins);
  } catch (error) {
    console.error('获取管理员列表失败:', error);
    return NextResponse.json(
      { error: '获取管理员列表失败' },
      { status: 500 }
    );
  }
}

// POST /api/admin/users - 创建管理员
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, password, isActive } = body;

    // 验证必填字段
    if (!username || !password) {
      return NextResponse.json(
        { error: '用户名和密码不能为空' },
        { status: 400 }
      );
    }

    // 创建管理员
    const admin = await adminManager.createAdmin({
      username,
      password,
      isActive: isActive ?? true,
    });

    // 不返回密码哈希
    const sanitizedAdmin = {
      id: admin.id,
      username: admin.username,
      isActive: admin.isActive,
      createdAt: admin.createdAt,
      updatedAt: admin.updatedAt,
    };

    return NextResponse.json(sanitizedAdmin, { status: 201 });
  } catch (error: any) {
    console.error('创建管理员失败:', error);
    if (error.message === '用户名已存在') {
      return NextResponse.json(
        { error: error.message },
        { status: 409 }
      );
    }
    return NextResponse.json(
      { error: '创建管理员失败' },
      { status: 500 }
    );
  }
}
