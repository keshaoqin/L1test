import { NextRequest, NextResponse } from 'next/server';
import { adminManager } from '@/storage/database';

// 自动初始化标志，避免重复初始化
let autoInitAttempted = false;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, password } = body;

    // 验证必填字段
    if (!username || !password) {
      return NextResponse.json(
        { error: '用户名和密码不能为空' },
        { status: 400 }
      );
    }

    // 验证登录
    const admin = await adminManager.validateLogin(username, password);
    
    if (!admin) {
      console.log(`登录失败: username=${username}, autoInitAttempted=${autoInitAttempted}`);
      
      // 如果登录失败，尝试自动初始化（仅在第一次失败时）
      if (!autoInitAttempted) {
        autoInitAttempted = true;
        console.log('首次登录失败，尝试自动初始化管理员账户...');
        
        try {
          const initResult = await adminManager.initAllAdmins();
          console.log('自动初始化完成:', initResult);
          
          // 返回特殊状态，提示用户重新登录
          return NextResponse.json(
            { 
              error: '系统已自动初始化，请重新登录',
              needRetry: true
            },
            { status: 401 }
          );
        } catch (initError) {
          console.error('自动初始化失败:', initError);
          // 即使初始化失败，也返回错误提示
          return NextResponse.json(
            { 
              error: '系统初始化失败，请联系管理员',
              initError: initError instanceof Error ? initError.message : String(initError)
            },
            { status: 500 }
          );
        }
      }
      
      return NextResponse.json(
        { error: '用户名或密码错误' },
        { status: 401 }
      );
    }

    // 登录成功，重置自动初始化标志
    if (autoInitAttempted) {
      console.log('登录成功，重置自动初始化标志');
      autoInitAttempted = false;
    }

    // 返回管理员信息（不包含密码）
    const responseData = {
      id: admin.id,
      username: admin.username,
      isActive: admin.isActive,
    };

    return NextResponse.json(responseData);
  } catch (error: any) {
    console.error('登录失败:', error);
    if (error.message === '账户已被禁用') {
      return NextResponse.json(
        { error: error.message },
        { status: 403 }
      );
    }
    return NextResponse.json(
      { error: '登录失败，请重试' },
      { status: 500 }
    );
  }
}
