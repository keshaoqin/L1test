import { NextRequest, NextResponse } from 'next/server';
import { assessmentManager } from '@/storage/database';

export async function GET(request: NextRequest) {
  try {
    // 获取仪表盘统计数据
    const stats = await assessmentManager.getDashboardStats();
    
    return NextResponse.json(stats);
  } catch (error) {
    console.error('获取仪表盘数据失败:', error);
    return NextResponse.json(
      { error: '获取仪表盘数据失败' },
      { status: 500 }
    );
  }
}
