# 部署文件清单

本文档列出了项目部署所需的所有文件及其说明。

## 📁 配置文件

### 环境配置
- `.env.production` - 生产环境变量配置
- `.env.example` - 环境变量示例文件

### Nginx 配置
- `nginx.conf` - Nginx 反向代理配置
- `setup-nginx.sh` - Nginx 安装和配置脚本（可执行）

### PM2 配置
- `ecosystem.config.js` - PM2 进程管理配置

### Systemd 配置
- `assessment-app.service` - Systemd 服务配置

## 📜 部署脚本

### 主部署脚本
- `deploy-with-pm2.sh` - PM2 部署脚本（可执行，推荐）
- `deploy.sh` - 基础部署脚本（可执行）
- `quick-start.sh` - 快速启动脚本（可执行）

### 测试脚本
- `test-admin-api.sh` - 管理员 API 测试脚本
- `test-admin-fix.sh` - 管理员修复测试脚本
- `test-admin-full.sh` - 管理员完整测试脚本

## 📖 文档文件

### 主要文档
- `DEPLOYMENT.md` - 详细部署指南
- `DEPLOYMENT_CHECKLIST.md` - 部署检查清单
- `DEPLOY_README.md` - 部署说明文档
- `QUICK_START.md` - 快速开始文档
- `DEPLOYMENT_SUMMARY_COMPLETE.md` - 部署配置完成摘要
- `DEPLOYMENT_FILES.md` - 本文件

### 原有文档
- `DEPLOYMENT_SUMMARY.md` - 旧版部署摘要
- `README.md` - 项目说明文档

## 🔧 系统配置

### Coze 配置
- `.coze` - Coze 平台配置文件
- `.cozeproj` - Coze 项目配置

### 构建脚本
- `scripts/build.sh` - 构建脚本
- `scripts/dev.sh` - 开发脚本
- `scripts/start.sh` - 启动脚本
- `scripts/prepare.sh` - 准备脚本

## 📦 项目配置

### Node.js 配置
- `package.json` - 项目依赖和脚本配置
- `pnpm-lock.yaml` - pnpm 锁定文件
- `tsconfig.json` - TypeScript 配置

### Next.js 配置
- `next.config.ts` - Next.js 配置

### 其他配置
- `.gitignore` - Git 忽略文件配置
- `tailwind.config.ts` - Tailwind CSS 配置

## 📂 源代码目录

### 应用代码
- `src/app/` - Next.js App Router 页面
- `src/components/` - React 组件
- `src/lib/` - 工具函数
- `src/storage/` - 数据存储层

### 配置文件
- `src/storage/database/` - 数据库相关配置

## 🎯 快速部署指南

### 方式一：PM2 部署（推荐）

```bash
cd /workspace/projects
./deploy-with-pm2.sh
```

### 方式二：基础部署

```bash
cd /workspace/projects
./deploy.sh
```

### 方式三：快速启动

```bash
cd /workspace/projects
./quick-start.sh
```

## 🔐 默认账户

| 用户名 | 密码 |
|--------|------|
| admin | admin123 |
| ksq | ksq123 |

## 🌐 访问地址

- **主页**: http://47.89.134.217:5000
- **管理后台**: http://47.89.134.217:5000/admin/login

## 📋 必需文件清单

部署项目至少需要以下文件：

### 必需配置
- [x] `.coze`
- [x] `.env.production`
- [x] `ecosystem.config.js`

### 必需脚本
- [x] `deploy-with-pm2.sh` 或 `deploy.sh`
- [x] `scripts/build.sh`
- [x] `scripts/start.sh`

### 必需代码
- [x] `package.json`
- [x] `next.config.ts`
- [x] `src/` 目录

## 🔍 文件权限检查

以下脚本需要执行权限：

```bash
chmod +x deploy-with-pm2.sh
chmod +x deploy.sh
chmod +x quick-start.sh
chmod +x setup-nginx.sh
```

当前状态：
```bash
ls -la *.sh
```

## 📝 部署前检查

部署前请确认：

1. [ ] 服务器环境已准备（Node.js 24.x, pnpm, PM2）
2. [ ] 防火墙已配置（开放端口 5000）
3. [ ] 项目代码已完整上传
4. [ ] `.env.production` 文件存在
5. [ ] 所有必需脚本有执行权限

## 🚀 一键部署

```bash
cd /workspace/projects
./deploy-with-pm2.sh
```

---

**最后更新**: 2025-01-09
**服务器 IP**: 47.89.134.217
**应用端口**: 5000
