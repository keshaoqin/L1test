#!/bin/bash

# 快速启动脚本 - 用于快速部署测试

set -e

echo "=================================="
echo "快速启动部署"
echo "=================================="

# 检查 Node.js
if ! command -v node &> /dev/null; then
    echo "错误: 未安装 Node.js"
    echo "请先安装 Node.js 24.x"
    exit 1
fi

echo "Node.js 版本: $(node --version)"

# 检查 pnpm
if ! command -v pnpm &> /dev/null; then
    echo "安装 pnpm..."
    npm install -g pnpm
fi

echo "pnpm 版本: $(pnpm --version)"

# 安装依赖
echo ""
echo "安装依赖..."
pnpm install

# 构建
echo ""
echo "构建项目..."
npx next build

# 启动
echo ""
echo "启动服务..."
npx next start --port 5000

echo ""
echo "服务已启动: http://47.89.134.217:5000"
