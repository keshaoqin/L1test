#!/bin/bash

# 测试修复后的管理后台 API

echo "🧪 测试修复后的管理后台 API..."
echo ""

# 测试基础列表查询（使用 all 值）
echo "1️⃣ 测试基础列表查询（无筛选）..."
curl -s "http://localhost:5000/api/admin/assessments?limit=2" | python3 -m json.tool | head -30
echo ""
echo ""

# 测试性别筛选为"all"
echo "2️⃣ 测试性别筛选为'all'（应该返回所有）..."
curl -s "http://localhost:5000/api/admin/assessments?gender=all&limit=2" | python3 -m json.tool | head -30
echo ""
echo ""

# 测试性别筛选为"male"
echo "3️⃣ 测试性别筛选为'male'..."
curl -s "http://localhost:5000/api/admin/assessments?gender=male&limit=2" | python3 -m json.tool | head -30
echo ""
echo ""

# 测试评分等级筛选为"all"
echo "4️⃣ 测试评分等级筛选为'all'（应该返回所有）..."
curl -s "http://localhost:5000/api/admin/assessments?totalScoreLevel=all&limit=2" | python3 -m json.tool | head -30
echo ""
echo ""

# 测试评分等级筛选为"good"
echo "5️⃣ 测试评分等级筛选为'good'..."
curl -s "http://localhost:5000/api/admin/assessments?totalScoreLevel=good&limit=2" | python3 -m json.tool | head -30
echo ""

echo "✅ API 测试完成"
