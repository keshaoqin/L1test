# 快速部署命令汇总

## 服务器信息

- **公网 IP**: 47.89.134.217
- **私有 IP**: 172.19.22.208
- **应用端口**: 5000

## 三种部署方式

### 方式一：PM2 部署（推荐，生产环境）

```bash
cd /workspace/projects
./deploy-with-pm2.sh
```

### 方式二：基础部署（使用 nohup）

```bash
cd /workspace/projects
./deploy.sh
```

### 方式三：快速启动（用于测试）

```bash
cd /workspace/projects
./quick-start.sh
```

## 一键部署（完整流程）

```bash
# 1. 进入项目目录
cd /workspace/projects

# 2. 使用 PM2 部署（推荐）
./deploy-with-pm2.sh

# 3. 访问网站
# 主页: http://47.89.134.217:5000
# 管理后台: http://47.89.134.217:5000/admin/login
```

## 常用管理命令

### 查看服务状态

```bash
# PM2 状态
pm2 status

# 端口监听
ss -lntp | grep 5000
```

### 查看日志

```bash
# PM2 日志
pm2 logs assessment-app

# 应用日志
tail -f /tmp/assessment-service.log
```

### 重启服务

```bash
# 使用 PM2
pm2 restart assessment-app

# 或手动重启
./deploy-with-pm2.sh
```

### 停止服务

```bash
# 使用 PM2
pm2 stop assessment-app

# 或手动停止
pkill -f "next start"
```

## 更新部署

```bash
cd /workspace/projects
git pull
pnpm install
npx next build
pm2 restart assessment-app
```

## 默认管理员账户

| 用户名 | 密码 |
|--------|------|
| admin | admin123 |
| ksq | ksq123 |

## 测试命令

```bash
# 测试初始化接口
curl http://localhost:5000/api/admin/init

# 测试登录接口
curl -X POST http://localhost:5000/api/admin/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# 测试网站访问
curl http://localhost:5000
```

## 故障排查

```bash
# 查看错误日志
pm2 logs assessment-app --err

# 检查端口占用
ss -lntp | grep 5000

# 检查进程
ps aux | grep next

# 查看完整日志
tail -100 /tmp/assessment-error.log
```

## 配置 Nginx（可选）

```bash
# 安装和配置 Nginx
sudo ./setup-nginx.sh

# 或手动配置
sudo cp nginx.conf /etc/nginx/sites-available/assessment
sudo ln -sf /etc/nginx/sites-available/assessment /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## 访问地址

- **HTTP**: http://47.89.134.217:5000
- **管理后台**: http://47.89.134.217:5000/admin/login
- **使用 Nginx**: http://47.89.134.217（端口 80）

## 防火墙配置

```bash
# 开放端口
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 5000/tcp

# 查看防火墙状态
sudo ufw status
```

## 阿里云安全组配置

在阿里云 ECS 控制台的安全组中，添加以下入站规则：

- TCP 80 - HTTP
- TCP 443 - HTTPS
- TCP 5000 - 应用端口

---

**快速参考**: 使用 `./deploy-with-pm2.sh` 一键部署！
