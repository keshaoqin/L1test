module.exports = {
  apps: [{
    name: 'assessment-app',
    script: 'npx',
    args: 'next start --port 5000',
    cwd: '/workspace/projects',
    instances: 1,
    exec_mode: 'cluster',
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DEPLOY_RUN_PORT: 5000,
      SERVER_PUBLIC_IP: '47.89.134.217',
      SERVER_PRIVATE_IP: '172.19.22.208'
    },
    error_file: '/tmp/assessment-error.log',
    out_file: '/tmp/assessment-out.log',
    log_file: '/tmp/assessment-combined.log',
    time: true,
    merge_logs: true
  }]
};
