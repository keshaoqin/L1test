#!/bin/bash

# Nginx 安装和配置脚本
# 适用于阿里云服务器

set -e

echo "=================================="
echo "Nginx 安装和配置"
echo "=================================="

# 检查是否为 root 用户
if [ "$EUID" -ne 0 ]; then
    echo "请使用 sudo 运行此脚本"
    exit 1
fi

echo ""
echo "步骤 1/3: 安装 Nginx..."
echo "=================================="
if command -v apt-get &> /dev/null; then
    apt-get update
    apt-get install -y nginx
elif command -v yum &> /dev/null; then
    yum install -y nginx
else
    echo "不支持的包管理器"
    exit 1
fi

echo ""
echo "步骤 2/3: 配置 Nginx..."
echo "=================================="
# 备份默认配置
if [ -f /etc/nginx/sites-enabled/default ]; then
    mv /etc/nginx/sites-enabled/default /etc/nginx/sites-enabled/default.backup
fi

# 复制项目配置
if [ -f /workspace/projects/nginx.conf ]; then
    cp /workspace/projects/nginx.conf /etc/nginx/sites-available/assessment
    ln -sf /etc/nginx/sites-available/assessment /etc/nginx/sites-enabled/assessment
    echo "Nginx 配置已更新"
else
    echo "警告: 未找到 nginx.conf 文件，请手动配置"
fi

echo ""
echo "步骤 3/3: 启动 Nginx..."
echo "=================================="
# 测试配置
nginx -t

# 重启 Nginx
systemctl restart nginx
systemctl enable nginx

echo ""
echo "=================================="
echo "Nginx 安装和配置完成！"
echo "=================================="
echo "Nginx 状态: systemctl status nginx"
echo "Nginx 日志: tail -f /var/log/nginx/assessment-access.log"
echo "=================================="
