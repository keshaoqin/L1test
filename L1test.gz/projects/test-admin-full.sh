#!/bin/bash

# 管理后台功能完整测试脚本

echo "🧪 测试管理后台完整功能..."
echo ""

# 测试 1: 基础列表查询
echo "1️⃣ 测试基础列表查询..."
echo "================================"
curl -s "http://localhost:5000/api/admin/assessments?limit=3" | python3 -m json.tool
echo ""
echo ""

# 测试 2: 按 ID 筛选
echo "2️⃣ 测试按 ID 筛选..."
echo "================================"
curl -s "http://localhost:5000/api/admin/assessments?id=f67595cb-9ec4-4c37-b865-576a0ab64639" | python3 -m json.tool
echo ""
echo ""

# 测试 3: 按用户名搜索
echo "3️⃣ 测试按用户名搜索..."
echo "================================"
curl -s "http://localhost:5000/api/admin/assessments?search=匿名" | python3 -m json.tool
echo ""
echo ""

# 测试 4: 按性别筛选
echo "4️⃣ 测试按性别筛选（男性）..."
echo "================================"
curl -s "http://localhost:5000/api/admin/assessments?gender=male" | python3 -m json.tool
echo ""
echo ""

# 测试 5: 按性别筛选（女性）
echo "5️⃣ 测试按性别筛选（女性）..."
echo "================================"
curl -s "http://localhost:5000/api/admin/assessments?gender=female" | python3 -m json.tool
echo ""
echo ""

# 测试 6: 按日期范围筛选
echo "6️⃣ 测试按日期范围筛选..."
echo "================================"
curl -s "http://localhost:5000/api/admin/assessments?startDate=2026-01-01&endDate=2026-02-02" | python3 -m json.tool
echo ""
echo ""

# 测试 7: 按评分等级筛选
echo "7️⃣ 测试按评分等级筛选（良好）..."
echo "================================"
curl -s "http://localhost:5000/api/admin/assessments?totalScoreLevel=good" | python3 -m json.tool
echo ""
echo ""

# 测试 8: 组合筛选（性别 + 评分等级）
echo "8️⃣ 测试组合筛选（男性 + 良好）..."
echo "================================"
curl -s "http://localhost:5000/api/admin/assessments?gender=male&totalScoreLevel=good" | python3 -m json.tool
echo ""
echo ""

# 测试 9: 获取单条评估详情
echo "9️⃣ 测试获取单条评估详情..."
echo "================================"
curl -s "http://localhost:5000/api/admin/assessments/f67595cb-9ec4-4c37-b865-576a0ab64639" | python3 -m json.tool | head -100
echo ""
echo ""

# 测试 10: 登录 API
echo "🔟 测试登录 API..."
echo "================================"
curl -s -X POST http://localhost:5000/api/admin/auth/login \
  -H "Content-Type: application/json" \
  -d '{"password":"admin123"}' | python3 -m json.tool
echo ""

echo "✅ 所有 API 测试完成"
