# 华西医院生活方式评估系统 - 产品需求文档 (PRD)

## 文档信息

| 项目 | 内容 |
|------|------|
| 文档名称 | 时悦sayIFine生活方式评估系统 PRD |
| 版本 | v1.0 |
| 创建日期 | 2025-02-01 |
| 最后更新 | 2025-02-01 |
| 文档状态 | 正式发布 |

---

## 目录

1. [项目概述](#1-项目概述)
2. [产品目标](#2-产品目标)
3. [用户画像](#3-用户画像)
4. [功能需求](#4-功能需求)
5. [题库设计](#5-题库设计)
6. [评分逻辑](#6-评分逻辑)
7. [后台管理](#7-后台管理)
8. [技术架构](#8-技术架构)
9. [数据模型](#9-数据模型)
10. [开发规范](#10-开发规范)
11. [测试标准](#11-测试标准)
12. [部署规范](#12-部署规范)

---

## 1. 项目概述

### 1.1 项目背景

时悦sayIFine生活方式评估系统是一个基于生活方式医学理论设计的在线评估工具，通过科学的问卷系统，全面评估用户的饮食、运动、睡眠等生活习惯，生成专业的评估报告，提供个性化的健康建议。

### 1.2 产品定位

- **产品类型**：在线健康评估系统
- **目标用户**：希望改善生活方式、管理体重的健康人群
- **核心价值**：科学评估、个性化建议、数据可视化
- **使用场景**：健康管理平台、个人健康管理

### 1.3 核心功能

1. **问卷系统**：全面评估用户的生活方式
2. **科学评分**：基于生活方式医学理论的多维度评分
3. **个性化报告**：生成详细的分析报告和改进建议
4. **后台管理**：数据统计、用户管理、报表分析

---

## 2. 产品目标

### 2.1 业务目标

- 提供科学、专业的生活方式评估工具
- 帮助用户了解自身生活方式的健康状况
- 提供个性化、可操作的健康建议
  
### 2.2 用户体验目标

- 简洁直观的问卷界面，降低用户填写门槛
- 清晰的报告展示，便于用户理解
- 支持移动端

### 2.3 技术目标

- 高可用性：系统稳定性达到 99.9%
- 高性能：页面加载时间 < 2秒
- 数据安全：用户数据加密存储
- 可扩展性：支持未来功能扩展

---

## 3. 用户画像

### 3.1 主要用户群体

#### 用户 
- **年龄**：30-50岁
- **性别**：男女不限
- **特征**：关注健康，希望通过科学方法改善生活方式
- **需求**：了解自身健康状况，获得专业建议

### 3.2 用户痛点

1. 不知道如何科学评估自己的生活方式
2. 网上的健康建议缺乏个性化，难以执行
3. 缺乏专业、权威的评估工具
4. 需要可视化的报告和数据分析

---

## 4. 功能需求

### 4.1 前端功能

#### 4.1.1 问卷系统

**功能描述**：
- 分步骤问卷系统，共6个步骤
- 每个步骤聚焦一个评估维度
- 实时错误提示和验证
- 支持进度显示

**步骤划分**：
1. **基本信息**（步骤 1）
   - 性别、年龄
   - 身高、体重（可选）
   - 腰围（可选）
   - 血压脉搏（可选）
   - 减重决心

2. **既往史**（步骤 2）
   - 是否有相关疾病史
   - 多选形式

3. **饮食评估**（步骤 3）
   - 食物选择与搭配
   - 蔬果摄入
   - 油脂与调味
   - 进餐习惯
   - 烹饪方式
   - 代餐使用
   - 饮食偏好

4. **运动评估**（步骤 4，非必填）
   - 每日步数
   - 有氧运动
   - 抗阻运动
   - 柔韧性训练

5. **睡眠评估**（步骤 5）
   - 睡眠时长
   - 入睡时间
   - 睡眠质量
   - 日间精神状态

6. **吸烟饮酒**（步骤 6）
   - 吸烟情况
   - 饮酒情况

**交互设计**：
- 每个步骤完成后自动跳转到下一步
- 支持返回上一步修改
- 提交前检查必填项
- 未完成项高亮显示

#### 4.1.2 结果展示

**功能描述**：
- 显示综合评分（0-100分）
- 评分等级标准（优秀、良好、一般、较差、差）
- 各维度得分雷达图
- 总体评价
- 各维度详细分析
- 个性化建议
- 行动计划

**展示内容**：
1. **总分展示**
   - 大字号显示总分
   - 评分等级标签
   - 鼓励性评语

2. **评分等级标准**
   - 5个等级：优秀（85-100分）、良好（70-84分）、一般（55-69分）、较差（40-54分）、差（<40分）
   - 当前等级高亮显示

3. **各维度得分**
   - 雷达图可视化
   - 5个维度得分卡片：饮食（40分）、运动（25分）、睡眠（15分）、基础健康（10分）、风险控制（10分）

4. **总体评价**
   - 基于总分的综合评价
   - 各维度详细分析

5. **健康风险**
   - 基于评估结果的健康风险提示
   - 需要重点关注的问题

6. **个性化建议**
   - 饮食建议
   - 运动建议
   - 睡眠建议
   - 健康监测建议
   - 心理支持建议


**导出功能**：
- 支持将报告导出为图片
- 导出内容与页面展示完全一致
- 支持下载和分享（移动端）

#### 4.1.3 用户操作

**功能描述**：
- 提交评估
- 重新测评
- 导出报告

### 4.2 后台管理功能

#### 4.2.1 仪表盘

**功能描述**：
- 显示核心统计数据
- 数据可视化展示

**统计指标**：
- 总评估数
- 今日评估数
- 本周评估数
- 平均总分

**数据可视化**：
- 评分等级分布（柱状图）
- 性别分布（饼图）
- 各维度平均分（雷达图）

#### 4.2.2 评估管理

**功能描述**：
- 评估记录列表
- 筛选和搜索
- 详情查看
- 删除记录

**列表功能**：
- 分页展示（默认每页20条）
- 排序（按时间倒序）
- 筛选（性别、评分等级、时间范围）
- 搜索（按姓名）

**详情功能**：
- 显示完整的评估数据
- 显示评估结果
- 支持编辑姓名和BMI
- 支持删除记录

#### 4.2.3 用户认证

**功能描述**：
- 管理员登录
- 会话管理
- 权限控制

**登录流程**：
1. 输入用户名和密码
2. 后端验证
3. 生成会话令牌
4. 前端存储令牌
5. 访问受保护资源时携带令牌

**安全要求**：
- 密码使用 bcrypt 加密存储
- 令牌有效期24小时
- 登录失败3次后锁定账户5分钟

---

## 5. 题库设计

### 5.1 题库结构

问卷分为6个步骤，每个步骤对应一个评估维度：

```typescript
// 评估请求结构
interface AssessmentRequest {
  // 一、一般信息
  generalInfo: {
    name?: string;
    gender: 'male' | 'female';
    age: number;
    smoking: {
      isSmoking: boolean;
      cigarettesPerDay?: number;
    };
    drinking: {
      isDrinking: boolean;
      gramsOfAlcoholPerDay?: number;
    };
  };

  // 二、身体情况
  enrollmentInfo: {
    height?: number; // cm
    weight?: number; // kg
    waistline?: number; // cm
    systolicBloodPressure?: number; // mmHg
    diastolicBloodPressure?: number; // mmHg
    pulse?: number; // 次/分
    bloodPressurePulseUnknown: boolean;
    weightLossDetermination: 'low' | 'medium' | 'high' | 'veryHigh';
  };

  // 三、既往史
  medicalHistory: {
    noDiseases: boolean;
    hyperlipidemia: boolean;
    fattyLiver: boolean;
    hypertension: boolean;
    coronaryHeartDisease: boolean;
    heartFailure: boolean;
    highBloodSugar: boolean;
    diabetes: boolean;
    hyperuricemia: boolean;
    gout: boolean;
    pancreatitis: boolean;
    thyroidRelated: boolean;
    others?: string;
  };

  // 四、饮食评估
  dietAssessment: {
    foodSelection: {
      stapleFood: 'refined' | 'mixed';
      proteinSource: 'balanced' | 'simple' | 'insufficient';
      processedMeatPreference: boolean;
    };
    fruitVegetableIntake: {
      vegetable300gOrMore: boolean;
      darkVegetableRatio: number;
      fruit200gOrMore: boolean;
      juiceInsteadOfFruit: boolean;
      cannedPickledFruitsAndVegetables: boolean;
    };
    oilAndSeasoning: {
      cookingOilType: 'vegetable' | 'animal' | 'mixed';
      oilIntakeExceeded: boolean;
      saltIntakeExceeded: boolean;
      sugarIntakeExceeded: boolean;
    };
    eatingSpeed: 'veryFast' | 'fast' | 'normal' | 'slow';
    mealRegularity: {
      breakfastFrequency: 'daily' | '5-6days' | '≤4days';
      dinnerTime: '≤19:00' | '19:00-21:00' | '≥21:00';
      midnightSnackFrequency: 'none' | '1-2times' | '≥3times';
    };
    eatingOut: {
      frequency: '0times' | '1-3times' | '4-6times' | 'daily';
      mainTypes: string[];
    };
    cookingMethodPreference: 'frying' | 'stirFrying' | 'steamingBoiling' | 'coldDish';
    mealReplacement: {
      isUsing: boolean;
      type?: 'proteinShake' | 'mealBar' | 'porridge' | 'other';
      productName?: string;
      frequency?: string;
    };
    foodAllergyOrTaboo: {
      hasTaboo: boolean;
      specificFoods?: string;
    };
    dailyWaterIntake: '<1L' | '1-2L' | '>2L' | 'sugaryDrinks';
    dietaryPreferences: string[];
    dietaryPreferencesNone: boolean;
  };

  // 五、运动评估（非必填）
  exerciseAssessment: {
    dailySteps: '<3000' | '3000-6000' | '6000-9000' | '>9000';
    aerobicExercise: {
      frequency?: number;
      duration?: number;
    };
    resistanceExercise: {
      frequency?: number;
      duration?: number;
    };
    flexibilityTraining: {
      frequency?: number;
      duration?: number;
    };
  };

  // 六、睡眠评估
  sleepAssessment: {
    sleepHours: '<5hours' | '5-7hours' | '7-9hours' | '>9hours';
    bedtime: string;
    snoring: boolean;
    sleepAidOrCPAP: boolean;
    sleepAidOrCPAPDetails?: string;
    daytimeEnergy: 'energetic' | 'tired';
  };
}
```

### 5.2 题目设计原则

1. **科学性**：基于生活方式医学的循证依据
2. **简洁性**：问题简洁明了，易于理解
3. **可操作性**：答案选项明确，便于用户选择
4. **全面性**：覆盖生活方式的各个方面
5. **个性化**：根据用户回答生成个性化建议

### 5.3 题目示例

题目参考：https://4pnwsd4yh7.coze.site/

---

## 6. 评分逻辑

### 6.1 评分维度

总分100分，分为5个维度：

| 维度 | 满分 | 占比 | 评估内容 |
|------|------|------|----------|
| 饮食习惯 | 40分 | 40% | 食物选择、搭配、进餐习惯、烹饪方式 |
| 运动习惯 | 25分 | 25% | 每日步数、运动量、运动类型 |
| 睡眠质量 | 15分 | 15% | 睡眠时长、规律性、质量 |
| 基础健康 | 10分 | 10% | BMI、腰围、血压 |
| 风险控制 | 10分 | 10% | 吸烟、饮酒 |

### 6.2 饮食习惯评分（40分）

#### 6.2.1 食物选择与搭配（16分）

**主食类型（3分）**
- 粗细搭配：3分
- 精制米面：0分

**蛋白质来源（3分）**
- 均衡（多种来源）：3分
- 较单一：1分
- 不足：0分

**加工肉偏好（2分）**
- 不偏好：2分
- 偏好：0分

**蔬果摄入（5分）**
- 蔬菜≥300g：2分
- 深色蔬菜占比>50%：1分
- 水果≥200g：1分
- 不用果汁替代、不吃腌制果蔬：1分

**油脂与调味（3分）**
- 植物油：1分
- 油、盐、糖摄入均未超标：2分
- 1-2项超标：1分
- 全部超标：0分

#### 6.2.2 进餐习惯（13分）

**进餐速度（3分）**
- 正常：3分
- 慢：2分
- 快：1分
- 很快：0分

**三餐规律性（4分）**
- 每天吃早餐 + 晚餐≤19:00 + 不吃夜宵：4分
- 每天吃早餐 + 晚餐≤21:00 + 夜宵≤2次：3分
- 吃早餐5-6天 + 晚餐≤21:00：2分
- 其他：0分

**饮水量（3分）**
- >2L：3分
- 1-2L：2分
- <1L或含糖饮料：0分

**外食频率（3分）**
- 0次或1-3次/周：3分
- 4-6次/周或每天：0分

#### 6.2.3 烹饪方式（5分）

- 蒸煮：5分
- 凉拌：4分
- 炒菜：3分
- 油炸：2分

#### 6.2.4 其他（6 分）

**代餐使用（2分）**
- 不使用：2分
- 使用：0分

**饮食禁忌（2分）**
- 无禁忌：2分
- 有禁忌：0分

**不良饮食偏好扣分（2 分）**
- 暴饮暴食：-2分
- 饮食不规律：-2分
- 偏好甜食：-1分
- 偏好油炸食物：-1分
- 无以上不良习惯 +2 分

### 6.3 运动习惯评分（25分）

#### 6.3.1 每日步数（10分）

| 步数 | 得分 |
|------|------|
| >9000 | 10分 |
| 6000-9000 | 8分 |
| 3000-6000 | 5分 |
| <3000 | 2分 |

#### 6.3.2 运动量（15分）

计算公式：
```
总运动时间 = 有氧运动频率 × 时长 + 抗阻运动频率 × 时长 + 柔韧性训练频率 × 时长
```

| 总运动时间 | 得分 |
|-----------|------|
| ≥150分钟 | 15分 |
| ≥120分钟 | 12分 |
| ≥90分钟 | 9分 |
| ≥60分钟 | 6分 |
| ≥30分钟 | 3分 |
| <30分钟 | 0分 |

### 6.4 睡眠质量评分（15分）

#### 6.4.1 睡眠时长（10分）

| 时长 | 得分 | 说明 |
|------|------|------|
| 7-9小时 | 10分 | 理想时长 |
| >9小时 | 6分 | 睡眠过长 |
| 5-7小时 | 5分 | 睡眠略不足 |
| <5小时 | 2分 | 睡眠严重不足 |

#### 6.4.2 规律性（3分）

| 入睡时间 | 得分 |
|---------|------|
| 22:00-23:00 | 3分 |
| 21:00-24:00 | 2分 |
| 0:00-2:00 | 1分 |
| 其他 | 0分 |

#### 6.4.3 睡眠质量（2分）

| 情况 | 得分 |
|------|------|
| 不打鼾 + 不使用助眠设备 + 日间精力充沛 | 2分 |
| 打鼾 + 不使用助眠设备 | 1分 |
| 其他 | 0分 |

### 6.5 基础健康评分（10分）

#### 6.5.1 BMI评分（5分）

| BMI | 分类 | 得分 |
|-----|------|------|
| 18.5-23.9 | 正常 | 5分 |
| 24.0-27.9 | 超重 | 3分 |
| ≥28.0 | 肥胖 | 0分 |
| <18.5 | 偏瘦 | 4分 |

#### 6.5.2 腰围评分（2.5分）

**男性**
- <85cm：2.5分（正常）
- 85-90cm：1.5分（高风险）
- ≥90cm：0分（极高风险）

**女性**
- <80cm：2.5分（正常）
- 80-85cm：1.5分（高风险）
- ≥85cm：0分（极高风险）

#### 6.5.3 血压评分（2.5分）

| 收缩压 | 舒张压 | 得分 |
|--------|--------|------|
| <120 | <80 | 2.5分 |
| 120-139 | 80-89 | 2分 |
| 140-159 | 90-99 | 1分 |
| ≥160 | ≥100 | 0.5分 |

**说明**：如果所有数据都没有，给予中性分5分。

### 6.6 风险控制评分（10分）

#### 6.6.1 吸烟评估（5分）

**不吸烟**：5分

**吸烟**
- <10支/天：1分
- ≥10支/天：0分

#### 6.6.2 饮酒评估（5分）

**不喝酒**：5分

**喝酒**（根据酒精摄入量）
- <20g/天：3分
- 20-50g/天：1分
- >50g/天：0分

**酒精摄入量计算**：
```
酒精摄入量（g）= 饮酒量（ml） × 酒精度（%） × 0.8
```

### 6.7 总分等级

| 总分 | 等级 | 说明 |
|------|------|------|
| 85-100 | 优秀 | 生活方式非常健康 |
| 70-84 | 良好 | 生活方式较健康 |
| 55-69 | 一般 | 生活方式一般，需要改进 |
| 40-54 | 较差 | 生活方式较差，需要立即改善 |
| <40 | 差 | 生活方式存在严重问题 |

---

## 7. 后台管理

### 7.1 仪表盘

#### 7.1.1 统计指标

- **总评估数**：系统累计评估次数
- **今日评估数**：当天新增评估数
- **本周评估数**：最近7天新增评估数
- **平均总分**：所有评估的平均总分

#### 7.1.2 数据可视化

**评分等级分布**
- 柱状图展示5个等级的评估数量
- 优秀（绿色）、良好（蓝色）、一般（黄色）、较差（橙色）、差（红色）

**性别分布**
- 饼图展示男女比例
- 男性（蓝色）、女性（粉色）

**各维度平均分**
- 雷达图展示5个维度的平均得分
- 饮食（绿色）、运动（橙色）、睡眠（紫色）、基础健康（红色）、风险控制（蓝色）

### 7.2 评估管理

#### 7.2.1 列表功能

**展示字段**
- ID
- 姓名
- 性别
- 年龄
- 总分
- 评分等级
- BMI
- 评估时间

**排序功能**
- 默认按评估时间倒序

**筛选功能**
- 性别：全部、男性、女性
- 评分等级：全部、优秀、良好、一般、较差、差
- 时间范围：开始日期、结束日期

**搜索功能**
- 按姓名搜索（模糊匹配）

**分页功能**
- 默认每页20条
- 支持调整每页数量（10、20、50、100）

#### 7.2.2 详情功能

**展示内容**
1. 基本信息
   - 姓名、性别、年龄
   - 身高、体重、BMI
   - 腰围
   - 血压脉搏

2. 评估结果
   - 总分和等级
   - 各维度得分
   - 总体评价
   - 各维度分析
   - 健康风险
   - 个性化建议
   - 行动计划

3. 原始问卷数据
   - 展示完整的问卷答案

**编辑功能**
- 支持编辑姓名
- 支持编辑BMI

**删除功能**
- 删除评估记录（需确认）

### 7.3 用户认证

#### 7.3.1 登录流程

1. 用户访问后台管理页面
2. 输入用户名和密码
3. 点击登录按钮
4. 后端验证用户名和密码
5. 验证成功后生成JWT令牌
6. 前端存储令牌（localStorage）
7. 跳转到仪表盘页面

#### 7.3.2 会话管理

- 令牌有效期：24小时
- 令牌刷新：访问受保护资源时自动验证
- 令牌过期：跳转到登录页面

#### 7.3.3 权限控制

- 所有后台管理接口都需要认证
- 前端在请求头中携带令牌
- 后端验证令牌有效性

#### 7.3.4 安全措施

- 密码使用bcrypt加密存储（10轮加密）
- 登录失败3次后锁定账户5分钟
- 令牌使用HS256算法签名
- 令牌存储在localStorage，不使用Cookie

---

## 8. 技术架构

### 8.1 技术栈

#### 前端技术栈

| 技术 | 版本 | 说明 |
|------|------|------|
| Next.js | 16 | React框架，App Router |
| React | 19 | UI框架 |
| TypeScript | 5 | 类型安全 |
| Tailwind CSS | 4 | CSS框架 |
| shadcn/ui | - | UI组件库 |
| Recharts | - | 图表库 |
| html2canvas | - | 截图库 |

#### 后端技术栈

| 技术 | 版本 | 说明 |
|------|------|------|
| Next.js API Routes | - | 后端API |
| Drizzle ORM | - | 数据库ORM |
| PostgreSQL | - | 关系型数据库 |
| bcryptjs | - | 密码加密 |
| jsonwebtoken | - | JWT令牌 |

#### 开发工具

| 工具 | 版本 | 说明 |
|------|------|------|
| pnpm | - | 包管理器 |
| ESLint | - | 代码规范 |
| Prettier | - | 代码格式化 |
| TypeScript | 5 | 类型检查 |

### 8.2 项目结构

```
.
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── api/               # API路由
│   │   │   ├── admin/        # 后台管理API
│   │   │   │   ├── auth/
│   │   │   │   │   └── login/route.ts
│   │   │   │   ├── dashboard/route.ts
│   │   │   │   └── assessments/
│   │   │   │       ├── route.ts
│   │   │   │       └── [id]/route.ts
│   │   │   └── assess/route.ts  # 评估提交API
│   │   ├── assessment/        # 评估页面
│   │   │   └── page.tsx
│   │   ├── admin/             # 后台管理页面
│   │   │   └── assessments/
│   │   │       └── [id]/page.tsx
│   │   ├── globals.css        # 全局样式
│   │   ├── layout.tsx         # 根布局
│   │   └── page.tsx           # 首页
│   ├── components/            # React组件
│   │   └── ui/               # shadcn/ui组件
│   ├── hooks/                # 自定义Hooks
│   │   └── use-mobile.ts
│   ├── lib/                  # 工具库
│   │   ├── scoring.ts        # 评分逻辑
│   │   └── utils.ts          # 通用工具函数
│   ├── storage/              # 数据存储
│   │   └── database/
│   │       ├── index.ts      # 数据库初始化
│   │       ├── assessmentManager.ts
│   │       └── shared/
│   │           ├── schema.ts  # 数据库Schema
│   │           └── relations.ts
│   └── types/                # 类型定义
│       └── assessment.ts
├── .coze                     # Coze配置文件
├── .cozeproj                 # Coze项目配置
├── .eslintrc.json            # ESLint配置
├── next.config.ts            # Next.js配置
├── package.json              # 依赖配置
├── tsconfig.json             # TypeScript配置
└── PRD.md                    # 本文档
```

### 8.3 架构设计

#### 8.3.1 前端架构

**组件化设计**
- 使用React函数组件
- 使用shadcn/ui组件库
- 自定义业务组件

**状态管理**
- 使用React Hooks（useState、useEffect）
- 表单状态管理
- 加载状态管理

**路由设计**
- 使用Next.js App Router
- 评估页面：`/assessment`
- 后台管理：`/admin/assessments`
- API路由：`/api/*`

#### 8.3.2 后端架构

**API设计**
- RESTful API
- 统一返回格式
- 错误处理

**数据库设计**
- 使用Drizzle ORM
- PostgreSQL数据库
- JSON字段存储复杂数据

**认证设计**
- JWT令牌认证
- 中间件验证
- 会话管理

### 8.4 数据流

#### 8.4.1 评估流程

```
用户填写问卷
    ↓
前端验证
    ↓
提交到后端API
    ↓
后端评分计算
    ↓
生成评估报告
    ↓
存储到数据库
    ↓
返回结果给前端
    ↓
前端展示报告
```

#### 8.4.2 后台管理流程

```
管理员登录
    ↓
验证用户名密码
    ↓
生成JWT令牌
    ↓
访问仪表盘
    ↓
获取统计数据
    ↓
展示数据可视化
```

---

## 9. 数据模型

### 9.1 数据库Schema

```typescript
// 评估记录表
export const assessments = pgTable("assessments", {
  id: varchar("id", { length: 36 })
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  
  // 用户基本信息
  name: varchar("name", { length: 128 }),
  gender: varchar("gender", { length: 20 }).notNull(),
  age: integer("age").notNull(),
  
  // 存储完整的评估请求和结果（JSON格式）
  requestData: jsonb("request_data").notNull(),
  responseData: jsonb("response_data").notNull(),
  
  // 提取常用字段方便查询和统计
  totalScore: integer("total_score").notNull(),
  bmi: varchar("bmi", { length: 20 }),
  totalScoreLevel: varchar("total_score_level", { length: 20 }).notNull(),
  bmiCategory: varchar("bmi_category", { length: 20 }),
  
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }),
});
```

### 9.2 索引设计

```typescript
// 创建索引
- createdAtIdx: 按创建时间索引
- totalScoreIdx: 按总分索引
- totalScoreLevelIdx: 按评分等级索引
- genderIdx: 按性别索引
```

### 9.3 数据存储策略

#### 9.3.1 JSON字段存储

**requestData字段**
- 存储完整的问卷数据
- 使用AssessmentRequest类型
- 便于回溯和修改

**responseData字段**
- 存储完整的评估结果
- 使用AssessmentResult类型
- 包含分析、建议、行动计划

#### 9.3.2 提取字段存储

为了提高查询效率，从JSON字段中提取常用字段：

- **totalScore**：总分
- **bmi**：BMI值
- **totalScoreLevel**：评分等级
- **bmiCategory**：BMI分类

---

## 10. 开发规范

### 10.1 代码规范

#### 10.1.1 TypeScript规范

**命名规范**
- 变量：camelCase
- 常量：UPPER_SNAKE_CASE
- 类：PascalCase
- 接口/类型：PascalCase
- 文件名：kebab-case 或 PascalCase（组件）

**类型定义**
- 使用interface定义对象类型
- 使用type定义联合类型
- 导出类型时使用export type

**类型注解**
- 函数参数必须有类型
- 函数返回值必须有类型
- 避免使用any，使用unknown代替

#### 10.1.2 React规范

**组件规范**
- 使用函数组件
- 使用TypeScript定义Props类型
- 使用解构赋值获取props

**Hooks规范**
- 自定义Hooks以use开头
- Hooks必须以use开头调用
- 遵循Hooks规则（只能在顶层调用）

**状态管理**
- 使用useState管理组件状态
- 使用useEffect处理副作用
- 使用useCallback优化性能
- 使用useMemo缓存计算结果

#### 10.1.3 样式规范

**Tailwind CSS规范**
- 优先使用Tailwind类名
- 避免内联样式
- 使用响应式前缀（sm:, md:, lg:）

**CSS变量**
- 定义在globals.css中
- 使用语义化命名
- 避免使用oklch颜色（使用hex）

#### 10.1.4 API规范

**RESTful API**
- 使用HTTP动词（GET、POST、PUT、DELETE）
- 资源路径使用名词复数
- 使用状态码表示结果

**返回格式**
```typescript
// 成功
{
  data: any,
  message?: string
}

// 错误
{
  error: string,
  message?: string
}
```

### 10.2 Git规范

#### 10.2.1 分支管理

- **main**：主分支，生产环境
- **develop**：开发分支，测试环境
- **feature/***：功能分支
- **bugfix/***：修复分支

#### 10.2.2 提交规范

使用Conventional Commits规范：

```
<type>(<scope>): <subject>

<body>

<footer>
```

**类型**
- feat：新功能
- fix：修复bug
- docs：文档更新
- style：代码格式调整
- refactor：重构
- test：测试
- chore：构建/工具

**示例**
```
feat(assessment): 添加饮食评估模块

实现饮食评估的6个子维度评分逻辑

Closes #123
```

### 10.3 文档规范

#### 10.3.1 代码注释

**文件注释**
```typescript
/**
 * 华西医院生活方式评估 - 评分系统
 * 基于生活方式医学的循证依据设计
 */
export class AssessmentScorer {
  // ...
}
```

**函数注释**
```typescript
/**
 * 计算BMI
 * @returns BMI值，如果缺少数据则返回null
 */
private calculateBMI(): number | null {
  // ...
}
```

**复杂逻辑注释**
```typescript
// 计算目标热量（基于基础代谢率和活动水平）
// Mifflin-St Jeor公式计算基础代谢率
let bmr: number;
if (gender === 'male') {
  bmr = 10 * weight + 6.25 * height - 5 * age + 5;
} else {
  bmr = 10 * weight + 6.25 * height - 5 * age - 161;
}
```

#### 10.3.2 README文档

每个模块/组件都应该有README文档，包含：
- 功能描述
- 使用方法
- 参数说明
- 示例代码

---

## 11. 测试标准

### 11.1 单元测试

**测试范围**
- 评分逻辑（src/lib/scoring.ts）
- 工具函数（src/lib/utils.ts）
- 数据库操作（src/storage/database/assessmentManager.ts）

**测试框架**
- Jest
- Testing Library

**测试覆盖率**
- 核心逻辑：≥90%
- 工具函数：≥80%
- 组件：≥70%

### 11.2 集成测试

**测试范围**
- API接口
- 数据库操作
- 评分流程

**测试场景**
1. 评估提交流程
2. 评分计算准确性
3. 数据库存储和查询
4. 后台管理功能

### 11.3 端到端测试

**测试范围**
- 用户填写问卷流程
- 结果展示功能
- 后台管理流程

**测试工具**
- Playwright
- Cypress

### 11.4 性能测试

**测试指标**
- 页面加载时间：<2秒
- API响应时间：<500ms
- 数据库查询时间：<100ms

**测试工具**
- Lighthouse
- WebPageTest

---

## 12. 部署规范

### 12.1 环境配置

#### 12.1.1 开发环境

```bash
# 安装依赖
pnpm install

# 启动开发服务器
pnpm dev

# 运行构建
pnpm build

# 启动生产服务器
pnpm start
```

#### 12.1.2 生产环境

```bash
# 设置环境变量
NODE_ENV=production
DATABASE_URL=postgresql://...
JWT_SECRET=your-secret-key

# 构建生产版本
pnpm build

# 启动生产服务器
pnpm start
```

### 12.2 环境变量

```env
# 数据库配置
DATABASE_URL=postgresql://user:password@host:port/database

# JWT配置
JWT_SECRET=your-secret-key
JWT_EXPIRES_IN=24h

# 应用配置
NEXT_PUBLIC_API_URL=https://api.example.com
NODE_ENV=production
```

### 12.3 部署流程

#### 12.3.1 部署前检查

- [ ] 运行测试：`pnpm test`
- [ ] 运行构建：`pnpm build`
- [ ] 检查类型：`npx tsc --noEmit`
- [ ] 检查代码规范：`pnpm lint`

#### 12.3.2 部署步骤

1. 拉取最新代码
2. 安装依赖：`pnpm install`
3. 构建生产版本：`pnpm build`
4. 运行数据库迁移
5. 重启应用服务
6. 健康检查

#### 12.3.3 回滚策略

- 保留最近3个版本的备份
- 部署失败时自动回滚
- 监控错误日志，及时回滚

### 12.4 监控和日志

#### 12.4.1 日志规范

**日志级别**
- ERROR：错误
- WARN：警告
- INFO：信息
- DEBUG：调试

**日志格式**
```typescript
console.error('[ERROR] 计算BMI失败:', error);
console.log('[INFO] 评估提交成功，ID:', assessmentId);
console.warn('[WARN] 缺少身高数据');
```

#### 12.4.2 监控指标

- 应用性能（APM）
- 错误率
- API响应时间
- 数据库连接数
- 内存使用率

---

## 附录

### A. 评分计算示例

#### 示例1：健康生活方式

**用户数据**：
- 主食：粗细搭配（3分）
- 蛋白质：均衡（3分）
- 蔬菜≥300g（1分）
- 水果≥200g（1分）
- 进餐速度：正常（3分）
- 每天吃早餐 + 晚餐≤19:00 + 不吃夜宵（4分）
- 饮水>2L（2分）
- 蒸煮（7分）
- 不使用代餐（2分）
- 无饮食禁忌（2分）

**饮食得分**：3 + 3 + 1 + 1 + 3 + 4 + 2 + 7 + 2 + 2 = 28分（满分40分）

- 步数>9000（10分）
- 有氧运动150分钟/周（15分）

**运动得分**：10 + 15 = 25分（满分25分）

- 睡眠7-9小时（10分）
- 入睡时间22:00（3分）
- 不打鼾 + 精力充沛（2分）

**睡眠得分**：10 + 3 + 2 = 15分（满分15分）

- BMI 22（5分）
- 腰围80cm（2.5分）
- 血压120/80（2.5分）

**基础健康得分**：5 + 2.5 + 2.5 = 10分（满分10分）

- 不吸烟（5分）
- 不喝酒（5分）

**风险控制得分**：5 + 5 = 10分（满分10分）

**总分**：28 + 25 + 15 + 10 + 10 = 88分（优秀）

#### 示例2：不健康生活方式

**用户数据**：
- 主食：精制米面（0分）
- 蛋白质：较单一（1分）
- 蔬菜<300g（0分）
- 水果<200g（0分）
- 进餐速度：很快（0分）
- 不吃早餐（0分）
- 饮水<1L（0分）
- 油炸（2分）
- 使用代餐（0分）
- 有饮食禁忌（0分）
- 暴饮暴食（-2分）

**饮食得分**：0 + 1 + 0 + 0 + 0 + 0 + 0 + 2 + 0 + 0 - 2 = 1分（满分40分）

- 步数<3000（2分）
- 无运动（0分）

**运动得分**：2 + 0 = 2分（满分25分）

- 睡眠<5小时（2分）
- 入睡时间1:00（0分）
- 打鼾（1分）

**睡眠得分**：2 + 0 + 1 = 3分（满分15分）

- BMI 28（0分）
- 腰围95cm（0分）
- 血压140/90（1分）

**基础健康得分**：0 + 0 + 1 = 1分（满分10分）

- 吸烟≥10支/天（0分）
- 喝酒>50g/天（0分）

**风险控制得分**：0 + 0 = 0分（满分10分）

**总分**：1 + 2 + 3 + 1 + 0 = 7分（差）

### B. API接口文档

#### B.1 评估提交接口

**请求**
```
POST /api/assess
Content-Type: application/json

{
  "generalInfo": {
    "gender": "male",
    "age": 30,
    "smoking": {
      "isSmoking": false
    },
    "drinking": {
      "isDrinking": false
    }
  },
  "enrollmentInfo": {
    "height": 175,
    "weight": 70,
    "weightLossDetermination": "high"
  },
  "medicalHistory": {
    "noDiseases": true
  },
  "dietAssessment": { ... },
  "exerciseAssessment": { ... },
  "sleepAssessment": { ... }
}
```

**响应**
```json
{
  "data": {
    "totalScore": 88,
    "totalScoreLevel": "excellent",
    "dimensionScores": {
      "diet": 28,
      "exercise": 25,
      "sleep": 15,
      "basicHealth": 10,
      "riskFactors": 10
    },
    "bmi": 22.9,
    "bmiCategory": "normal",
    "waistlineCategory": "normal",
    "analysis": { ... },
    "recommendations": { ... },
    "actionPlan": { ... }
  }
}
```

#### B.2 仪表盘统计接口

**请求**
```
GET /api/admin/dashboard
Authorization: Bearer <token>
```

**响应**
```json
{
  "data": {
    "totalAssessments": 1000,
    "todayCount": 50,
    "weekCount": 300,
    "averageTotalScore": 72.5,
    "scoreDistribution": {
      "excellent": 200,
      "good": 300,
      "average": 250,
      "poor": 150,
      "veryPoor": 100
    },
    "genderDistribution": {
      "male": 550,
      "female": 450
    },
    "dimensionAverages": {
      "diet": 28.5,
      "exercise": 18.2,
      "sleep": 11.3,
      "basicHealth": 7.8,
      "riskFactors": 8.5
    }
  }
}
```

#### B.3 评估列表接口

**请求**
```
GET /api/admin/assessments?skip=0&limit=20&gender=male&totalScoreLevel=excellent
Authorization: Bearer <token>
```

**响应**
```json
{
  "data": [
    {
      "id": "uuid",
      "name": "张三",
      "gender": "male",
      "age": 30,
      "totalScore": 88,
      "totalScoreLevel": "excellent",
      "bmi": "22.9",
      "createdAt": "2025-01-15T10:00:00Z"
    }
  ],
  "total": 100
}
```

### C. 常见问题

#### Q1: 为什么运动评估是非必填的？

**A**: 考虑到部分用户可能因为身体原因无法进行运动，或者刚开始建立运动习惯，因此将运动评估设为非必填。如果用户不填写运动评估，运动维度得分为0分，但不影响其他维度的评分。

#### Q2: 如何处理用户不知道的血压数据？

**A**: 系统提供"不知道血压与脉搏数据"的选项。如果用户勾选此选项，血压维度不参与评分，基础健康得分会根据其他数据计算。

#### Q3: 如果用户所有数据都不提供，如何评分？

**A**: 系统会给予中性分，不会因为数据缺失而评分为0。基础健康维度会给予5分的中性分，其他维度根据实际情况评分。

#### Q4: 评分标准是如何制定的？

**A**: 评分标准基于生活方式医学的循证依据，参考了世界卫生组织（WHO）、美国心脏协会（AHA）等权威机构的推荐，并结合华西医院临床经验制定。

#### Q5: 如何保证评分的准确性？

**A**: 
1. 评分逻辑经过多轮专家评审
2. 使用单元测试验证评分逻辑
3. 定期收集用户反馈，优化评分标准
4. 与临床数据对比，验证评分有效性

---

## 变更历史

| 版本 | 日期 | 变更内容 | 作者 |
|------|------|----------|------|
| v1.0 | 2025-02-01 | 初始版本 | AI Assistant |

---

## 联系方式

如有疑问或建议，请联系：
- 项目负责人：[负责人姓名]
- 技术支持：[技术支持邮箱]
- 项目地址：[项目地址]

---

**文档结束**
