# 阿里云服务器部署指南

## 服务器信息

- **公网 IP**: 47.89.134.217
- **私有 IP**: 172.19.22.208
- **操作系统**: Ubuntu 20.04 / 22.04 (或其他 Linux 发行版)
- **Node.js 版本**: 24.x

## 部署前置要求

### 1. 系统要求

```bash
# 更新系统
sudo apt-get update && sudo apt-get upgrade -y

# 安装基础工具
sudo apt-get install -y curl git vim wget
```

### 2. 安装 Node.js 24

```bash
# 使用 nvm 安装 Node.js 24
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
source ~/.bashrc
nvm install 24
nvm use 24
nvm alias default 24

# 验证安装
node --version
npm --version
```

### 3. 安装 pnpm

```bash
npm install -g pnpm

# 验证安装
pnpm --version
```

### 4. 安装 PM2（推荐用于生产环境）

```bash
npm install -g pm2

# 验证安装
pm2 --version
```

### 5. 安装 Nginx（可选，用于反向代理）

```bash
sudo apt-get install -y nginx

# 验证安装
nginx -v
```

### 6. 开放防火墙端口

```bash
# 如果使用 ufw
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 5000/tcp

# 如果使用 iptables（阿里云 ECS 默认）
sudo iptables -A INPUT -p tcp --dport 80 -j ACCEPT
sudo iptables -A INPUT -p tcp --dport 443 -j ACCEPT
sudo iptables -A INPUT -p tcp --dport 5000 -j ACCEPT
sudo service iptables save
```

**重要**：在阿里云 ECS 控制台的安全组中，确保开放以下端口：
- TCP 80（HTTP）
- TCP 443（HTTPS，如果需要）
- TCP 5000（应用端口）

## 部署方式选择

项目提供了两种部署方式：

### 方式一：使用部署脚本（推荐）

```bash
# 1. 上传项目代码到服务器
cd /workspace/projects

# 2. 赋予部署脚本执行权限
chmod +x deploy-with-pm2.sh

# 3. 执行部署脚本
./deploy-with-pm2.sh
```

### 方式二：手动部署

```bash
# 1. 安装依赖
pnpm install

# 2. 构建项目
npx next build

# 3. 启动服务
npx next start --port 5000
```

## 详细部署步骤

### 步骤 1：上传项目代码

#### 使用 git（推荐）

```bash
cd /workspace/projects
git clone <你的仓库地址>
cd <项目目录>
```

#### 使用 scp 上传

```bash
# 在本地执行
scp -r <项目目录> root@47.89.134.217:/workspace/projects/
```

#### 使用 rsync 上传

```bash
# 在本地执行
rsync -avz --progress <项目目录>/ root@47.89.134.217:/workspace/projects/
```

### 步骤 2：配置环境变量

环境变量已预配置在 `.env.production` 文件中，无需额外配置。

```bash
# 查看环境变量配置
cat .env.production
```

### 步骤 3：安装依赖

```bash
pnpm install
```

### 步骤 4：构建项目

```bash
npx next build
```

### 步骤 5：启动服务

#### 使用 PM2（推荐）

```bash
# 启动服务
pm2 start ecosystem.config.js

# 保存配置
pm2 save

# 设置开机自启
pm2 startup systemd -u $USER --hp /home/$user
```

#### 使用 nohup（简单方式）

```bash
nohup npx next start --port 5000 > /tmp/assessment-service.log 2>&1 &
```

### 步骤 6：配置 Nginx（可选）

如果需要使用 Nginx 作为反向代理：

```bash
# 赋予配置脚本执行权限
chmod +x setup-nginx.sh

# 执行配置脚本
sudo ./setup-nginx.sh

# 或手动配置
sudo cp nginx.conf /etc/nginx/sites-available/assessment
sudo ln -sf /etc/nginx/sites-available/assessment /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## 验证部署

### 1. 检查服务状态

```bash
# 使用 PM2
pm2 status
pm2 logs assessment-app

# 或检查端口
ss -lntp | grep 5000
```

### 2. 访问服务

- **主页**: http://47.89.134.217:5000
- **管理后台**: http://47.89.134.217:5000/admin/login

### 3. 测试登录

使用以下任一账户登录：

| 用户名 | 密码 |
|--------|------|
| admin | admin123 |
| ksq | ksq123 |

### 4. 测试 API 接口

```bash
# 测试初始化接口
curl http://47.89.134.217:5000/api/admin/init

# 测试登录接口
curl -X POST http://47.89.134.217:5000/api/admin/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'
```

## 常用管理命令

### PM2 管理命令

```bash
# 查看服务状态
pm2 status

# 查看日志
pm2 logs assessment-app

# 实时查看日志
pm2 logs assessment-app --lines 100

# 重启服务
pm2 restart assessment-app

# 停止服务
pm2 stop assessment-app

# 删除服务
pm2 delete assessment-app

# 监控服务
pm2 monit
```

### Nginx 管理命令

```bash
# 查看状态
sudo systemctl status nginx

# 重启服务
sudo systemctl restart nginx

# 重新加载配置
sudo systemctl reload nginx

# 查看日志
sudo tail -f /var/log/nginx/assessment-access.log
sudo tail -f /var/log/nginx/assessment-error.log

# 测试配置
sudo nginx -t
```

### 应用管理命令

```bash
# 查看进程
ps aux | grep next

# 查看端口占用
ss -lntp | grep 5000

# 查看日志
tail -f /tmp/assessment-service.log
```

## 故障排查

### 1. 端口被占用

```bash
# 查看占用端口的进程
ss -lntp | grep 5000

# 停止进程
kill -9 <PID>
```

### 2. 服务无法启动

```bash
# 查看日志
pm2 logs assessment-app --err

# 或查看应用日志
tail -f /tmp/assessment-service.log

# 检查 Node.js 版本
node --version

# 检查依赖
pnpm install
```

### 3. 网络访问失败

```bash
# 检查防火墙
sudo ufw status

# 检查端口监听
ss -lntp | grep 5000

# 检查安全组（在阿里云控制台）
```

### 4. 数据库连接失败

```bash
# 检查数据库配置
cat .env.production

# 查看应用日志
pm2 logs assessment-app

# 测试初始化接口
curl http://localhost:5000/api/admin/init
```

## 更新部署

```bash
# 1. 拉取最新代码
git pull

# 2. 安装依赖
pnpm install

# 3. 重构项目
npx next build

# 4. 重启服务
pm2 restart assessment-app
```

## 性能优化建议

### 1. 启用 Gzip 压缩

已在 Nginx 配置中启用。

### 2. 启用静态资源缓存

已在 Nginx 配置中配置。

### 3. 使用 PM2 集群模式

修改 `ecosystem.config.js`：
```javascript
instances: 'max', // 或指定数字，如 2
exec_mode: 'cluster',
```

### 4. 配置 HTTPS

```bash
# 安装 Certbot
sudo apt-get install -y certbot python3-certbot-nginx

# 获取 SSL 证书
sudo certbot --nginx -d 47.89.134.217

# 自动续期
sudo certbot renew --dry-run
```

## 安全建议

1. **修改默认密码**：生产环境务必修改默认管理员密码
2. **使用 HTTPS**：配置 SSL 证书，启用 HTTPS
3. **配置防火墙**：只开放必要的端口
4. **定期更新**：及时更新系统和依赖包
5. **备份策略**：定期备份数据库和配置文件
6. **监控日志**：定期检查应用和系统日志

## 联系支持

如有问题，请查看：
- 应用日志：`pm2 logs assessment-app`
- Nginx 日志：`/var/log/nginx/assessment-*.log`
- 系统日志：`/var/log/syslog`
