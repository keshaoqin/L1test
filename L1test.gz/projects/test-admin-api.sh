#!/bin/bash

# 管理后台 API 测试脚本

echo "🧪 测试管理后台 API..."
echo ""

# 测试仪表盘 API
echo "1️⃣ 测试仪表盘统计 API..."
curl -s http://localhost:5000/api/admin/dashboard | python3 -m json.tool || echo "❌ 仪表盘 API 测试失败"
echo ""

# 测试评估列表 API
echo "2️⃣ 测试评估列表 API..."
curl -s "http://localhost:5000/api/admin/assessments?limit=5" | python3 -m json.tool || echo "❌ 评估列表 API 测试失败"
echo ""

# 测试登录 API
echo "3️⃣ 测试登录 API..."
curl -s -X POST http://localhost:5000/api/admin/auth/login \
  -H "Content-Type: application/json" \
  -d '{"password":"admin123"}' | python3 -m json.tool || echo "❌ 登录 API 测试失败"
echo ""

echo "✅ API 测试完成"
