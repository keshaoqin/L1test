# 阿里云服务器部署配置完成摘要

## 📋 项目信息

**项目名称**: 科学减重生活方式评估系统
**部署目标**: 阿里云服务器
**服务器信息**:
- 公网 IP: 47.89.134.217
- 私有 IP: 172.19.22.208
- 应用端口: 5000

## 🎯 部署方式

提供了三种部署方式，推荐使用 PM2 部署：

### 1. PM2 部署（推荐，生产环境）
```bash
cd /workspace/projects
./deploy-with-pm2.sh
```

### 2. 基础部署（使用 nohup）
```bash
cd /workspace/projects
./deploy.sh
```

### 3. 快速启动（用于测试）
```bash
cd /workspace/projects
./quick-start.sh
```

## 📁 已创建的配置文件

### 环境配置
- ✅ `.env.production` - 生产环境变量配置

### Nginx 配置
- ✅ `nginx.conf` - Nginx 反向代理配置
- ✅ `setup-nginx.sh` - Nginx 安装和配置脚本

### PM2 配置
- ✅ `ecosystem.config.js` - PM2 进程管理配置

### Systemd 配置
- ✅ `assessment-app.service` - Systemd 服务配置

### 部署脚本
- ✅ `deploy-with-pm2.sh` - PM2 部署脚本（推荐）
- ✅ `deploy.sh` - 基础部署脚本
- ✅ `quick-start.sh` - 快速启动脚本

### 文档
- ✅ `DEPLOYMENT.md` - 详细部署指南
- ✅ `DEPLOYMENT_CHECKLIST.md` - 部署检查清单
- ✅ `DEPLOY_README.md` - 部署说明文档
- ✅ `QUICK_START.md` - 快速开始文档
- ✅ `DEPLOYMENT_SUMMARY_COMPLETE.md` - 本文件

## 🔐 默认管理员账户

| 用户名 | 密码 | 说明 |
|--------|------|------|
| admin | admin123 | 默认管理员 |
| ksq | ksq123 | 附加管理员 |

## 🌐 访问地址

部署成功后，可以通过以下地址访问：

- **主页**: http://47.89.134.217:5000
- **管理后台**: http://47.89.134.217:5000/admin/login

如果配置了 Nginx：
- **HTTP**: http://47.89.134.217（端口 80）

## 🔧 防火墙配置

需要在阿里云 ECS 安全组和服务器防火墙中开放以下端口：

- TCP 80 - HTTP（如使用 Nginx）
- TCP 443 - HTTPS（如使用 Nginx）
- TCP 5000 - 应用端口

## 📝 部署步骤（完整）

### 1. 准备服务器环境

```bash
# 更新系统
sudo apt-get update && sudo apt-get upgrade -y

# 安装基础工具
sudo apt-get install -y curl git vim wget

# 安装 Node.js 24
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
source ~/.bashrc
nvm install 24
nvm use 24
nvm alias default 24

# 安装 pnpm
npm install -g pnpm

# 安装 PM2
npm install -g pm2

# 安装 Nginx（可选）
sudo apt-get install -y nginx
```

### 2. 上传项目代码

使用 git、scp 或 rsync 上传项目代码到 `/workspace/projects`。

### 3. 配置防火墙

```bash
# 开放端口
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 5000/tcp
```

**重要**: 在阿里云 ECS 控制台的安全组中，添加相应的入站规则。

### 4. 部署应用

```bash
cd /workspace/projects
./deploy-with-pm2.sh
```

### 5. 配置 Nginx（可选）

```bash
sudo ./setup-nginx.sh
```

### 6. 验证部署

```bash
# 检查服务状态
pm2 status

# 检查端口监听
ss -lntp | grep 5000

# 测试访问
curl http://localhost:5000
curl http://localhost:5000/api/admin/init
```

## 🎨 功能特性

### 自动初始化
- 部署后自动初始化管理员账户
- 登录失败时自动检测并初始化
- 确保 admin 和 ksq 账户可用

### 健康检查
- 登录页面加载时自动检查系统状态
- 登录接口提供自动重试机制
- 详细的错误日志输出

### 管理功能
- 评估记录管理（查看、筛选、导出）
- 管理员管理（CRUD、启用/禁用、修改密码）
- 详细的评估报告生成
- 数据统计和分析

## 📊 常用管理命令

### PM2 管理

```bash
pm2 status                    # 查看服务状态
pm2 logs assessment-app       # 查看日志
pm2 restart assessment-app    # 重启服务
pm2 stop assessment-app       # 停止服务
pm2 monit                     # 监控服务
```

### Nginx 管理

```bash
sudo systemctl restart nginx  # 重启服务
sudo systemctl status nginx   # 查看状态
sudo nginx -t                 # 测试配置
```

### 应用管理

```bash
ss -lntp | grep 5000          # 查看端口
tail -f /tmp/assessment-*.log # 查看日志
```

## 🔍 测试命令

```bash
# 测试初始化接口
curl http://localhost:5000/api/admin/init

# 测试登录接口
curl -X POST http://localhost:5000/api/admin/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# 测试网站访问
curl http://localhost:5000
```

## 🔄 更新部署

```bash
cd /workspace/projects
git pull
pnpm install
npx next build
pm2 restart assessment-app
```

## ⚠️ 安全建议

1. **修改默认密码**: 生产环境务必修改默认管理员密码
2. **使用 HTTPS**: 配置 SSL 证书，启用 HTTPS
3. **配置防火墙**: 只开放必要的端口
4. **定期更新**: 及时更新系统和依赖包
5. **备份策略**: 定期备份数据库和配置文件
6. **监控日志**: 定期检查应用和系统日志

## 🐛 故障排查

### 服务无法启动
```bash
pm2 logs assessment-app --err
ss -lntp | grep 5000
node --version
```

### 无法访问网站
```bash
sudo ufw status
pm2 status
ss -lntp | grep 5000
```

### 登录失败
```bash
curl http://localhost:5000/api/admin/init
pm2 logs assessment-app
```

### 构建失败
```bash
rm -rf .next node_modules/.cache
pnpm install
npx next build
```

## 📚 详细文档

- [详细部署指南](DEPLOYMENT.md)
- [部署检查清单](DEPLOYMENT_CHECKLIST.md)
- [快速开始文档](QUICK_START.md)
- [部署说明文档](DEPLOY_README.md)

## ✅ 部署检查清单

部署前请确认：

- [ ] 服务器环境已准备（Node.js 24.x, pnpm, PM2）
- [ ] 防火墙已配置（开放端口 80, 443, 5000）
- [ ] 项目代码已上传
- [ ] 阿里云安全组规则已配置
- [ ] 依赖已安装（pnpm install）
- [ ] 项目已构建（npx next build）
- [ ] 服务已启动（PM2 或 nohup）
- [ ] 端口正常监听（ss -lntp | grep 5000）
- [ ] 网站可访问（curl http://47.89.134.217:5000）
- [ ] 管理后台可登录（admin/admin123 或 ksq/ksq123）

## 📞 技术支持

如有问题，请查看：

- **应用日志**: `pm2 logs assessment-app`
- **Nginx 日志**: `/var/log/nginx/assessment-*.log`
- **系统日志**: `/var/log/syslog`
- **应用日志文件**: `/tmp/assessment-*.log`

---

**部署日期**: 2025-01-09
**配置版本**: 1.0.0
**服务器 IP**: 47.89.134.217
**应用端口**: 5000

**一键部署命令**:
```bash
cd /workspace/projects && ./deploy-with-pm2.sh
```

**快速访问**:
- 主页: http://47.89.134.217:5000
- 管理后台: http://47.89.134.217:5000/admin/login
